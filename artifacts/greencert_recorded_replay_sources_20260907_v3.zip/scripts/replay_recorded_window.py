"""Read-only recomputation of a completed recorded finite-window enclosure.

Rechecks physical encoding, saved vector norms and role chains, neural
envelope records, Green calibration, scalar closure, and output margins.
Neural gradients/HVPs/envelopes themselves remain validated-producer
obligations. This tool cannot issue a certificate or observe a future.
"""
import argparse
import ast
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import time

import numpy as np
import flint

from anchor_response_evidence import authenticate_anchor, original_checkpoint, reference_prefix
from bound_row_evidence import authenticate_bound_row
from combined_anchor_response import combine
from exact_homogeneous_replay import authenticate as authenticate_homogeneous
from exact_response_replay import authenticate_response
from exact_runtime_green_replay import authenticate_runtime_green_family
from file_backed_window_assembly import WindowEvidenceRequest, BoundRowLocation, _validate, fingerprint
from green_family_evidence import checked_array, canonical_sha, require
from known_anchor_response import encode_velocity_offset
from recorded_evidence_replay import RecordedEvidenceReader, canonical_path
from portable_reference_margin_evidence import authenticate_reference_window, intersect_with_derivative_row
from verified_artifact_io import unique_object, invalid_constant, finite_json_float
from window_event_assembly import Identity, ResponseBound, assemble


def primitive(value):
    return json.loads(json.dumps(value, allow_nan=False))


def source_graph():
    base = Path(__file__).resolve().parent
    pending, result = [Path(__file__).resolve()], {}
    while pending:
        path = pending.pop()
        if path.name in result:
            continue
        raw = path.read_bytes()
        result[path.name] = hashlib.sha256(raw).hexdigest()
        for node in ast.walk(ast.parse(raw)):
            names = ([node.module] if isinstance(node, ast.ImportFrom) and node.module else
                     [item.name for item in node.names] if isinstance(node, ast.Import) else [])
            for name in names:
                candidate = base/(name.replace(".", "/")+".py")
                if candidate.is_file() and candidate.name not in result:
                    pending.append(candidate)
    return result


def load_context(root, manifest_path, manifest_sha):
    raw = manifest_path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == manifest_sha, "replay manifest differs")
    manifest = json.loads(raw, object_pairs_hook=unique_object, parse_constant=invalid_constant, parse_float=finite_json_float)
    require(manifest["schema"] == "recorded_large_evidence_manifest_v1" and
            manifest["event_certificate_issued"] is False and manifest["future_outcome_access"] is False,
            "replay index scope differs")
    reader = RecordedEvidenceReader(root, {name: row["sha256"] for name,row in manifest["files"].items()})
    terminal, _ = reader.read_json(manifest["original_terminal"], manifest["original_terminal_sha256"])
    audit, _ = reader.read_json(manifest["original_audit"], manifest["original_audit_sha256"])
    recorded = {canonical_path(name): sha for name,sha in audit["observed_artifact_hashes"].items()}
    required = {**recorded, canonical_path(manifest["original_terminal"]): manifest["original_terminal_sha256"],
                canonical_path(manifest["original_audit"]): manifest["original_audit_sha256"]}
    require(reader.recorded == required, "recorded dependency population changed")
    require(terminal["audit_sha256"] == manifest["original_audit_sha256"] and
            terminal["policy_sha256"] == audit["policy_sha256"] and
            terminal["event_certificate_issued"] is True and terminal["decision"]["decision"] == "certificate" and
            terminal["future_outcome_access"] is False and terminal["original_issuance_policy_changed"] is False,
            "not the original completed certificate record")
    raw_request = audit["request"]
    request = WindowEvidenceRequest(**{**raw_request, "identity": Identity(**raw_request["identity"]),
        "original_probe_hashes": tuple(raw_request["original_probe_hashes"]),
        "example_ids": tuple(raw_request["example_ids"]),
        "row_plan": tuple(BoundRowLocation(**row) for row in raw_request["row_plan"]),
        "forbidden_outcome_files": tuple(raw_request["forbidden_outcome_files"])})
    _validate(reader, request)
    require(terminal["identity"] == asdict(request.identity) and
            terminal["request_sha256"] == fingerprint(request), "recorded window identity differs")
    policy, _ = reader.read_json(terminal["policy_path"], terminal["policy_sha256"])
    assembly_names = [name for name,sha in reader.recorded.items() if sha == terminal["assembly_policy_sha256"]]
    require(bool(assembly_names), "missing pinned assembly policy")
    assembly_policy, _ = reader.read_json(sorted(assembly_names)[0], terminal["assembly_policy_sha256"])
    require(assembly_policy["request"] == raw_request and
            policy["assembly_policy_sha256"] == terminal["assembly_policy_sha256"] and
            policy["execution_registry"] == assembly_policy["execution_registry"] and
            policy["sequence_plan"] == assembly_policy["sequence_plan"] and
            canonical_sha({"executions": policy["execution_registry"], "sequence_plan": policy["sequence_plan"]}) ==
                terminal["execution_plan_sha256"], "original execution composition differs")
    sources = source_graph()
    for name, digest in sources.items():
        if "scripts/"+name in recorded:
            require(recorded["scripts/"+name] == digest, "loaded frozen implementation differs")
    forbidden = set(request.forbidden_outcome_files)
    parent = Path(canonical_path(manifest["original_terminal"])).parent.parent
    forbidden.update(str(parent/p) for p in ("reveal.json", "registered_outcome_run"))
    forbidden = tuple(sorted(forbidden))
    def no_future_reads():
        names = {canonical_path(p).casefold() for p in reader.recorded} | {
            canonical_path(p).casefold() for p in reader.observed}
        require(not any(name == canonical_path(p).casefold() or name.startswith(canonical_path(p).casefold()+"/")
                        for p in forbidden for name in names), "future content belongs to replay inputs")
    no_future_reads()
    return reader, request, terminal, audit, policy, sources, forbidden, no_future_reads


def fresh_response(reader, request, terminal, audit, progress):
    ident = request.identity
    anchor = authenticate_anchor(reader, identity=ident, **request.anchor_paths)
    folder = Path(canonical_path(request.response_folder)).parent/"known_anchor_homogeneous"
    method, mh = reader.read_json(folder/"method.json", terminal["homogeneous_method_sha256"])
    require(method["identity"] == asdict(ident) and method["learning_rate"] == request.learning_rate and
            method["momentum"] == request.momentum and method["original_green_method_sha256"] == request.green_method_sha256 and
            method["precision_bits"] == 128 and method["future_outcome_access"] is False and
            method["expected_hvp_indices"] == list(range(1, ident.horizon)) and
            method["training_pairs"] == [row["pair"] for row in request.training_examples] and
            method["training_labels"] == [row["label"] for row in request.training_examples] and
            method["normalization_eps"] == request.normalization_eps, "homogeneous method binding differs")
    reader.check_sources(method, required_names=frozenset({"known_anchor_response.py", "known_anchor_green_response.py",
                                                         "arb_factored_regularizer_hvp.py"}))
    encoding, _ = reader.read_json(method["encoding_record"], method["encoding_sha256"])
    require(encoding["identity"] == asdict(ident) and encoding["vector_sha256"] == method["encoded_velocity_sha256"] and
            encoding["offset_sign"] == "eta*original_unscaled_velocity - reference_scaled_velocity" and
            encoding["original_certificate_gamma_replaced"] is False and encoding["future_outcome_access"] is False,
            "physical encoding record differs")
    reader.check_sources(encoding, required_names=frozenset({"known_anchor_response.py"}))
    encoded = checked_array(reader, encoding["vector_path"], encoding["vector_sha256"], ident.parameters)
    candidate, _ = reader.read_json(request.anchor_paths["candidate_path"], ident.candidate_sha256)
    checkpoint = original_checkpoint(reader, request.anchor_paths["checkpoint_path"], candidate["anchor_sha256"], ident.parameters)
    center = reference_prefix(reader, request.anchor_paths["corrected_path"], ident.reference_sha256,
                              shape=(ident.horizon+1, 2*ident.parameters))[0]
    relation = encode_velocity_offset(checkpoint["velocity"], center[ident.parameters:],
                                      learning_rate=request.learning_rate, momentum=request.momentum)
    tail = relation["unrepresented_first_injection_norm_upper"]
    require(np.array_equal(encoded, relation["encoded_velocity_offset"]) and
            tail == encoding["unrepresented_first_injection_norm_upper"] == method["initial_encoding_injection_tail_upper"] and
            anchor.first_injection_error_upper == method["original_first_injection_bound_still_in_force"],
            "physical encoding or its unrepresented error differs")
    original = authenticate_response(reader, request.response_folder, identity=ident, anchor=anchor,
        gradient_folder=request.gradient_folder, training_count=len(request.training_examples),
        progress=lambda j,H: progress("original_response", j, H))
    construction, _ = reader.read_json(folder/"construction_summary.json")
    saved, product_sha = reader.read_json(folder/"product/summary.json")
    require(construction == {"method_sha256": mh, **saved} and construction["complete"] is True,
            "incomplete homogeneous product")
    homogeneous = authenticate_homogeneous(reader, folder/"product", identity=ident, summary_sha256=product_sha,
        operator_sha256=mh, encoding_sha256=method["encoding_sha256"], encoded_velocity_offset=encoded,
        learning_rate=request.learning_rate, momentum=request.momentum)
    profile = combine(reader, request.response_folder, original_evidence=original, homogeneous=homogeneous,
        encoding_injection_tail_upper=tail, progress=lambda j,H: progress("combined_response", j,H))
    require(primitive(asdict(profile)) == audit["result"]["provenance"]["known_anchor_response"]["profile"],
            "replayed physical response differs from original audit")
    return ResponseBound(ident, profile.parameter_norms, profile.residual_upper,
                         profile.encoding_injection_tail_upper, True, "outward")


def run(args):
    reader, request, terminal, audit, policy, sources, forbidden, barrier = load_context(
        args.root, args.manifest, args.manifest_sha256)
    base = {"schema": "recorded_window_read_only_replay_v1", "manifest_sha256": args.manifest_sha256,
        "identity": asdict(request.identity), "sources": sources, "event_certificate_issued": False,
        "future_outcome_access": False, "outcome_join_authorized": False,
        "historical_prospectivity_reestablished": False, "neural_kernels_replayed": False}
    if args.mode == "check":
        return {**base, "status": "ready_read_only_replay", "numerical_replay_performed": False}
    started = time.perf_counter()
    def progress(component, current=None, total=None):
        print(json.dumps({"component": component, "current": current, "total": total}), flush=True)
    progress("physical_response")
    response = fresh_response(reader, request, terminal, audit, progress)
    barrier()
    progress("reference_margins")
    margins = authenticate_reference_window(reader, request.reference_margin_folder, identity=request.identity,
        evaluation=request.evaluation_examples, example_ids=request.example_ids,
        classes=request.classes, normalization_eps=request.normalization_eps)
    output, drift = [margins["anchor"]], []
    for location in request.row_plan:
        row = authenticate_bound_row(reader, location.folder, identity=request.identity, step=location.step,
            domain=request.domain, producer=location.producer, training_examples=request.training_examples,
            evaluation_examples=request.evaluation_examples, example_ids=request.example_ids)
        output.append(intersect_with_derivative_row(margins["rows"][location.step], row["output"]))
        if location.step < request.identity.horizon:
            require(row["drift"] is not None, "missing interior drift")
            drift.append(row["drift"])
        else:
            require(row["drift"] is None, "unexpected terminal drift")
        progress("derivative_rows", location.step, request.identity.horizon)
    barrier()
    progress("complete_green_family")
    green = authenticate_runtime_green_family(reader, origin_folder=request.green_folder,
        origin_method_sha256=request.green_method_sha256, executions=policy["execution_registry"],
        sequence_plan=tuple(tuple(v) for v in policy["sequence_plan"]), identity=request.identity,
        power=request.power, original_probe_hashes=request.original_probe_hashes,
        failure_probability=request.failure_probability, learning_rate=request.learning_rate,
        momentum=request.momentum, forbidden_paths=forbidden)
    require(green["bound"] is not None, "recorded Green bound no longer closes")
    result = assemble(identity=request.identity, training_count=len(request.training_examples),
        example_ids=request.example_ids, domain=request.domain, drift_rows=drift, output_rows=output,
        response=response, green=green["bound"], target=request.target, persistence=request.persistence, precision_bits=256)
    require(result == audit["result"]["assembly"] and result["bracket"] == terminal["decision"]["bracket"] and
            result["certificate_issued"] is False, "replayed event assembly differs")
    barrier()
    numerically_accessed = tuple(reader.observed)
    progress("final_recorded_graph_hash_check", 0, len(reader.recorded))
    for name, digest in reader.recorded.items():
        reader.check_blob(name, digest)
    require(source_graph() == sources, "replay implementation changed during execution")
    return {**base, "status": "PASS", "numerical_replay_performed": True, "assembly": result,
        "green": primitive({**green, "bound": asdict(green["bound"])}),
        "physical_anchor_encoding_replayed": True, "array_norms_replayed": True,
        "premise_files_accessed_before_final_hash_check": len(numerically_accessed),
        "complete_recorded_graph_rehashed": True,
        "observed_artifact_hashes": reader.observed, "elapsed_seconds": time.perf_counter()-started,
        "environment": {"python": platform.python_version(), "system": platform.system(),
                        "machine": platform.machine(), "numpy": np.__version__, "flint": flint.__version__},
        "scope": "Read-only recomputation of the recorded enclosure, conditional on the original validated neural producers and ideal-Gaussian event; no new issuance or future observation."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--mode", choices=("check", "replay"), default="check")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    if args.report and args.report.exists():
        parser.error("fresh report required")
    result = {"created_utc": datetime.now(timezone.utc).isoformat(), **run(args)}
    if args.report:
        with args.report.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(result, stream, indent=2, allow_nan=False)
            stream.write("\n")
    print(json.dumps({k:v for k,v in result.items() if k not in ("assembly", "green", "observed_artifact_hashes", "sources")}, indent=2))
