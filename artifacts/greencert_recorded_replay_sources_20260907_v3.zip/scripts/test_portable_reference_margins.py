"""Windows/POSIX path-encoding equality and preserved margin-evidence refusals."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import tempfile

from portable_reference_margin_evidence import authenticate_reference_window
from reference_margin_evidence import authenticate_reference_window as reference
from recorded_evidence_replay import RecordedEvidenceReader
from test_reference_margin_evidence import fixture
from verified_artifact_io import IntegrityError


def pin(root):
    return RecordedEvidenceReader(root, {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                                       for p in root.rglob("*") if p.is_file()})


def numerical(result):
    return {"rows": [asdict(row) for row in result["rows"]], "anchor": asdict(result["anchor"]),
            "lower_counts": result["lower_counts"], "upper_counts": result["upper_counts"]}


def audit():
    cases = refusals = legacy_failures = 0
    with tempfile.TemporaryDirectory(prefix="portable_margins_") as temporary:
        root = Path(temporary).resolve()
        for imported in (None, 0, 1, 3):
            baseline = fixture(root/f"base_{imported}", imported=imported)
            expected = numerical(reference(**baseline))
            for separator in ("/", "\\"):
                def encode(stage, record, **where):
                    if stage == "summary":
                        for entry in record["rows"]:
                            entry["path"] = entry["path"].replace("\\", "/").replace("/", separator)
                folder = root/f"case_{cases}"
                args = fixture(folder, imported=imported, mutation=encode)
                args["reader"] = pin(folder)
                assert numerical(authenticate_reference_window(**args)) == expected
                cases += 1
                if separator == "\\" and imported is not None and __import__("os").name != "nt":
                    try:
                        reference(**args)
                    except IntegrityError as error:
                        assert "imported point hash/path mismatch" in str(error)
                        legacy_failures += 1
                    else:
                        raise AssertionError("legacy Linux path failure not reproduced")
        for field, value in (("path", "../prior/result.json"), ("path", "/prior/result.json"),
                             ("path", "prior/not_result.json"), ("sha256", "0"*64)):
            def corrupt(stage, record, **where):
                if stage == "summary":
                    record["rows"][1][field] = value
            folder = root/f"refusal_{refusals}"
            args = fixture(folder, mutation=corrupt)
            args["reader"] = pin(folder)
            try:
                authenticate_reference_window(**args)
            except IntegrityError:
                refusals += 1
            else:
                raise AssertionError("malformed imported evidence accepted")
    return {"schema": "portable_reference_margin_tests_v1", "status": "PASS",
            "path_encoding_equality_cases": cases, "coherent_refusals": refusals,
            "legacy_posix_failures_reproduced": legacy_failures,
            "frozen_auditor_modified": False, "neural_forward_replayed": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = audit()
    payload = json.dumps(result, indent=2, sort_keys=True)+"\n"
    if args.report:
        with args.report.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(payload)
    print(payload, end="")
