# Portable derivative of reference_margin_evidence.py (original unchanged).
# Original SHA256: 02c6e9f0b4138dcc328b9fe85f230ffdb283d42cf0f0e8cf5be5737b9c9fc118.
# Changes: canonicalize recorded relative paths before basename/parent parsing.
"""Authenticate reference logits and rederive conservative margin intervals.

These are reference-point observations, not nonlinear trajectory enclosures.
Only the exact parameter anchor can use them without separate derivative
bounds. Neural forward arithmetic remains an obligation of the authenticated
validated producer; interval subtraction and count logic are replayed here.
"""
from dataclasses import dataclass, replace
import math
from pathlib import Path
from recorded_evidence_replay import canonical_path
import re

from flint import arb, ctx
from green_family_evidence import canonical_sha, require
from verified_artifact_io import IntegrityError
from window_event_assembly import Identity, PointMargin, AnchorOutputRow, OutputRow

COMMON_SOURCES=frozenset({"audit_candidate_outward_forward.py","test_arb_deep_transformer_forward.py",
    "arb_deep_transformer_forward.py","arb_transformer_objective.py","transformer_hvp_grokking.py"})
WINDOW_PROTOCOL="LARGER_CANDIDATE_OUTWARD_WINDOW_PROTOCOL.md"
POINT_PROTOCOL="LARGER_CANDIDATE_OUTWARD_FORWARD_PROTOCOL.md"


def scalar(value):
    require(type(value) in (int,float),"invalid margin scalar")
    try:
        value=float(value)
    except OverflowError:
        raise IntegrityError("unrepresentable margin scalar") from None
    require(math.isfinite(value),"nonfinite margin scalar")
    return value


def interval(value):
    lo,hi=scalar(value["lower"]),scalar(value["upper"])
    require(lo<=hi,"reversed output/margin interval")
    return lo,hi


def outward_endpoint(value,upper):
    result=math.nextafter(float(value.upper() if upper else value.lower()),math.inf if upper else -math.inf)
    require(math.isfinite(result),"margin has no finite float64 enclosure")
    return result


@dataclass(frozen=True)
class ReferenceMarginRow:
    identity: Identity
    step: int
    margins: tuple[PointMargin,...]
    arithmetic: str


def anchor_output(row):
    require(isinstance(row,ReferenceMarginRow) and row.step==0 and row.arithmetic=="outward",
            "only verified anchor margins need no derivative envelope")
    return AnchorOutputRow(row.identity,row.margins,"outward")


def intersect_with_derivative_row(reference,derivatives):
    """Keep separately verified derivatives; intersect two reference intervals."""
    require(isinstance(reference,ReferenceMarginRow) and isinstance(derivatives,OutputRow) and
            reference.step==derivatives.step and reference.identity==derivatives.identity and
            reference.arithmetic==derivatives.arithmetic=="outward","reference/derivative identity mismatch")
    require(tuple(x.example_id for x in reference.margins)==tuple(x.example_id for x in derivatives.margins),
            "reference/derivative evaluation population mismatch")
    combined=[]
    for point,bound in zip(reference.margins,derivatives.margins):
        lo=max(point.lower,bound.lower)
        hi=min(point.upper,bound.upper)
        require(lo<=hi,"disjoint independently enclosed reference margins")
        combined.append(replace(bound,lower=lo,upper=hi))
    return replace(derivatives,margins=tuple(combined))


def authenticate_reference_window(reader,folder,*,identity,evaluation,example_ids,classes,normalization_eps):
    old=ctx.prec
    ctx.prec=256
    try:
        require(type(classes) is int and classes>=2,"invalid output class count")
        require(canonical_sha(evaluation)==identity.evaluation_set_sha256 and
                len(evaluation)==len(example_ids)>0 and len(set(example_ids))==len(example_ids),
                "reference evaluation population mismatch")
        for i,item in enumerate(evaluation):
            require(type(item["index"]) is int and item["index"]==i and type(item["label"]) is int and
                    0<=item["label"]<classes,"invalid fixed evaluation row")
        folder=Path(canonical_path(folder))
        summary,summary_sha=reader.read_json(folder/"summary.json",allow_in_progress=True)
        method,mh=reader.read_json(folder/"method.json",summary["method_sha256"])
        reader.check_sources(method,required_names=COMMON_SOURCES|{"audit_candidate_outward_window.py"})
        reader.check_blob(WINDOW_PROTOCOL,method["protocol_sha256"])
        for record in (method,summary):
            require(record["parameters"]==identity.parameters and record["horizon"]==identity.horizon and
                    record["examples"]==len(evaluation) and record["precision_bits"]==192 and
                    record["future_outcome_access"] is False,"reference-window dimension/arithmetic scope mismatch")
        require(method["candidate_sha256"]==identity.candidate_sha256 and method["path_sha256"]==identity.reference_sha256,
                "foreign reference-forward operator")
        entries=summary["rows"]
        require(isinstance(entries,list) and len(entries)==identity.horizon+1,"incomplete reference window")
        require(len(summary["lower_counts"])==len(summary["upper_counts"])==len(entries),"incomplete producer count paths")
        imported={int(match.group(1)):value for key,value in method.items()
                  if (match:=re.fullmatch(r"prior_step(\d+)_sha256",key))}
        require(all(0<=j<=identity.horizon for j in imported),"imported point outside the window")
        rows=[]
        lower_counts=[]
        upper_counts=[]
        imported_rows=[]
        for j,entry in enumerate(entries):
            require(type(entry["step"]) is int and entry["step"]==j,"noncanonical/duplicate reference time")
            path=Path(canonical_path(entry["path"]))
            if j not in imported:
                require(reader.resolve(path)==reader.resolve(folder/f"step_{j:03d}.json"),"unregistered reference row path")
            else:
                require(path.name=="result.json" and entry["sha256"]==imported[j],"imported point hash/path mismatch")
            record,sha=reader.read_json(path,entry["sha256"])
            if j not in imported:
                require(record["method_sha256"]==mh,"reference window row uses another method")
            else:
                point,point_sha=reader.read_json(path.parent/"method.json",record["method_sha256"])
                reader.check_sources(point,required_names=COMMON_SOURCES)
                reader.check_blob(POINT_PROTOCOL,point["protocol_sha256"])
                require(point["candidate_sha256"]==identity.candidate_sha256 and point["path_sha256"]==identity.reference_sha256 and
                        point["reference_step"]==j and point["parameters"]==identity.parameters and
                        point["examples"]==len(evaluation) and point["precision_bits"]==192 and
                        point["future_outcome_access"] is False,"imported point identity/arithmetic mismatch")
                imported_rows.append({"step":j,"path":str(path),"record_sha256":sha,"method_sha256":point_sha})
            require(record["parameters"]==identity.parameters and record["examples"]==len(evaluation) and
                    type(record["reference_step"]) is int and record["reference_step"]==j and
                    record["normalization_eps"]==normalization_eps and record["future_outcome_access"] is False,
                    "reference point identity or normalization mismatch")
            require(len(record["outputs"])==len(record["margins"])==len(evaluation),"partial reference example population")
            margins=[]
            stored_lower=stored_upper=0
            for i,(label_info,outputs,saved) in enumerate(zip(evaluation,record["outputs"],record["margins"])):
                label=label_info["label"]
                require(len(outputs)==classes and saved["example"]==i and saved["label"]==label and
                        len(saved["competitor_margins"])==classes-1,"reference class/label/example mismatch")
                require(type(saved["guaranteed_correct"]) is bool and type(saved["possibly_correct"]) is bool and
                        (not saved["guaranteed_correct"] or saved["possibly_correct"]),"invalid producer correctness metadata")
                logits=[interval(value) for value in outputs]
                lows=[]
                highs=[]
                for k,direct in zip((k for k in range(classes) if k!=label),saved["competitor_margins"]):
                    # Use the stored logit boxes, not narrower unverified
                    # arithmetic inferred from a producer correctness flag.
                    lo=outward_endpoint(arb(logits[label][0])-arb(logits[k][1]),False)
                    hi=outward_endpoint(arb(logits[label][1])-arb(logits[k][0]),True)
                    direct_lo,direct_hi=interval(direct)
                    require(max(lo,direct_lo)<=min(hi,direct_hi),"inconsistent logit and competitor-margin enclosures")
                    lows.append(lo)
                    highs.append(hi)
                margins.append(PointMargin(example_ids[i],min(lows),min(highs)))
                stored_lower+=int(saved["guaranteed_correct"])
                stored_upper+=int(saved["possibly_correct"])
            require(record["guaranteed_correct_count"]==stored_lower==summary["lower_counts"][j] and
                    record["possible_correct_count"]==stored_upper==summary["upper_counts"][j],"producer count metadata mismatch")
            row=ReferenceMarginRow(identity,j,tuple(margins),"outward")
            rows.append(row)
            lower_counts.append(sum(m.lower>0 for m in margins))
            upper_counts.append(sum(not m.upper<0 for m in margins))
        require(summary["all_counts_resolved"] is (summary["lower_counts"]==summary["upper_counts"]),
                "inconsistent producer resolution metadata")
        return {"rows":tuple(rows),"anchor":anchor_output(rows[0]),"lower_counts":lower_counts,"upper_counts":upper_counts,
                "provenance":{"method_sha256":mh,"summary_sha256":summary_sha,"imported_points":imported_rows,
                    "counts_rederived_from_logit_intervals":True,"neural_forward_replayed":False,
                    "all_rederived_counts_match_producer":lower_counts==summary["lower_counts"] and upper_counts==summary["upper_counts"],
                    "after_anchor_derivative_bounds_supplied":False,"event_certificate_issued":False}}
    except (KeyError,TypeError,IndexError) as error:
        raise IntegrityError("malformed reference-margin evidence") from error
    finally:
        ctx.prec=old
