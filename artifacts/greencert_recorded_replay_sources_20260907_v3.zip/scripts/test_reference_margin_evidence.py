"""Synthetic multi-class windows test reference-only margin authentication."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import shutil
import tempfile

from reference_margin_evidence import (COMMON_SOURCES,WINDOW_PROTOCOL,POINT_PROTOCOL,
    authenticate_reference_window,anchor_output,intersect_with_derivative_row)
from green_family_evidence import canonical_sha
from verified_artifact_io import EvidenceReader,EvidencePending,IntegrityError
from window_event_assembly import Identity,MarginBound,OutputRow,AnchorOutputRow

ROOT=Path(__file__).resolve().parents[1]


def write(path,value):
    data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


def fixture(root,*,imported=1,mutation=None,loose_logits=False):
    root.mkdir()
    sources={}
    for name in COMMON_SOURCES|{"audit_candidate_outward_window.py"}:
        path=root/"scripts"/name
        path.parent.mkdir(exist_ok=True)
        payload=b"# synthetic reference producer fixture\n"
        path.write_bytes(payload)
        sources[name]=hashlib.sha256(payload).hexdigest()
    policies={}
    for name in (WINDOW_PROTOCOL,POINT_PROTOCOL):
        payload=b"synthetic reference protocol\n"
        (root/name).write_bytes(payload)
        policies[name]=hashlib.sha256(payload).hexdigest()
    evaluation=[{"index":0,"pair":[0,1],"label":0},{"index":1,"pair":[1,0],"label":1}]
    identity=Identity("0"*64,"1"*64,"2"*64,canonical_sha(evaluation),7,3,"scaled_momentum_euclidean")
    def change(stage,value,**where):
        if mutation is not None:
            mutation(stage,value,**where)
    def row(j,mh):
        outputs=[]
        margins=[]
        for i,item in enumerate(evaluation):
            label=item["label"]
            true=-1. if j==0 else 1.
            point=[true if k==label else 0. for k in range(3)]
            outputs.append([{"lower":v-.125,"upper":v+.125} for v in point])
            competitors=[{"lower":true-.25,"upper":true+.25} for _ in range(2)]
            if loose_logits and j==1 and i==0:
                outputs[-1]=[{"lower":-1.,"upper":1.} if k==label else {"lower":0.,"upper":0.} for k in range(3)]
                competitors=[{"lower":.25,"upper":.75} for _ in range(2)]
            margins.append({"example":i,"label":label,"guaranteed_correct":j>0,"possibly_correct":j>0,
                            "competitor_margins":competitors})
        record={"method_sha256":mh,"reference_step":j,"parameters":7,"examples":2,
                "normalization_eps":[[1e-5,1e-5]],"future_outcome_access":False,
                "guaranteed_correct_count":0 if j==0 else 2,"possible_correct_count":0 if j==0 else 2,
                "outputs":outputs,"margins":margins}
        change("row",record,j=j)
        return record
    point=None
    prior_sha=None
    if imported is not None:
        pm={"sources":{k:v for k,v in sources.items() if k in COMMON_SOURCES},"protocol_sha256":policies[POINT_PROTOCOL],
            "candidate_sha256":identity.candidate_sha256,"path_sha256":identity.reference_sha256,"reference_step":imported,
            "precision_bits":192,"parameters":7,"examples":2,"future_outcome_access":False}
        change("point_method",pm)
        pmh=write(root/"prior/method.json",pm)
        point=row(imported,pmh)
        prior_sha=write(root/"prior/result.json",point)
    method={"sources":sources,"protocol_sha256":policies[WINDOW_PROTOCOL],"candidate_sha256":identity.candidate_sha256,
            "path_sha256":identity.reference_sha256,"horizon":3,"parameters":7,"examples":2,"precision_bits":192,
            "future_outcome_access":False}
    if imported is not None:
        method[f"prior_step{imported}_sha256"]=prior_sha
    change("method",method)
    mh=write(root/"window/method.json",method)
    entries=[]
    records=[]
    for j in range(4):
        if j==imported:
            path=Path("prior/result.json")
            sha=prior_sha
            record=point
        else:
            path=Path("window")/f"step_{j:03d}.json"
            record=row(j,mh)
            sha=write(root/path,record)
        entries.append({"step":j,"path":str(path),"sha256":sha})
        records.append(record)
    summary={"method_sha256":mh,"horizon":3,"parameters":7,"examples":2,"precision_bits":192,
             "future_outcome_access":False,"rows":entries,"all_counts_resolved":True,
             "lower_counts":[r["guaranteed_correct_count"] for r in records],
             "upper_counts":[r["possible_correct_count"] for r in records]}
    change("summary",summary)
    write(root/"window/summary.json",summary)
    return dict(reader=EvidenceReader(root),folder="window",identity=identity,evaluation=evaluation,
                example_ids=("a","b"),classes=3,normalization_eps=[[1e-5,1e-5]])


def main():
    parent=ROOT/"tmp"
    parent.mkdir(exist_ok=True)
    temp=Path(tempfile.mkdtemp(prefix="reference_margin_test_",dir=parent)).resolve()
    assert temp.parent==parent.resolve() and temp.name.startswith("reference_margin_test_")
    report={"all_passed":True,"valid_import_positions":0,"semantic_rejections":0,"pending_checks":0,
            "producer_flags_not_used_for_certification":False,"derivative_merge_checked":False,"neural_forward_replayed":False}
    try:
        for i,imported in enumerate((None,0,1,3)):
            args=fixture(temp/f"valid_{i}",imported=imported)
            result=authenticate_reference_window(**args)
            assert isinstance(result["anchor"],AnchorOutputRow)
            assert result["lower_counts"]==result["upper_counts"]==[0,2,2,2]
            assert result["provenance"]["all_rederived_counts_match_producer"]
            assert len(result["provenance"]["imported_points"])==int(imported is not None)
            report["valid_import_positions"]+=1
        args=fixture(temp/"loose",loose_logits=True)
        result=authenticate_reference_window(**args)
        assert result["lower_counts"][1]==1 and result["upper_counts"][1]==2
        assert not result["provenance"]["all_rederived_counts_match_producer"]
        report["producer_flags_not_used_for_certification"]=True
        point=result["rows"][1]
        derivatives=OutputRow(args["identity"],1,.5,tuple(MarginBound(m.example_id,.2,1.2,3.,4.) for m in point.margins),"outward")
        combined=intersect_with_derivative_row(point,derivatives)
        assert combined.domain==.5 and all(m.point_jacobian_upper==3. and m.ball_hessian_upper==4. for m in combined.margins)
        assert combined.margins[0].lower==.2
        report["derivative_merge_checked"]=True
        for call in (lambda:anchor_output(point),
                     lambda:intersect_with_derivative_row(point,replace(derivatives,step=2)),
                     lambda:intersect_with_derivative_row(point,replace(derivatives,margins=tuple(replace(m,lower=2.,upper=3.) for m in derivatives.margins)))):
            try:
                call()
            except IntegrityError:
                report["semantic_rejections"]+=1
            else:
                raise AssertionError("point-only or disjoint derivative substitution accepted")
        def field(stage,key,value,**criteria):
            def mutation(actual,row,**where):
                if actual==stage and all(where.get(k)==v for k,v in criteria.items()):
                    row[key]=value
            return mutation
        changes=[field("method","sources",{}),field("method","candidate_sha256","3"*64),
            field("method","path_sha256","4"*64),field("method","precision_bits",64),
            field("method","future_outcome_access",True),field("method","prior_step1_sha256","0"*64),
            field("point_method","sources",{}),field("point_method","reference_step",2),
            field("point_method","path_sha256","0"*64),field("point_method","examples",1),
            field("point_method","precision_bits",64),field("row","normalization_eps",[],j=2),
            field("row","reference_step",1,j=2),field("row","future_outcome_access",True,j=2),
            field("row","outputs",[],j=2),field("row","margins",[],j=2),
            field("row","guaranteed_correct_count",1,j=2),field("summary","rows",[]),
            field("summary","lower_counts",[]),field("summary","all_counts_resolved",False)]
        def nested_change(which):
            def mutation(stage,value,**where):
                if stage=="row" and where.get("j")==2:
                    if which=="label":value["margins"][0]["label"]=1
                    elif which=="reversed":value["outputs"][0][0]["lower"]=2.
                    elif which=="disjoint":value["margins"][0]["competitor_margins"][0]={"lower":8.,"upper":9.}
                elif stage=="summary":
                    if which=="duplicate":value["rows"][2]=value["rows"][1]
                    elif which=="traverse":value["rows"][2]["path"]="../escape.json"
            return mutation
        changes += [nested_change(x) for x in ("label","reversed","disjoint","duplicate","traverse")]
        for i,mutation in enumerate(changes):
            args=fixture(temp/f"bad_{i}",mutation=mutation)
            try:
                authenticate_reference_window(**args)
            except IntegrityError:
                report["semantic_rejections"]+=1
            else:
                raise AssertionError(f"coherent margin corruption {i} accepted")
        for i,name in enumerate(("window/summary.json","prior/result.json","window/step_002.json")):
            args=fixture(temp/f"pending_{i}")
            (args["reader"].root/name).unlink()  # This test's newly-created fixture only.
            try:
                authenticate_reference_window(**args)
            except EvidencePending:
                report["pending_checks"]+=1
            else:
                raise AssertionError("missing reference evidence promoted")
        print(json.dumps(report,indent=2))
        return report
    finally:
        assert temp.resolve().parent==parent.resolve() and temp.name.startswith("reference_margin_test_")
        shutil.rmtree(temp)


if __name__=="__main__":
    main()
