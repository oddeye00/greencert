"""Stop a new 451k-parameter run at an outcome-blind predicted event."""
from dataclasses import asdict, replace
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import torch

from larger_transformer_development import configuration, save_json, digest
from streaming_variational_centerline import build_streaming_transformer_centerline
from transformer_hvp_grokking import (
    make_template, flat_spec, flatten_parameters, make_disjoint_split,
    gradient, accuracy, logits,
)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/larger_transformer_second_pass"
HORIZON, PERSISTENCE = 64, 5
GATES = (0.6, 0.8, 0.9)


def first(counts, target):
    for j in range(len(counts) - PERSISTENCE + 1):
        if min(counts[j:j+PERSISTENCE]) >= target:
            return j
    return None


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / "method.json").exists():
        raise FileExistsError("second pass already started; inspect its process and records before resuming")
    config = replace(configuration("four_block_layernorm"), seed=94002,
                     learning_rate=0.003, weight_decay=0.001, steps=6000)
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    torch.backends.mha.set_fastpath_enabled(False)
    torch.use_deterministic_algorithms(True)
    template = make_template(config)
    spec = flat_spec(template)
    data = make_disjoint_split(config)
    parameter, velocity = flatten_parameters(template), torch.zeros(sum(spec.sizes), dtype=torch.float64)
    assert parameter.numel() == 451008
    source_names = ("select_larger_transformer_second_pass.py", "larger_transformer_development.py",
                    "streaming_variational_centerline.py", "transformer_hvp_grokking.py",
                    "transformer_modal_forecast.py")
    sources = {name: digest(ROOT / "scripts" / name) for name in source_names}
    save_json(OUT / "method.json", {"config": asdict(config), "sources": sources,
                                   "parameter_count": parameter.numel(), "horizon": HORIZON,
                                   "persistence": PERSISTENCE, "gates": GATES,
                                   "protocol_sha256": digest(ROOT / "LARGER_TRANSFORMER_SECOND_PASS_PROTOCOL.md")})
    rows, started = [], time.perf_counter()
    for step in range(config.steps + 1):
        if step % 25 == 0:
            current = {
                "step": step,
                "train_accuracy": accuracy(parameter, data[0], data[1], template, spec),
                "trigger_accuracy": accuracy(parameter, data[2], data[3], template, spec),
                "certification_accuracy": accuracy(parameter, data[4], data[5], template, spec),
            }
            eligible = [g for g in GATES if current["trigger_accuracy"] >= g - 0.10
                        and current["certification_accuracy"] < g]
            current["eligible_gates"] = eligible
            if eligible:
                phase = time.perf_counter()
                try:
                    path = build_streaming_transformer_centerline(config, template, spec, data[0], data[1],
                                                                parameter, velocity, maximum_horizon=HORIZON, sweeps=4)
                    with torch.no_grad():
                        counts = [int((logits(p[:parameter.numel()], data[4], template, spec).argmax(1) == data[5]).sum())
                                  for p in path["center"]]
                    current["clock_counts"] = counts
                    current["clock_events"] = {str(g): first(counts, int(np.ceil(g * len(data[4])))) for g in eligible}
                    selected = next((g for g in eligible if current["clock_events"][str(g)] is not None
                                     and current["clock_events"][str(g)] > 0), None)
                    current["clock_seconds"] = time.perf_counter() - phase
                except (RuntimeError, FloatingPointError, OverflowError) as error:
                    current["clock_failure"] = f"{type(error).__name__}: {error}"
                    selected = None
                if selected is not None:
                    rows.append(current)
                    with (OUT / "anchor.npz").open("xb") as stream:
                        np.savez(stream, parameter=parameter.numpy(), velocity=velocity.numpy())
                    save_json(OUT / "candidate.json", {
                        "scope": "development candidate; future continuation unopened", "config": asdict(config),
                        "anchor": step, "threshold": selected,
                        "predicted_offset": current["clock_events"][str(selected)],
                        "reference_scaled_sha256": path["centerline_sha256"],
                        "anchor_sha256": digest(OUT / "anchor.npz"), "sources": sources,
                        "elapsed_seconds": time.perf_counter() - started, "history": rows,
                    })
                    save_json(OUT / f"inspection_{step:05d}.json", current)
                    print(json.dumps({"status": "candidate selected; training stopped before continuation",
                                      "anchor": step, "threshold": selected,
                                      "predicted_offset": current["clock_events"][str(selected)]}), flush=True)
                    return
            rows.append(current)
            save_json(OUT / f"inspection_{step:05d}.json", current)
            print(json.dumps({k: v for k,v in current.items() if k != "clock_counts"}), flush=True)
        if step == config.steps:
            break
        velocity = config.momentum * velocity + gradient(parameter, data[0], data[1], template, spec, config)
        parameter = parameter - config.learning_rate * velocity
        if not bool(torch.isfinite(parameter).all()):
            save_json(OUT / "terminal.json", {"status": "nonfinite training", "step": step+1, "history": rows})
            return
    save_json(OUT / "terminal.json", {"status": "no candidate by frozen maximum step", "history": rows,
                                      "elapsed_seconds": time.perf_counter() - started})


if __name__ == "__main__":
    main()
