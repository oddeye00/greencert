"""Physical-anchor event assembly with explicit mixed-runtime Green evidence.

The response, neural derivative/output adapters, scalar closure and event
rule are unchanged. Only the complete-family Green evidence route differs.
This function returns a checked enclosure, never an issued disposition or
permission to inspect the future. A saved response profile is not an input.
"""
from dataclasses import asdict

from bound_row_evidence import authenticate_bound_row
from file_backed_window_assembly import _validate, fingerprint
from green_family_evidence import canonical_sha, require
from known_anchor_window_assembly import response_from_fresh_audit
from reference_margin_evidence import authenticate_reference_window, intersect_with_derivative_row
from runtime_green_evidence import authenticate_runtime_green_family
from verified_artifact_io import EvidencePending, IntegrityError, require_sha256
from window_event_assembly import assemble

SCHEMA = "runtime_anchor_window_assembly_v1"
SCOPE = "outward validated-producer arithmetic conditional on the original ideal-Gaussian projection event"


def assemble_runtime_anchor_evidence(reader, request, *, executions, sequence_plan,
                                    fresh_response_audit, method_sha256, required_audit_sources,
                                    additional_forbidden_paths, progress=None):
    try:
        _validate(reader, request)
        require_sha256(method_sha256)
        require(callable(fresh_response_audit), "live physical-anchor response audit required")
        require(isinstance(executions, dict) and executions and isinstance(sequence_plan, tuple),
                "explicit mixed-runtime execution plan required")
        require(isinstance(additional_forbidden_paths, tuple) and additional_forbidden_paths,
                "outcome continuation barrier required")
        plan_fingerprint = canonical_sha({"executions": executions, "sequence_plan": sequence_plan})
    except (KeyError, TypeError, ValueError, OverflowError) as error:
        raise IntegrityError("invalid runtime-anchor window request") from error
    request_fingerprint = fingerprint(request)
    forbidden = request.forbidden_outcome_files + additional_forbidden_paths
    def barrier():
        require(all(not reader.resolve(path).exists() for path in forbidden), "future barrier opened")
    barrier()
    missing, provenance, rows = [], {}, {}
    def attempt(name, operation):
        barrier()
        if progress:
            progress(name, "started")
        try:
            value = operation()
        except EvidencePending as error:
            missing.append({"component": name, "reason": str(error)})
            if progress:
                progress(name, "pending")
            return None
        provenance[name] = value["provenance"]
        if progress:
            progress(name, "authenticated")
        return value
    response = attempt("known_anchor_response", lambda: response_from_fresh_audit(reader, request,
        fresh_response_audit(), method_sha256=method_sha256, required_audit_sources=required_audit_sources))
    margins = attempt("reference_margins", lambda: authenticate_reference_window(reader,
        request.reference_margin_folder, identity=request.identity, evaluation=request.evaluation_examples,
        example_ids=request.example_ids, classes=request.classes, normalization_eps=request.normalization_eps))
    for location in request.row_plan:
        row = attempt(f"derivative_row_{location.step:03d}", lambda: authenticate_bound_row(reader, location.folder,
            identity=request.identity, step=location.step, domain=request.domain, producer=location.producer,
            training_examples=request.training_examples, evaluation_examples=request.evaluation_examples,
            example_ids=request.example_ids))
        if row is not None:
            rows[location.step] = row
    green = attempt("runtime_green", lambda: authenticate_runtime_green_family(reader,
        origin_folder=request.green_folder, origin_method_sha256=request.green_method_sha256,
        executions=executions, sequence_plan=sequence_plan, identity=request.identity, power=request.power,
        original_probe_hashes=request.original_probe_hashes, failure_probability=request.failure_probability,
        learning_rate=request.learning_rate, momentum=request.momentum, forbidden_paths=forbidden))
    barrier()
    require(fingerprint(request) == request_fingerprint, "window request changed during assembly")
    require(canonical_sha({"executions": executions, "sequence_plan": sequence_plan}) == plan_fingerprint,
            "execution plan changed during assembly")
    for path, value in tuple(reader.observed.items()):
        reader.check_blob(path, value)
    result = {"schema": SCHEMA, "scope": SCOPE, "request_sha256": request_fingerprint,
        "execution_plan_sha256": plan_fingerprint, "identity": asdict(request.identity),
        "method_sha256": method_sha256,
        "event_definition": {"target": request.target, "persistence": request.persistence},
        "status": "pending", "missing": missing, "authenticated_components": list(provenance),
        "authenticated_derivative_steps": sorted(rows), "provenance": provenance, "assembly": None,
        "original_issuance_policy_changed": False, "original_records_relabelled": False,
        "event_certificate_issued": False, "construction_disposition_sealed": False,
        "future_outcome_access": False, "outcome_join_authorized": False,
        "conditional_on_validated_producers": True, "neural_kernels_replayed": False}
    if missing:
        return result
    if green["bound"] is None:
        return {**result, "status": "no_finite_green_bound_at_requested_power"}
    output, drift = [margins["anchor"]], []
    for step in range(1, request.identity.horizon+1):
        output.append(intersect_with_derivative_row(margins["rows"][step], rows[step]["output"]))
        if step < request.identity.horizon:
            require(rows[step]["drift"] is not None, "missing authenticated interior drift")
            drift.append(rows[step]["drift"])
        else:
            require(rows[step]["drift"] is None, "unexpected terminal drift")
    assembled = assemble(identity=request.identity, training_count=len(request.training_examples),
        example_ids=request.example_ids, domain=request.domain, drift_rows=drift, output_rows=output,
        response=response["bound"], green=green["bound"], target=request.target,
        persistence=request.persistence, precision_bits=256)
    require(assembled["inputs_compatible"], "runtime-anchor scalar contract differs: " + str(assembled.get("reason")))
    require(assembled["probability_scope"] == "ideal_gaussian_probes" and
            assembled["failure_probability"] == request.failure_probability,
            "original Gaussian event budget changed")
    require(assembled["state_closure"]["first_injection_error"] == response["bound"].first_injection_error_upper,
            "physical encoding tail omitted")
    barrier()
    return {**result, "assembly": assembled, "status": "enclosure_available_for_separate_disposition"
            if assembled["bracket"] is not None else "assembly_abstention"}
