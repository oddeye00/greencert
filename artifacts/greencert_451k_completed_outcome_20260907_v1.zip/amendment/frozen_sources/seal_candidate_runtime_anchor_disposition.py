"""Fresh-join terminal gate for the explicit-runtime physical-anchor route.

The configured execution supplies q1 only. Original powers [1,2] remain the
decision budget: a q1 failure is nonterminal, never premature abstention.
No mode loads a saved numerical result for publication or opens the future.
"""
import argparse
import ast
from dataclasses import asdict
import json
from pathlib import Path
from types import SimpleNamespace

import audit_candidate_runtime_anchor_window as assembly
from green_family_evidence import canonical_sha, require
from registered_outcome_continuation import publish_json, utc
from runtime_anchor_disposition import POLICY_SCHEMA, SCOPE, primitive, plan_for, publish_fresh, authenticate_record
from verified_artifact_io import EvidenceReader, EvidencePending, require_sha256
from window_disposition import family_fingerprint

ROOT, REL, CON = assembly.ROOT, assembly.REL, assembly.CON
POLICY = CON / "runtime_anchor_disposition_policy.json"
DISPOSITION = CON / "runtime_anchor_window_disposition.json"
DOCUMENT = Path("RUNTIME_ANCHOR_DISPOSITION_PROTOCOL.md")
ASSEMBLY_SHA = "f01d075d7daeeeb47479a3e39b44b3e722b734be1e0c25ff48b2e67d4c1f18c3"
REGRESSION = Path("results/runtime_anchor_disposition_contract_20260907.json")


def sources():
    pending = [ROOT / "scripts" / name for name in (
        "seal_candidate_runtime_anchor_disposition.py", "test_runtime_anchor_disposition.py")]
    result = {}
    while pending:
        path = pending.pop()
        if path.name in result:
            continue
        result[path.name] = assembly.sha(path)
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
            names = [v.name for v in node.names] if isinstance(node, ast.Import) else (
                [node.module] if isinstance(node, ast.ImportFrom) and node.module else [])
            for name in names:
                candidate = ROOT / "scripts" / (name.replace(".", "/") + ".py")
                if candidate.is_file() and candidate.name not in result:
                    pending.append(candidate)
    return result


def barrier(reader, request):
    # A read-only audit must remain possible after this gate's own record
    # exists. Competing dispositions and all optimizer futures stay forbidden.
    for path in (*request.forbidden_outcome_files, REL / "reveal.json", REL / "registered_outcome_run",
                 CON / "outward_window_disposition.json", CON / "known_anchor_window_disposition.json"):
        require(not reader.resolve(path).exists(), "future or competing disposition barrier opened")


def check_assembly_parent(reader, request, registry, sequences, common):
    barrier(reader, request)
    assembly.check_parents(reader, request, registry, sequences, common)
    parent, _ = reader.read_json(assembly.POLICY, ASSEMBLY_SHA)
    # Do not call assembly.expected_policy after publication: its construction
    # barrier correctly refuses our own disposition. Authenticate the same
    # pinned bytes, sources, parents and request without weakening that barrier.
    require(parent["schema"] == "candidate_runtime_anchor_window_policy_v1" and parent["scope"] == SCOPE and
            parent["window_family_sha256"] == family_fingerprint(request) and
            parent["request"] == primitive(asdict(request)) and
            parent["homogeneous_method_sha256"] == assembly.HOMOGENEOUS_SHA and
            parent["original_anchor_policy_sha256"] == assembly.ANCHOR_POLICY_SHA and
            parent["runtime_green_policy_sha256"] == assembly.GREEN_POLICY_SHA and
            parent["common_operator_sha256"] == common and parent["sources"] == assembly.source_hashes() and
            parent["execution_registry"] == primitive(registry) and parent["sequence_plan"] == primitive(sequences) and
            parent["power"] == request.power == 1 and parent["failure_probability"] == request.failure_probability and
            all(parent[key] is False for key in ("original_numerical_methods_changed", "original_event_rule_changed",
                "original_records_relabelled", "event_issuance_authorized", "outcome_join_authorized", "future_outcome_access")),
            "foreign or changed runtime assembly parent")
    reader.check_sources(parent, required_names=frozenset(assembly.source_hashes()))
    reader.check_blob(assembly.PROTOCOL, parent["protocol_sha256"])
    require(set(parent["regression_reports"]) == {str(assembly.JOIN_TEST), str(assembly.POLICY_TEST)},
            "assembly regression roles differ")
    for path, digest in parent["regression_reports"].items():
        report, _ = reader.read_json(path, digest)
        require(report["status"] == "PASS", "assembly regression not passed")
        for rel, source_sha in report["sources"].items():
            reader.check_blob(rel, source_sha)
    original, _ = reader.read_json(assembly.original_anchor.POLICY, assembly.ANCHOR_POLICY_SHA)
    require(original["allowed_powers"] == [1, 2], "original decision budget changed")
    return parent, original["allowed_powers"]


def expected_policy(reader, request, registry, sequences, common):
    parent, powers = check_assembly_parent(reader, request, registry, sequences, common)
    regression, regression_sha = reader.read_json(REGRESSION)
    require(regression["status"] == "PASS" and regression["neural_certificates_issued"] == 0,
            "terminal contract report missing")
    for rel, digest in regression["sources"].items():
        reader.check_blob(rel, digest)
    return primitive({"schema": POLICY_SCHEMA, "scope": SCOPE, "sources": sources(),
        "protocol_document_sha256": assembly.sha(reader.resolve(DOCUMENT)),
        "regression_report": str(REGRESSION), "regression_sha256": regression_sha,
        "window_family_sha256": family_fingerprint(request), "assembly_policy_sha256": ASSEMBLY_SHA,
        "homogeneous_method_sha256": assembly.HOMOGENEOUS_SHA,
        "common_operator_sha256": common, "execution_registry": registry, "sequence_plan": sequences,
        "execution_plan_sha256": canonical_sha({"executions": registry, "sequence_plan": sequences}),
        "allowed_powers": powers, "configured_execution_power": 1,
        "failure_probability": request.failure_probability, "terminal_disposition_authorized": True,
        "outcome_join_authorized": False, "future_outcome_access": False, "original_issuance_policy_changed": False,
        "selection_scope": "outcome-sealed execution composition after partial construction; not fresh confirmation",
        "terminal_rule": "fresh complete enclosure may issue; q1 failure remains nonterminal under original [1,2] budget"})


def context(reader):
    request, provenance, registry, sequences, common = assembly.runtime_green.context(reader)
    barrier(reader, request)
    return request, provenance, registry, sequences, common


def check_policy(reader, request, registry, sequences, common, expected_sha):
    saved, _ = reader.read_json(POLICY, require_sha256(expected_sha))
    require(saved == expected_policy(reader, request, registry, sequences, common), "terminal policy or code changed")
    return saved


def run(args):
    reader = EvidenceReader(ROOT)
    request, provenance, registry, sequences, common = context(reader)
    if args.mode == "freeze-policy":
        require(not reader.resolve(DISPOSITION).exists() and not reader.resolve(POLICY).exists(),
                "terminal policy or disposition already reserved")
        payload = expected_policy(reader, request, registry, sequences, common)
        barrier(reader, request)
        digest = publish_json(reader.resolve(POLICY), payload)
        return {"status": "runtime_terminal_policy_frozen", "policy_sha256": digest,
            "source_count": len(payload["sources"]), "event_certificate_issued": False,
            "outcome_join_authorized": False, "future_outcome_access": False}
    recheck = lambda: check_policy(reader, request, registry, sequences, common, args.policy_sha256)
    policy = recheck()
    if args.mode == "audit-record":
        return authenticate_record(reader, request=request, disposition_path=DISPOSITION,
            disposition_sha256=args.disposition_sha256, policy_path=POLICY, policy_sha256=args.policy_sha256,
            recheck_policy=recheck, barrier=lambda: barrier(reader, request))
    require(not reader.resolve(DISPOSITION).exists(), "terminal record exists; no duplicate construction")
    missing = []
    for path in assembly.completion_markers(request, sequences):
        try:
            reader.read_json(path, allow_in_progress=True)
        except EvidencePending as error:
            missing.append({"path": str(path), "reason": str(error)})
    barrier(reader, request)
    if missing or args.mode == "check":
        return {"status": "pending_markers" if missing else "completion_markers_present", "missing": missing,
            "missing_count": len(missing), "numerical_verification_performed": False,
            "event_certificate_issued": False, "outcome_join_authorized": False, "future_outcome_access": False}
    require(args.mode == "commit" and assembly.memory_available_mib() >= 1536,
            "fresh terminal verification requires commit mode and 1536MiB free")
    result = assembly.assemble_runtime_anchor_evidence(reader, request, executions=registry, sequence_plan=sequences,
        fresh_response_audit=lambda: assembly.response_audit.audit(SimpleNamespace(method_sha256=assembly.HOMOGENEOUS_SHA)),
        method_sha256=assembly.HOMOGENEOUS_SHA, required_audit_sources=frozenset(assembly.response_audit.NAMES),
        additional_forbidden_paths=assembly.forbidden_paths(request),
        progress=lambda name, status: print(json.dumps({"component": name, "status": status}), flush=True))
    plan = plan_for(request, result, policy)
    recheck()
    barrier(reader, request)
    for rel, digest in tuple(reader.observed.items()):
        reader.check_blob(rel, digest)
    audit = {"utc": utc(), "policy_sha256": args.policy_sha256, "request": asdict(request),
        "context": provenance, "result": result, "plan": plan, "observed_artifact_hashes": dict(reader.observed)}
    path = CON / "runtime_anchor_final_verifications" / (audit["utc"].replace(":", "").replace("-", "") + ".json")
    audit_sha = publish_json(reader.resolve(path), primitive(audit))
    publication = publish_fresh(reader, request=request, result=result, audit_path=path, audit_sha256=audit_sha,
        policy_path=POLICY, policy_sha256=args.policy_sha256, disposition_path=DISPOSITION,
        recheck_policy=recheck, barrier=lambda: barrier(reader, request))
    return {**publication, "audit_path": str(path), "audit_sha256": audit_sha, "future_outcome_access": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("freeze-policy", "check", "commit", "audit-record"), default="check")
    parser.add_argument("--policy-sha256")
    parser.add_argument("--disposition-sha256")
    print(json.dumps(run(parser.parse_args()), indent=2))
