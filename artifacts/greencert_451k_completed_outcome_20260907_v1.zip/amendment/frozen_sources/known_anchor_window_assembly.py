"""Separate full-window join for a freshly audited physical-anchor response.

This module cannot promote a saved audit flag or authorize an outcome join.
The production caller must invoke the complete combined-response auditor in
this run. All other evidence uses the original window, operator and event.
The resulting enclosure is an input to a separately declared disposition,
not an issued certificate and not a change to the original issuance policy.
"""
from dataclasses import asdict

from bound_row_evidence import authenticate_bound_row
from file_backed_window_assembly import _validate, fingerprint
from green_family_evidence import authenticate_green_family, number, require
from reference_margin_evidence import authenticate_reference_window, intersect_with_derivative_row
from verified_artifact_io import EvidencePending, IntegrityError, require_sha256
from window_event_assembly import ResponseBound, assemble

SCHEMA = "known_anchor_window_assembly_v1"
SCOPE = "outward validated-producer arithmetic conditional on the original ideal-Gaussian projection event"


def response_from_fresh_audit(reader, request, record, *, method_sha256, required_audit_sources):
    """Typed bridge with explicit fresh-audit and producer obligations.

    Only the production driver's live audit supplies record. Checks below
    bind that result to the same files and request; they are not a substitute
    for running the numerical audit and do not make arbitrary JSON truthful.
    """
    require_sha256(method_sha256)
    try:
        require(record["status"] == "combined_response_audited_not_event_certified" and
                record["method_sha256"] == method_sha256 and
                record["physical_encoding_replayed"] is True and record["neural_hvps_replayed"] is False and
                record["original_issuance_policy_changed"] is False and
                record["event_certificate_issued"] is False and record["future_outcome_access"] is False,
                "combined response scope or execution method differs")
        require_sha256(record["construction_sha256"])
        reader.check_sources(record, required_names=required_audit_sources)
        artifacts = record["observed_artifact_hashes"]
        require(isinstance(artifacts, dict) and artifacts, "missing fresh response artifact bindings")
        for path, sha in artifacts.items():
            reader.check_blob(path, sha)
        profile = record["profile"]
        require(profile["identity"] == asdict(request.identity), "combined response identity differs")
        p = profile["parameter_norms"]
        require(isinstance(p, tuple) and len(p) == request.identity.horizon+1 and p[0] == 0.,
                "fresh complete combined response required")
        p = tuple(number(v, "combined parameter norm") for v in p)
        tau = number(profile["residual_upper"], "combined recurrence residual")
        tail = number(profile["encoding_injection_tail_upper"], "unrepresented physical anchor injection")
        number(profile["original_first_injection_upper"], "original physical anchor injection")
        require_sha256(profile["original_summary_sha256"])
        require_sha256(profile["homogeneous_summary_sha256"])
        # This is an explicit new-route conversion. The original response
        # and its nonzero gamma are not modified or relabeled.
        bound = ResponseBound(request.identity, p, tau, tail, True, "outward")
        return {"bound": bound, "provenance": {"method_sha256": method_sha256,
            "construction_sha256": record["construction_sha256"], "profile": profile,
            "physical_encoding_replayed": True, "neural_hvps_replayed": False,
            "sources": record["sources"], "response_artifact_count": len(artifacts)}}
    except (KeyError, TypeError, OverflowError) as error:
        raise IntegrityError("malformed fresh combined response audit") from error


def assemble_known_anchor_evidence(reader, request, *, fresh_response_audit, method_sha256,
                                  required_audit_sources, additional_forbidden_paths, progress=None):
    """Re-audit the response, join every original bound, then evaluate closure.

    Missing evidence is pending, never a smaller-window enclosure. Integrity
    failures raise. The callback is a code-level testing seam; the production
    CLI always uses the actual combined-response auditor, never a saved file.
    """
    try:
        _validate(reader, request)
        require_sha256(method_sha256)
        require(isinstance(additional_forbidden_paths, tuple) and additional_forbidden_paths,
                "separate outcome-continuation barrier required")
        require(callable(fresh_response_audit), "live combined-response audit required")
    except (KeyError, TypeError, OverflowError) as error:
        raise IntegrityError("malformed known-anchor window request") from error
    original_request = fingerprint(request)
    forbidden = request.forbidden_outcome_files + additional_forbidden_paths
    def barrier():
        require(all(not reader.resolve(path).exists() for path in forbidden), "future barrier open")
    barrier()
    missing, provenance, rows = [], {}, {}
    def attempt(name, operation):
        barrier()
        if progress:
            progress(name, "started")
        try:
            result = operation()
        except EvidencePending as error:
            missing.append({"component": name, "reason": str(error)})
            if progress:
                progress(name, "pending")
            return None
        provenance[name] = result["provenance"]
        if progress:
            progress(name, "authenticated")
        return result
    response = attempt("known_anchor_response", lambda: response_from_fresh_audit(reader, request,
        fresh_response_audit(), method_sha256=method_sha256, required_audit_sources=required_audit_sources))
    margins = attempt("reference_margins", lambda: authenticate_reference_window(reader,
        request.reference_margin_folder, identity=request.identity, evaluation=request.evaluation_examples,
        example_ids=request.example_ids, classes=request.classes, normalization_eps=request.normalization_eps))
    for location in request.row_plan:
        row = attempt(f"derivative_row_{location.step:03d}", lambda: authenticate_bound_row(reader, location.folder,
            identity=request.identity, step=location.step, domain=request.domain, producer=location.producer,
            training_examples=request.training_examples, evaluation_examples=request.evaluation_examples,
            example_ids=request.example_ids))
        if row is not None:
            rows[location.step] = row
    green = attempt("green", lambda: authenticate_green_family(reader, request.green_folder,
        identity=request.identity, power=request.power, method_sha256=request.green_method_sha256,
        original_probe_hashes=request.original_probe_hashes, failure_probability=request.failure_probability,
        learning_rate=request.learning_rate, momentum=request.momentum))
    barrier()
    require(fingerprint(request) == original_request, "window request changed during known-anchor assembly")
    # Include response-audit artifacts in the same final immutability check.
    for path, sha in tuple(reader.observed.items()):
        reader.check_blob(path, sha)
    result = {"schema": SCHEMA, "scope": SCOPE, "request_sha256": original_request,
        "identity": asdict(request.identity), "method_sha256": method_sha256,
        "event_definition": {"target": request.target, "persistence": request.persistence},
        "status": "pending", "missing": missing, "authenticated_components": list(provenance),
        "authenticated_derivative_steps": sorted(rows), "provenance": provenance,
        "assembly": None, "original_issuance_policy_changed": False,
        "event_certificate_issued": False, "construction_disposition_sealed": False,
        "future_outcome_access": False, "outcome_join_authorized": False,
        "conditional_on_validated_producers": True, "neural_kernels_replayed": False}
    if missing:
        return result
    if green["bound"] is None:
        return {**result, "status": "no_finite_green_bound_at_requested_power"}
    output, drift = [margins["anchor"]], []
    for step in range(1, request.identity.horizon+1):
        output.append(intersect_with_derivative_row(margins["rows"][step], rows[step]["output"]))
        if step < request.identity.horizon:
            require(rows[step]["drift"] is not None, "missing authenticated interior drift")
            drift.append(rows[step]["drift"])
        else:
            require(rows[step]["drift"] is None, "unexpected terminal drift")
    assembled = assemble(identity=request.identity, training_count=len(request.training_examples),
        example_ids=request.example_ids, domain=request.domain, drift_rows=drift, output_rows=output,
        response=response["bound"], green=green["bound"], target=request.target,
        persistence=request.persistence, precision_bits=256)
    require(assembled["inputs_compatible"], "known-anchor scalar contract differs: " + str(assembled.get("reason")))
    require(assembled["probability_scope"] == "ideal_gaussian_probes" and
            assembled["failure_probability"] == request.failure_probability,
            "known-anchor route must reuse the original Green probability event")
    require(assembled["state_closure"]["first_injection_error"] == response["bound"].first_injection_error_upper,
            "physical encoding tail omitted from closure")
    barrier()
    return {**result, "assembly": assembled, "status": "enclosure_available_for_separate_disposition"
            if assembled["bracket"] is not None else "assembly_abstention"}
