"""Third frozen development trajectory; stop before selected candidate outcomes."""
from dataclasses import asdict, replace
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

import select_larger_transformer_second_pass as original

ROOT = original.ROOT
OUT = ROOT / "results/larger_transformer_third_pass"
RECOVERY = OUT / "recovery"


def comparable(record):
    return {key: value for key, value in record.items() if key != "clock_seconds"}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / "candidate.json").exists() or (OUT / "terminal.json").exists():
        raise RuntimeError("selection already terminal; do not resume training")
    config = replace(original.configuration("four_block_layernorm"), seed=94003,
                     learning_rate=0.003, weight_decay=0.01, steps=12000)
    protocol_path = ROOT / "LARGER_TRANSFORMER_THIRD_PASS_PROTOCOL.md"
    if not (OUT / "method.json").exists():
        names = ("run_larger_transformer_third_pass.py", "select_larger_transformer_second_pass.py",
                 "larger_transformer_development.py", "streaming_variational_centerline.py",
                 "transformer_hvp_grokking.py", "transformer_modal_forecast.py")
        original.save_json(OUT / "method.json", {
            "config": asdict(config), "sources": {name: original.digest(ROOT / "scripts" / name) for name in names},
            "parameter_count": 451008, "horizon": original.HORIZON, "persistence": original.PERSISTENCE,
            "gates": original.GATES, "protocol_sha256": original.digest(protocol_path)})
    method = json.loads((OUT / "method.json").read_text())
    for name, expected in method["sources"].items():
        assert original.digest(ROOT / "scripts" / name) == expected, name
    assert original.digest(protocol_path) == method["protocol_sha256"]
    assert asdict(config) == method["config"]
    assert [original.HORIZON, original.PERSISTENCE, list(original.GATES)] == [method["horizon"], method["persistence"], method["gates"]]
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    torch.backends.mha.set_fastpath_enabled(False)
    torch.use_deterministic_algorithms(True)
    template = original.make_template(config)
    spec = original.flat_spec(template)
    data = original.make_disjoint_split(config)
    parameter = original.flatten_parameters(template)
    assert parameter.numel() == method["parameter_count"]
    velocity = torch.zeros_like(parameter)
    RECOVERY.mkdir(exist_ok=True)
    driver_hash = original.digest(Path(__file__))
    started = time.perf_counter()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    inspections = {int(path.stem.split("_")[1]): json.loads(path.read_text())
                   for path in OUT.glob("inspection_*.json")}
    if inspections:
        assert sorted(inspections) == list(range(0, max(inspections)+1, 25))
    original.save_json(RECOVERY / f"execution_{stamp}.json", {
        "started_utc": stamp, "driver_sha256": driver_hash,
        "protocol_sha256": original.digest(protocol_path),
        "method_sha256": original.digest(OUT / "method.json"),
        "existing_inspections": len(inspections), "latest_inspection": max(inspections, default=-1),
        "pid": os.getpid(), "future_outcome_access": False,
    })
    start_step, rows = 0, []
    pointer_path = RECOVERY / "latest.json"
    if pointer_path.exists():
        pointer = json.loads(pointer_path.read_text())
        assert pointer["driver_sha256"] == driver_hash
        assert pointer["method_sha256"] == original.digest(OUT / "method.json")
        checkpoint = RECOVERY / pointer["file"]
        assert original.digest(checkpoint) == pointer["sha256"]
        assert original.digest(OUT / f"inspection_{pointer['step']:05d}.json") == pointer["inspection_sha256"]
        with np.load(checkpoint) as saved:
            parameter = torch.tensor(saved["parameter"])
            velocity = torch.tensor(saved["velocity"])
            assert int(saved["step"]) == pointer["step"]
        start_step = pointer["step"]
        rows = [inspections[j] for j in sorted(inspections) if j < start_step]

    replayed = []
    for step in range(start_step, config.steps + 1):
        if step % 25 == 0:
            current = {
                "step": step,
                "train_accuracy": original.accuracy(parameter, data[0], data[1], template, spec),
                "trigger_accuracy": original.accuracy(parameter, data[2], data[3], template, spec),
                "certification_accuracy": original.accuracy(parameter, data[4], data[5], template, spec),
            }
            eligible = [gate for gate in original.GATES if current["trigger_accuracy"] >= gate - 0.10
                        and current["certification_accuracy"] < gate]
            current["eligible_gates"] = eligible
            selected = None
            if eligible:
                phase = time.perf_counter()
                try:
                    path = original.build_streaming_transformer_centerline(
                        config, template, spec, data[0], data[1], parameter, velocity,
                        maximum_horizon=original.HORIZON, sweeps=4)
                    with torch.no_grad():
                        counts = [int((original.logits(p[:parameter.numel()], data[4], template, spec).argmax(1)
                                       == data[5]).sum()) for p in path["center"]]
                    current["clock_counts"] = counts
                    current["clock_events"] = {str(g): original.first(counts, int(np.ceil(g * len(data[4]))))
                                               for g in eligible}
                    selected = next((g for g in eligible if current["clock_events"][str(g)] is not None
                                     and current["clock_events"][str(g)] > 0), None)
                    current["clock_seconds"] = time.perf_counter() - phase
                except (RuntimeError, FloatingPointError, OverflowError) as error:
                    current["clock_failure"] = f"{type(error).__name__}: {error}"
                    selected = None
            if step in inspections:
                if comparable(current) != comparable(inspections[step]):
                    original.save_json(RECOVERY / f"replay_mismatch_{stamp}_{step}.json", {
                        "expected": inspections[step], "observed": current})
                    raise RuntimeError(f"deterministic inspection replay differs at {step}")
                replayed.append(step)
            else:
                original.save_json(OUT / f"inspection_{step:05d}.json", current)
            rows.append(current)
            if selected is not None:
                with (OUT / "anchor.npz").open("xb") as stream:
                    np.savez(stream, parameter=parameter.numpy(), velocity=velocity.numpy())
                original.save_json(OUT / "candidate.json", {
                    "scope": "development candidate; future continuation unopened",
                    "config": asdict(config), "anchor": step, "threshold": selected,
                    "predicted_offset": current["clock_events"][str(selected)],
                    "reference_scaled_sha256": path["centerline_sha256"],
                    "anchor_sha256": original.digest(OUT / "anchor.npz"), "sources": method["sources"],
                    "recovery_driver_sha256": driver_hash,
                    "execution_seconds": time.perf_counter() - started, "history": rows,
                })
                print(json.dumps({"status": "candidate selected; STOP before continuation", "anchor": step,
                                  "threshold": selected, "predicted_offset": current["clock_events"][str(selected)]}), flush=True)
                return
            # Alternate two files: until the pointer is replaced, its old file
            # is untouched. A stopped write therefore leaves one valid state.
            previous_slot = json.loads(pointer_path.read_text()).get("slot", 0) if pointer_path.exists() else 0
            slot = 1-previous_slot
            filename = f"checkpoint_{slot}.npz"
            temporary = RECOVERY / (filename + ".tmp")
            with temporary.open("wb") as stream:
                np.savez(stream, step=step, parameter=parameter.numpy(), velocity=velocity.numpy())
            temporary.replace(RECOVERY / filename)
            pointer = {"file": filename, "slot": slot, "sha256": original.digest(RECOVERY / filename), "step": step,
                       "driver_sha256": driver_hash, "method_sha256": original.digest(OUT / "method.json"),
                       "inspection_sha256": original.digest(OUT / f"inspection_{step:05d}.json")}
            pointer_temp = RECOVERY / "latest.json.tmp"
            pointer_temp.write_text(json.dumps(pointer, indent=2) + "\n", encoding="utf-8")
            pointer_temp.replace(pointer_path)
            if inspections and step == max(inspections):
                original.save_json(RECOVERY / f"replay_verified_{stamp}.json", {
                    "replayed_steps": replayed, "all_compared_inspections_equal": True,
                    "previous_latest_inspection": step, "driver_sha256": driver_hash})
            print(json.dumps({k: v for k, v in current.items() if k != "clock_counts"}), flush=True)
        if step == config.steps:
            break
        velocity = config.momentum * velocity + original.gradient(parameter, data[0], data[1], template, spec, config)
        parameter = parameter - config.learning_rate * velocity
        if not bool(torch.isfinite(parameter).all()):
            original.save_json(OUT / "terminal.json", {"status": "nonfinite training", "step": step + 1, "history": rows})
            return
    original.save_json(OUT / "terminal.json", {
        "status": "no candidate by frozen maximum step", "history": rows,
        "recovery_driver_sha256": driver_hash, "execution_seconds": time.perf_counter() - started})


if __name__ == "__main__":
    main()
