"""Outcome-barrier development runner for the four-block LayerNorm experiment.

Train, construct, and reveal are separate durable phases. No constructor reads
a future optimizer continuation. This development study never modifies a
historical confirmation record.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import platform
import time

import numpy as np
import torch

from transformer_hvp_grokking import (
    TransformerConfig, accuracy, flat_spec, flatten_parameters, gradient,
    logits, make_disjoint_split, make_template,
)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/larger_transformer_development"
ANCHORS = (100, 300, 600, 1000, 2000)
HORIZON, PERSISTENCE = 24, 5
GATES = (0.6, 0.8, 0.9)
DOMAIN = 1e-8
DELTA = 1e-7


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def configuration(model: str) -> TransformerConfig:
    large = model == "four_block_layernorm"
    return TransformerConfig(
        modulus=17, model_dim=96 if large else 32,
        hidden_dim=384 if large else 128, heads=4, depth=4 if large else 1,
        train_fraction=0.6, learning_rate=0.01, momentum=0.9,
        weight_decay=0.01, steps=2000, seed=94001, threads=4,
        dtype="float64", normalization="layernorm" if large else "none",
    )


def setup(model: str):
    config = configuration(model)
    torch.set_num_threads(config.threads)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    torch.use_deterministic_algorithms(True)
    # Disable eval-only fused encoder paths: the same differentiable math path
    # must implement training, HVPs, and checkpoint output evaluations.
    torch.backends.mha.set_fastpath_enabled(False)
    template = make_template(config)
    spec = flat_spec(template)
    return config, template, spec, make_disjoint_split(config)


def location(model: str, anchor: int) -> Path:
    if anchor not in ANCHORS:
        raise ValueError("anchor is outside the recorded development grid")
    return OUT / model / f"anchor_{anchor:04d}"


def ensure_protocol(model: str, config, spec, data) -> dict:
    folder = OUT / model
    folder.mkdir(parents=True, exist_ok=True)
    protocol = ROOT / "LARGER_TRANSFORMER_DEVELOPMENT_PROTOCOL.md"
    path = folder / "training_spec.json"
    identity = {
        "config": asdict(config), "parameter_count": sum(spec.sizes),
        "parameter_names": list(spec.names), "protocol_sha256": digest(protocol),
        "split_sha256": hashlib.sha256(b"".join(x.numpy().tobytes() for x in data)).hexdigest(),
        "training_module_sha256": digest(ROOT / "scripts/transformer_hvp_grokking.py"),
        "torch": torch.__version__, "python": platform.python_version(),
        "scope": "development; no confirmation count changes",
    }
    if path.exists():
        if read_json(path) != identity:
            raise RuntimeError("training configuration/source/split changed")
    else:
        save_json(path, identity)
    return identity


def train_to_anchor(model: str, anchor: int) -> dict:
    folder = location(model, anchor)
    record = folder / "anchor.json"
    if record.exists():
        saved = read_json(record)
        if digest(folder / "anchor.npz") != saved["checkpoint_sha256"]:
            raise RuntimeError("anchor checksum mismatch")
        return saved
    config, template, spec, data = setup(model)
    identity = ensure_protocol(model, config, spec, data)
    index = ANCHORS.index(anchor)
    if index:
        previous = location(model, ANCHORS[index - 1])
        reveal = read_json(previous / "reveal.json")
        checkpoint = previous / "continued.npz"
        if digest(checkpoint) != reveal["continued_sha256"]:
            raise RuntimeError("continuation checksum mismatch")
        arrays = np.load(checkpoint)
        parameter, velocity = (torch.from_numpy(arrays[k].copy()) for k in ("parameter", "velocity"))
        start = ANCHORS[index - 1] + HORIZON
    else:
        parameter = flatten_parameters(template)
        velocity = torch.zeros_like(parameter)
        start = 0
    rows = []
    started = time.perf_counter()
    for step in range(start, anchor):
        velocity = config.momentum * velocity + gradient(parameter, data[0], data[1], template, spec, config)
        parameter = parameter - config.learning_rate * velocity
        if not torch.isfinite(parameter).all():
            raise FloatingPointError(f"training is nonfinite at {step + 1}")
        if (step + 1) % 50 == 0 or step + 1 == anchor:
            row = {"step": step + 1,
                   "train_accuracy": accuracy(parameter, data[0], data[1], template, spec),
                   "trigger_accuracy": accuracy(parameter, data[2], data[3], template, spec)}
            rows.append(row)
            print(json.dumps({"model": model, **row}), flush=True)
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / "anchor.npz").open("xb") as stream:
        np.savez(stream, parameter=parameter.numpy(), velocity=velocity.numpy())
    saved = {
        "phase": "anchor before constructor or future continuation", "model": model,
        "anchor": anchor, "start_step": start, "parameter_count": identity["parameter_count"],
        "train_examples": len(data[0]), "trigger_examples": len(data[2]), "certification_examples": len(data[4]),
        "training_seconds": time.perf_counter() - started, "training_log": rows,
        "checkpoint_sha256": digest(folder / "anchor.npz"),
        "runner_sha256": digest(Path(__file__)),
    }
    save_json(record, saved)
    return saved


def first_persistent(counts, target: int) -> int | None:
    for j in range(len(counts) - PERSISTENCE + 1):
        if min(counts[j:j + PERSISTENCE]) >= target:
            return j
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("train", "construct", "reveal", "run"))
    parser.add_argument("--model", choices=("four_block_layernorm", "one_block_control"), required=True)
    parser.add_argument("--anchor", type=int, choices=ANCHORS, default=100)
    args = parser.parse_args()
    if args.phase == "train":
        print(json.dumps(train_to_anchor(args.model, args.anchor), indent=2))
    else:
        # Certificate code is separate from the training implementation so its
        # development cannot silently change an already stored optimizer orbit.
        from larger_transformer_certificate import construct, reveal
        if args.phase == "construct":
            construct(args.model, args.anchor)
        elif args.phase == "reveal":
            reveal(args.model, args.anchor)
        else:
            for anchor in ANCHORS:
                if anchor < args.anchor:
                    continue
                train_to_anchor(args.model, anchor)
                construct(args.model, anchor)
                reveal(args.model, anchor)


if __name__ == "__main__":
    main()
