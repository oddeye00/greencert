"""Terminal semantics for explicit-runtime, physical-anchor window evidence.

The original known-anchor planner supplies unchanged closure/count semantics.
An explicit in-memory view changes its schema/component labels only; stored
evidence and execution identities are never relabeled. Publication requires
the production caller's fresh join, not a supplied saved audit.
"""
from dataclasses import asdict
import json
from pathlib import Path

from file_backed_window_assembly import fingerprint
from green_family_evidence import canonical_sha, require
import known_anchor_disposition as original
from known_anchor_window_assembly import SCHEMA as ORIGINAL_ASSEMBLY_SCHEMA
from registered_outcome_continuation import publish_json
from runtime_anchor_window_assembly import SCHEMA as ASSEMBLY_SCHEMA, SCOPE
from verified_artifact_io import IntegrityError, require_sha256
from window_disposition import family_fingerprint

SCHEMA = "runtime_anchor_window_disposition_v1"
POLICY_SCHEMA = "runtime_anchor_window_disposition_policy_v1"


def primitive(value):
    def path_only(item):
        if isinstance(item, Path):
            return str(item)
        raise TypeError("unsupported audit value")
    try:
        return json.loads(json.dumps(value, default=path_only, allow_nan=False))
    except (TypeError, ValueError, OverflowError) as error:
        raise IntegrityError("unserializable runtime disposition evidence") from error


def plan_disposition(request, result, *, allowed_powers, method_sha256, execution_plan_sha256):
    try:
        require_sha256(execution_plan_sha256)
        require(result["schema"] == ASSEMBLY_SCHEMA and result["scope"] == SCOPE and
                result["execution_plan_sha256"] == execution_plan_sha256 and
                result["original_records_relabelled"] is False, "runtime assembly identity or scope differs")
        components = result["authenticated_components"]
        provenance = result["provenance"]
        require(isinstance(components, list) and isinstance(provenance, dict) and
                "green" not in components and "green" not in provenance,
                "old and runtime Green labels mixed")
        if result["status"] != "pending":
            green = provenance["runtime_green"]
            require(green["original_records_relabelled"] is False and green["neural_hvps_replayed"] is False and
                    green["array_norms_replayed"] is True and green["event_certificate_issued"] is False and
                    green["future_outcome_access"] is False and type(green["power"]) is int and
                    green["power"] == request.power and type(green["complete_probes"]) is int and
                    green["complete_probes"] == len(request.original_probe_hashes) and
                    green["origin_method_sha256"] == request.green_method_sha256 and
                    isinstance(green["executions"], dict) and green["executions"],
                    "incomplete or relabeled runtime Green provenance")
        # This is only an adapter to the unchanged decision-semantic checker.
        # The original runtime result is kept verbatim in the final audit.
        view = {**result, "schema": ORIGINAL_ASSEMBLY_SCHEMA,
            "authenticated_components": ["green" if name == "runtime_green" else name for name in components],
            "provenance": {"green" if name == "runtime_green" else name: value for name, value in provenance.items()}}
        return original.plan_disposition(request, view, allowed_powers=allowed_powers, method_sha256=method_sha256)
    except (KeyError, TypeError, IndexError) as error:
        raise IntegrityError("malformed runtime-anchor disposition evidence") from error


def checked_policy(reader, request, *, policy_path, policy_sha256, recheck_policy):
    checked = recheck_policy()
    policy, _ = reader.read_json(policy_path, require_sha256(policy_sha256))
    require(policy == checked and policy["schema"] == POLICY_SCHEMA and policy["scope"] == SCOPE and
            policy["window_family_sha256"] == family_fingerprint(request) and
            policy["terminal_disposition_authorized"] is True and policy["outcome_join_authorized"] is False and
            policy["future_outcome_access"] is False and policy["original_issuance_policy_changed"] is False and
            policy["failure_probability"] == request.failure_probability and
            policy["execution_plan_sha256"] == canonical_sha({"executions": policy["execution_registry"],
                                                             "sequence_plan": policy["sequence_plan"]}),
            "unverified runtime terminal policy")
    for key in ("homogeneous_method_sha256", "assembly_policy_sha256", "execution_plan_sha256"):
        require_sha256(policy[key])
    return policy


def plan_for(request, result, policy):
    return plan_disposition(request, result, allowed_powers=tuple(policy["allowed_powers"]),
        method_sha256=policy["homogeneous_method_sha256"], execution_plan_sha256=policy["execution_plan_sha256"])


def record_fields(request, plan, *, audit_path, audit_sha256, policy_path, policy_sha256, policy):
    return {"schema": SCHEMA, "policy_path": str(policy_path), "policy_sha256": policy_sha256,
        "audit_path": str(audit_path), "audit_sha256": audit_sha256,
        "request_sha256": fingerprint(request), "window_family_sha256": family_fingerprint(request),
        "identity": asdict(request.identity), "event_definition": {"target": request.target, "persistence": request.persistence},
        "decision": primitive(original.decision_fields(plan)), "numerical_scope": SCOPE,
        "failure_probability": request.failure_probability,
        "homogeneous_method_sha256": policy["homogeneous_method_sha256"],
        "assembly_policy_sha256": policy["assembly_policy_sha256"],
        "execution_plan_sha256": policy["execution_plan_sha256"],
        "event_certificate_issued": plan["decision"] == "certificate", "construction_disposition_sealed": True,
        "outcome_join_authorized": False, "future_outcome_access": False,
        "original_issuance_policy_changed": False, "original_records_relabelled": False,
        "independent_neural_kernel_replay": False, "population_generalization_claim": False,
        "whole_prior_training_program_certified": False}


def publish_fresh(reader, *, request, result, audit_path, audit_sha256, policy_path, policy_sha256,
                  disposition_path, recheck_policy, barrier):
    barrier()
    require(not reader.resolve(disposition_path).exists(), "terminal record already reserved")
    policy = checked_policy(reader, request, policy_path=policy_path, policy_sha256=policy_sha256,
                            recheck_policy=recheck_policy)
    plan = plan_for(request, result, policy)
    if not plan["terminal"]:
        return {"published": False, "reason": plan["reason"], "event_certificate_issued": False,
                "outcome_join_authorized": False}
    audit, _ = reader.read_json(audit_path, require_sha256(audit_sha256))
    require(audit["result"] == primitive(result) and audit["plan"] == primitive(plan) and
            audit["request"] == primitive(asdict(request)) and audit["policy_sha256"] == policy_sha256,
            "saved audit differs from fresh runtime verification")
    artifacts = audit["observed_artifact_hashes"]
    require(isinstance(artifacts, dict) and artifacts, "final input provenance absent")
    for path, digest in artifacts.items():
        reader.check_blob(path, digest)
    checked_policy(reader, request, policy_path=policy_path, policy_sha256=policy_sha256, recheck_policy=recheck_policy)
    barrier()
    record = record_fields(request, plan, audit_path=audit_path, audit_sha256=audit_sha256,
                           policy_path=policy_path, policy_sha256=policy_sha256, policy=policy)
    digest = publish_json(reader.resolve(disposition_path), record)
    saved, _ = reader.read_json(disposition_path, digest)
    require(saved == record, "published runtime terminal record differs")
    return {"published": True, "decision": plan["decision"], "bracket": plan["bracket"],
        "disposition_sha256": digest, "event_certificate_issued": record["event_certificate_issued"],
        "outcome_join_authorized": False, "future_outcome_access": False}


def authenticate_record(reader, *, request, disposition_path, disposition_sha256, policy_path, policy_sha256,
                        recheck_policy, barrier):
    barrier()
    policy = checked_policy(reader, request, policy_path=policy_path, policy_sha256=policy_sha256,
                            recheck_policy=recheck_policy)
    record, digest = reader.read_json(disposition_path, require_sha256(disposition_sha256))
    try:
        audit, asha = reader.read_json(record["audit_path"], record["audit_sha256"])
        require(audit["policy_sha256"] == policy_sha256 and audit["request"] == primitive(asdict(request)),
                "foreign runtime final audit")
        plan = plan_for(request, audit["result"], policy)
        require(plan["terminal"] is True and audit["plan"] == primitive(plan), "nonterminal or changed saved plan")
        expected = record_fields(request, plan, audit_path=record["audit_path"], audit_sha256=asha,
            policy_path=policy_path, policy_sha256=policy_sha256, policy=policy)
        require(record == expected, "runtime terminal record differs from its checked decision")
        artifacts = audit["observed_artifact_hashes"]
        require(isinstance(artifacts, dict) and artifacts, "final provenance absent")
        for path, expected_sha in artifacts.items():
            reader.check_blob(path, expected_sha)
        barrier()
        return {"record_authenticated": True, "decision": plan["decision"], "bracket": plan["bracket"],
            "disposition_sha256": digest, "audit_sha256": asha, "numerical_scope": SCOPE,
            "failure_probability": request.failure_probability, "event_certificate_issued": record["event_certificate_issued"],
            "neural_kernel_replay_performed": False, "outcome_join_authorized": False, "future_outcome_access": False}
    except (KeyError, TypeError, IndexError) as error:
        raise IntegrityError("malformed runtime terminal record") from error
