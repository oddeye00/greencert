"""Join-orchestration tests, not neural experiments or producer proof replay.

Unit fixtures replace authenticated adapters with controlled typed evidence.
The real adapter integrity suites run separately in the combined regression.
An empty real artifact tree additionally exercises the actual pending path.
"""
from contextlib import ExitStack
import copy
from dataclasses import replace
import json
from pathlib import Path
import shutil
import tempfile
from unittest.mock import patch

from anchor_response_evidence import AnchorEvidence
import file_backed_window_assembly as join
from green_family_evidence import canonical_sha
from reference_margin_evidence import ReferenceMarginRow, anchor_output
from test_window_event_assembly import fixture, sha
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError
from window_event_assembly import PointMargin, assemble


def setup(n=7, horizon=6):
    args = fixture(n, horizon)
    train = [{"index": i, "pair": [i % 2, 0], "label": i % 2} for i in range(3)]
    evaluation = [{"index": i, "pair": [0, i], "label": i} for i in range(2)]
    identity = replace(args["identity"], training_set_sha256=canonical_sha(train),
                       evaluation_set_sha256=canonical_sha(evaluation))
    args["identity"] = identity
    args["drift_rows"] = [replace(row, identity=identity) for row in args["drift_rows"]]
    args["output_rows"] = [replace(row, identity=identity) for row in args["output_rows"]]
    args["response"] = replace(args["response"], identity=identity)
    args["green"] = replace(args["green"], identity=identity, probability_scope="ideal_gaussian_probes",
                            failure_probability=1e-7, expected_probes=2, complete_probes=2)
    request = join.WindowEvidenceRequest(identity=identity, anchor_paths={
        key: key + ".fixture" for key in ("candidate_path", "reference_record_path", "checkpoint_path",
                                         "corrected_path", "original_path", "audit_path")},
        response_folder="response", gradient_folder="gradient", reference_margin_folder="margins",
        green_folder="green", green_method_sha256=sha("green_method"),
        original_probe_hashes=(sha("g0"), sha("g1")), power=1, failure_probability=1e-7,
        learning_rate=.003, momentum=.9, training_examples=train, evaluation_examples=evaluation,
        example_ids=args["example_ids"], classes=2, normalization_eps=[],
        row_plan=tuple(join.BoundRowLocation(j, f"rows/{j}", "original") for j in range(1, horizon+1)),
        domain=args["domain"], target=args["target"], persistence=min(2,horizon),
        forbidden_outcome_files=("future.json",))
    args["persistence"] = request.persistence
    ref = tuple(ReferenceMarginRow(identity, row.step,
                tuple(PointMargin(m.example_id, m.lower, m.upper) for m in row.margins), "outward")
                for row in args["output_rows"])
    evidence = {
        "anchor": AnchorEvidence(identity, args["response"].first_injection_error_upper, sha("anchor"), sha("ref"), n),
        "response": {"bound": args["response"], "provenance": {}},
        "reference_margins": {"rows": ref, "anchor": anchor_output(ref[0]), "provenance": {}},
        "green": {"bound": args["green"], "provenance": {}},
    }
    for j in range(1, horizon+1):
        evidence[f"derivative_row_{j:03d}"] = {"output": args["output_rows"][j],
            "drift": args["drift_rows"][j-1] if j < horizon else None, "provenance": {}}
    return request, args, evidence


def fake_adapters(stack, evidence, *, missing=(), corrupt=()):
    calls = []
    def get(name):
        calls.append(name)
        if name in missing:
            raise EvidencePending("controlled pending fixture: " + name)
        if name in corrupt:
            raise IntegrityError("controlled corrupt completed fixture: " + name)
        return evidence[name]
    for function, name in (("authenticate_anchor", "anchor"), ("authenticate_response", "response"),
                           ("authenticate_reference_window", "reference_margins"), ("authenticate_green_family", "green")):
        stack.enter_context(patch.object(join, function, side_effect=lambda *a, _name=name, **k: get(_name)))
    stack.enter_context(patch.object(join, "authenticate_bound_row",
        side_effect=lambda *a, **k: get(f"derivative_row_{k['step']:03d}")))
    return calls


def rejects(reader, request, evidence, *, progress=None):
    with ExitStack() as stack:
        fake_adapters(stack, evidence)
        try:
            join.assemble_window_evidence(reader, request, progress=progress)
        except IntegrityError:
            return 1
    raise AssertionError("incompatible window evidence was accepted")


def main():
    parent = Path(__file__).resolve().parents[1] / "tmp"
    parent.mkdir(exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix="window_join_test_", dir=parent))
    report = {"all_passed": True, "controlled_complete_joins": 0, "pending_dependencies": 0,
              "integrity_failures_not_downgraded": 0, "semantic_rejections": 0,
              "real_missing_tree_pending": False, "event_certificates_issued": 0,
              "scope": "orchestration and scalar fixtures, not neural training experiments"}
    try:
        reader = EvidenceReader(temp)
        for n in (1, 13792, 451008, 1008864):
            for H in (1, 2, 6, 12):
                request, args, evidence = setup(n, H)
                with ExitStack() as stack:
                    calls = fake_adapters(stack, evidence)
                    result = join.assemble_window_evidence(reader, request)
                direct = assemble(**args)
                assert result["assembly"] == direct
                assert len(calls) == H + 4 and not result["missing"]
                assert not result["event_certificate_issued"] and not result["construction_disposition_sealed"]
                assert result["assembly"]["failure_probability"] == 1e-7
                report["controlled_complete_joins"] += 1
        request, args, evidence = setup()
        for component in evidence:
            with ExitStack() as stack:
                fake_adapters(stack, evidence, missing=(component,))
                result = join.assemble_window_evidence(reader, request)
            assert result["status"] == "pending" and result["assembly"] is None
            assert component in [row["component"] for row in result["missing"]]
            assert not result["event_certificate_issued"]
            report["pending_dependencies"] += 1
            with ExitStack() as stack:
                fake_adapters(stack, evidence, corrupt=(component,))
                try:
                    join.assemble_window_evidence(reader, request)
                except IntegrityError:
                    report["integrity_failures_not_downgraded"] += 1
                else:
                    raise AssertionError("corrupted completed evidence downgraded to pending")
        # Actual adapters on an empty tree do not emit a false abstention.
        empty = join.assemble_window_evidence(reader, request)
        assert empty["status"] == "pending" and len(empty["missing"]) == request.identity.horizon+4
        report["real_missing_tree_pending"] = True
        bad_requests = [
            replace(request, row_plan=request.row_plan[:-1]),
            replace(request, row_plan=request.row_plan[::-1]),
            replace(request, row_plan=(request.row_plan[0],) + request.row_plan),
            replace(request, row_plan=(replace(request.row_plan[0], folder=request.row_plan[1].folder),) + request.row_plan[1:]),
            replace(request, row_plan=(replace(request.row_plan[0], producer="unverified_float64"),) + request.row_plan[1:]),
            replace(request, target=True), replace(request, target=3), replace(request, persistence=8),
            replace(request, domain=float("nan")), replace(request, power=False),
            replace(request, failure_probability=0.), replace(request, failure_probability=True),
            replace(request, original_probe_hashes=()), replace(request, forbidden_outcome_files=()),
            replace(request, forbidden_outcome_files=("../future.json",)),
            replace(request, anchor_paths={}), replace(request, example_ids=("a","a")),
            replace(request, classes=True), replace(request, learning_rate=-1.),
            replace(request, identity=replace(request.identity, parameters=0)),
            replace(request, identity=replace(request.identity, state_metric="adamw")),
            replace(request, evaluation_examples=list(reversed(request.evaluation_examples))),
        ]
        for bad in bad_requests:
            report["semantic_rejections"] += rejects(reader, bad, evidence)
        for change in ("green_identity", "green_incomplete", "response_anchor_error_missing", "missing_interior_drift",
                       "unexpected_terminal_drift", "wrong_output_step", "point_only_future_output", "disjoint_intervals"):
            bad = copy.deepcopy(evidence)
            if change == "green_identity":
                bad["green"]["bound"] = replace(args["green"], identity=replace(request.identity, horizon=2))
            elif change == "green_incomplete":
                bad["green"]["bound"] = replace(args["green"], complete_probes=1)
            elif change == "response_anchor_error_missing":
                bad["response"]["bound"] = replace(args["response"], first_injection_error_upper=None)
            elif change == "missing_interior_drift":
                bad["derivative_row_001"]["drift"] = None
            elif change == "unexpected_terminal_drift":
                bad["derivative_row_006"]["drift"] = args["drift_rows"][0]
            elif change == "wrong_output_step":
                bad["derivative_row_001"]["output"] = args["output_rows"][2]
            elif change == "point_only_future_output":
                bad["derivative_row_001"]["output"] = bad["reference_margins"]["anchor"]
            elif change == "disjoint_intervals":
                row = bad["derivative_row_001"]["output"]
                bad["derivative_row_001"]["output"] = replace(row, margins=tuple(
                    replace(m, lower=5., upper=6.) for m in row.margins))
            report["semantic_rejections"] += rejects(reader, request, bad)
        no_gain = copy.deepcopy(evidence)
        no_gain["green"]["bound"] = None
        with ExitStack() as stack:
            fake_adapters(stack, no_gain)
            assert join.assemble_window_evidence(reader, request)["status"] == "no_finite_green_bound_at_requested_power"
        # A revealed file before or during verification cannot become a result.
        (temp / "future.json").write_text("{}", encoding="utf-8")
        report["semantic_rejections"] += rejects(reader, request, evidence)
        (temp / "future.json").unlink()
        def reveal_during(name, status):
            if name == "green" and status == "authenticated":
                (temp / "future.json").write_text("{}", encoding="utf-8")
        report["semantic_rejections"] += rejects(reader, request, evidence, progress=reveal_during)
        (temp / "future.json").unlink()
        def mutate_request(name, status):
            if name == "green" and status == "authenticated":
                request.normalization_eps.append([1e-5, 1e-5])
        report["semantic_rejections"] += rejects(reader, request, evidence, progress=mutate_request)
        print(json.dumps(report, indent=2))
        return report
    finally:
        assert temp.resolve().parent == parent.resolve() and temp.name.startswith("window_join_test_")
        shutil.rmtree(temp)


if __name__ == "__main__":
    main()
