"""Two-power Green bridges plus policy, publication and corruption tests.

The real bridges use actual file-backed quadratic Green products with
synthetic neural derivative/output premises. No real neural event is issued.
"""
from contextlib import ExitStack, redirect_stdout
import copy
from dataclasses import asdict, replace
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

import audit_candidate_power2_window as driver
from file_backed_window_assembly import fingerprint
from green_family_evidence import canonical_sha
from reference_margin_evidence import ReferenceMarginRow, anchor_output
from test_file_backed_window_assembly import setup
from test_known_anchor_window_assembly import record_fixture
from test_runtime_anchor_window_assembly import invoke
from test_runtime_anchor_disposition import runtime_fixture
from test_runtime_green_evidence import fixture as green_fixture
from verified_artifact_io import EvidenceReader, IntegrityError
from window_event_assembly import PointMargin, assemble


def main():
    counts = {"status":"PASS","real_two_power_bridges":0,"extension_refusals":0,
              "driver_pending_without_numerics":0,"synthetic_fresh_commits":0,"post_publication_authentications":0,
              "driver_refusals":0,"neural_certificates_issued":0}
    def refuse(call,key):
        try:
            call()
        except (IntegrityError,ValueError,FileExistsError):
            counts[key] += 1
        else:
            raise AssertionError("invalid power2 input accepted")
    with tempfile.TemporaryDirectory(prefix="greencert-power2-window-") as temp:
        top = Path(temp)
        old,_,_ = setup()
        old = replace(old,original_probe_hashes=tuple(str(i)*64 for i in range(1,5)))
        new = replace(old,power=2)
        r1 = {"dgx":{"synthetic":True}}
        s1 = tuple(({phase:{"folder":f"q1/{i}/{phase}","method":"dgx"} for phase in ("forward","adjoint")},) for i in range(4))
        r2 = {**r1,"dgx_q2":{"synthetic":True}}
        s2 = tuple((s1[i][0],{phase:{"folder":str(driver.execution.NEW/f"probe_{i}/power_02/{phase}"),"method":"dgx_q2"}
                              for phase in ("forward","adjoint")}) for i in range(4))
        driver.validate_extension(old,new,r1,s1,r2,s2)
        for field,value in (("power",1),("target",old.target+1),("persistence",old.persistence+1),("failure_probability",2e-7),
                            ("learning_rate",.004),("domain",old.domain*2),
                            ("original_probe_hashes",old.original_probe_hashes[::-1])):
            changed = replace(new,**{field:value})
            refuse(lambda:driver.validate_extension(old,changed,r1,s1,r2,s2),"extension_refusals")
        for changed in (s2[:-1],tuple((pair[1],pair[0]) for pair in s2),tuple((pair[0],) for pair in s2)):
            refuse(lambda:driver.validate_extension(old,new,r1,s1,r2,changed),"extension_refusals")
        refuse(lambda:driver.validate_extension(old,new,r1,s1,{"dgx_q2":{}},s2),"extension_refusals")
        refuse(lambda:driver.validate_extension(replace(old,power=True),new,r1,s1,r2,s2),"extension_refusals")
        for H in (1,3):
            root = top/f"real{H}"
            ga, checked = green_fixture(root,H,2,4,2)
            req,direct,_ = setup(2,H)
            train = [{"index":0,"pair":[0,1],"label":1}]
            identity = replace(ga["identity"],evaluation_set_sha256=canonical_sha(req.evaluation_examples))
            req = replace(req,identity=identity,training_examples=train,green_method_sha256=ga["origin_method_sha256"],
                          original_probe_hashes=ga["original_probe_hashes"],failure_probability=.01,power=2)
            direct["identity"],direct["training_count"] = identity,1
            direct["response"] = replace(direct["response"],identity=identity,first_injection_error_upper=.001)
            direct["green"] = replace(checked["bound"],identity=identity)
            direct["drift_rows"] = [replace(row,identity=identity,verified_training_count=1) for row in direct["drift_rows"]]
            direct["output_rows"] = [replace(row,identity=identity) for row in direct["output_rows"]]
            ref = tuple(ReferenceMarginRow(identity,row.step,tuple(PointMargin(m.example_id,m.lower,m.upper) for m in row.margins),
                                            "outward") for row in direct["output_rows"])
            ev = {"reference_margins":{"rows":ref,"anchor":anchor_output(ref[0]),"provenance":{}}}
            for j in range(1,H+1):
                ev[f"derivative_row_{j:03d}"] = {"output":direct["output_rows"][j],
                    "drift":direct["drift_rows"][j-1] if j < H else None,"provenance":{}}
            record = record_fixture(root,req,direct["response"])
            result,_ = invoke(root,req,ev,record,executions=ga["executions"],plan=ga["sequence_plan"],real_green=True)
            assert result["assembly"] == assemble(**direct)
            assert result["provenance"]["runtime_green"]["power"] == 2
            assert result["provenance"]["runtime_green"]["complete_probes"] == 4
            plan = driver.plan_for(req,result,{"allowed_powers":[1,2],"homogeneous_method_sha256":"a"*64,
                                              "execution_plan_sha256":result["execution_plan_sha256"]})
            assert plan["terminal"] and not plan["outcome_join_authorized"]
            counts["real_two_power_bridges"] += 1
        # Exercise the actual policy/publication driver while supplying an
        # explicitly mocked numerical join. This checks authority, not kernels.
        with ExitStack() as stack:
            root = top/"driver"
            request,result,_,reg,seq = runtime_fixture(root)
            request = replace(request,power=2)
            seq = tuple((p[0],{phase:{"folder":f"q2/{i}/{phase}","method":"dgx"} for phase in ("forward","adjoint")})
                        for i,p in enumerate(seq))
            result["request_sha256"] = fingerprint(request)
            result["execution_plan_sha256"] = canonical_sha({"executions":reg,"sequence_plan":seq})
            result["provenance"]["runtime_green"]["power"] = 2
            result["method_sha256"] = driver.previous.assembly.HOMOGENEOUS_SHA
            result["provenance"]["known_anchor_response"]["method_sha256"] = driver.previous.assembly.HOMOGENEOUS_SHA
            source_map = {}
            for name in ("audit_candidate_power2_window.py","test_runtime_power2_window.py"):
                (root/"scripts"/name).write_text("# synthetic driver\n")
                source_map[name] = driver.execution.sha(root/"scripts"/name)
            (root/"protocol.md").write_text("synthetic power2 protocol\n")
            for name,value in (("ROOT",root),("REL",Path("source")),("CON",Path("construction")),
                               ("ASSEMBLY",Path("construction/assembly.json")),("POLICY",Path("construction/policy.json")),
                               ("DISPOSITION",Path("construction/terminal.json")),("DOCUMENT",Path("protocol.md"))):
                stack.enter_context(patch.object(driver,name,value))
            stack.enter_context(patch.object(driver,"sources",side_effect=lambda:{name:driver.execution.sha(root/"scripts"/name) for name in source_map}))
            stack.enter_context(patch.object(driver,"context",return_value=(request,{},reg,seq,"c"*64)))
            driver.execution.save(root/driver.REGRESSION,{"status":"PASS","real_two_power_bridges":2,
                                  "neural_certificates_issued":0,"driver_pending_without_numerics":1,"sources":{}})
            assembly = driver.run(SimpleNamespace(mode="freeze-assembly"))
            terminal = driver.run(SimpleNamespace(mode="freeze-terminal",assembly_sha256=assembly["sha256"]))
            args = SimpleNamespace(mode="commit",policy_sha256=terminal["sha256"],disposition_sha256=None)
            join = stack.enter_context(patch.object(driver.previous.assembly,"assemble_runtime_anchor_evidence"))
            response = stack.enter_context(patch.object(driver.previous.assembly.response_audit,"audit",return_value={"fresh":True}))
            pending = driver.run(args)
            assert pending["status"] == "pending_markers" and not join.called and not response.called
            counts["driver_pending_without_numerics"] += 1
            for path in driver.previous.assembly.completion_markers(request,seq):
                driver.execution.save(root/path,{"fixture_marker":True})
            args.mode = "check"
            assert driver.run(args)["status"] == "completion_markers_present" and not join.called
            stack.enter_context(patch.object(driver.previous.assembly,"memory_available_mib",return_value=4096))
            def fresh(reader,req,**kwargs):
                assert kwargs["fresh_response_audit"]() == {"fresh":True}
                assert kwargs["sequence_plan"] == seq and req.power == 2
                return copy.deepcopy(result)
            join.side_effect = fresh
            args.mode = "commit"
            with redirect_stdout(io.StringIO()):
                published = driver.run(args)
            assert published["published"] and join.call_count == response.call_count == 1
            counts["synthetic_fresh_commits"] += 1
            refuse(lambda:driver.run(args),"driver_refusals")
            args.mode,args.disposition_sha256 = "audit-record",published["disposition_sha256"]
            assert driver.run(args)["record_authenticated"] and join.call_count == 1
            counts["post_publication_authentications"] += 1
            source = root/"scripts/audit_candidate_power2_window.py"
            source.write_text("# corrupted policy source\n")
            refuse(lambda:driver.run(args),"driver_refusals")
    counts["sources"] = {"scripts/"+name:driver.execution.sha(driver.ROOT/"scripts"/name) for name in
        ("audit_candidate_power2_window.py","test_runtime_power2_window.py","runtime_anchor_window_assembly.py",
         "runtime_anchor_disposition.py","runtime_green_evidence.py","test_runtime_green_evidence.py",
         "test_runtime_anchor_window_assembly.py","test_runtime_anchor_disposition.py")}
    path = driver.ROOT/driver.REGRESSION
    driver.execution.save(path,counts)
    print(json.dumps(counts|{"sha256":driver.execution.sha(path)},indent=2))


if __name__ == "__main__":
    main()
