"""Outcome-gate/interrupt tests; optional tiny, unrelated neural replay fixture."""
import argparse
from dataclasses import asdict
import hashlib
import itertools
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import continue_candidate_sealed_outcome as driver
from registered_outcome_continuation import execute_once, first_persistent, publish_json, utc
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError

ROOT = Path(__file__).resolve().parents[1]


class CounterObserver:
    runtime = {"fixture": "synthetic counter; not a neural experiment"}

    def __init__(self, counts, fail=None):
        self.counts, self.step, self.fail = counts, 0, fail

    def advance(self):
        self.step += 1
        if self.step == self.fail:
            raise RuntimeError("injected interruption during update")

    def observe(self):
        return {"correct_count": self.counts[self.step], "evaluation_count": 2,
                "parameter_sha256": "1"*64, "unscaled_velocity_sha256": "2"*64}


def fixture():
    return ({"outcome_join_authorized": True, "future_outcome_access": False,
             "decision": "certificate", "disposition_sha256": "a"*64, "bracket": [2,3]},
            {"horizon": 4, "target": 2, "persistence": 2, "evaluation_count": 2,
             "anchor": 100, "predicted_offset": 2})


def scalar_tests():
    rejected, publications, interruptions = 0, 0, 0
    # Correct, inaccurate, and no finite event are all recorded without suppression.
    for counts, covered in (([0,1,2,2,1],True), ([0,0,1,2,2],True),
                            ([0,2,2,0,0],False), ([0,1,1,1,1],False)):
        with TemporaryDirectory(prefix="greencert-outcome-test-") as tmp:
            reader = EvidenceReader(tmp)
            gate, protocol = fixture()
            record = execute_once(reader, gate=gate, protocol=protocol, protocol_sha256="b"*64,
                run_folder="run", outcome_path="reveal.json", prepare=lambda: CounterObserver(counts), recheck=lambda: None)
            saved, sha = reader.read_json("reveal.json", record["outcome_sha256"])
            assert saved["observed_float64_crossing_in_bracket"] is covered
            assert saved["exact_real_continuation_verified"] is False
            assert saved["exact_real_state_tube_tested"] is False
            assert len(saved["row_sha256"]) == 5
            assert (Path(tmp)/"run/intent_001.json").exists()
            publications += 1
            try:
                execute_once(reader, gate=gate, protocol=protocol, protocol_sha256="b"*64,
                    run_folder="run", outcome_path="reveal.json", prepare=lambda: (_ for _ in ()).throw(AssertionError()),
                    recheck=lambda: None)
            except IntegrityError:
                rejected += 1
            else:
                raise AssertionError("repeated outcome run allowed")
    mutations = [lambda g,p: g.update(outcome_join_authorized=False),
                 lambda g,p: g.update(future_outcome_access=True),
                 lambda g,p: g.update(decision="pending"),
                 lambda g,p: g.update(disposition_sha256=None),
                 lambda g,p: g.update(bracket=[0,3]),
                 lambda g,p: g.update(bracket=[3,2]),
                 lambda g,p: g.update(bracket=[1,4]),
                 lambda g,p: g.update(bracket=[True,2]),
                 lambda g,p: g.update(decision="route_abstention"),
                 lambda g,p: p.update(target=3),
                 lambda g,p: p.update(persistence=6),
                 lambda g,p: p.update(horizon=True)]
    for mutate in mutations:
        with TemporaryDirectory(prefix="greencert-outcome-test-") as tmp:
            gate, protocol = fixture()
            mutate(gate, protocol)
            try:
                execute_once(EvidenceReader(tmp), gate=gate, protocol=protocol, protocol_sha256="b"*64,
                    run_folder="run", outcome_path="reveal.json", prepare=lambda: (_ for _ in ()).throw(AssertionError()),
                    recheck=lambda: None)
            except (IntegrityError, TypeError):
                assert not (Path(tmp)/"run").exists()
                rejected += 1
            else:
                raise AssertionError("invalid gate accepted")
    for failure in ("prepare", "update", "final_recheck", "bad_count"):
        with TemporaryDirectory(prefix="greencert-outcome-test-") as tmp:
            gate, protocol = fixture()
            checks = []
            def recheck():
                checks.append(1)
                if failure == "final_recheck" and len(checks) == 2:
                    raise IntegrityError("injected source mutation")
            def prepare():
                if failure == "prepare":
                    raise RuntimeError("injected model initialization error")
                return CounterObserver([3,1,2,2,1] if failure == "bad_count" else [0,1,2,2,1],
                                       fail=2 if failure == "update" else None)
            try:
                execute_once(EvidenceReader(tmp), gate=gate, protocol=protocol, protocol_sha256="b"*64,
                    run_folder="run", outcome_path="reveal.json", prepare=prepare, recheck=recheck)
            except (RuntimeError, IntegrityError):
                assert (Path(tmp)/"run/started.json").exists()
                assert (Path(tmp)/"run/interrupted.json").exists()
                assert not (Path(tmp)/"reveal.json").exists()
                interruptions += 1
            else:
                raise AssertionError("interruption not propagated")
            try:
                execute_once(EvidenceReader(tmp), gate=gate, protocol=protocol, protocol_sha256="b"*64,
                    run_folder="run", outcome_path="reveal.json", prepare=prepare, recheck=lambda: None)
            except IntegrityError:
                rejected += 1
            else:
                raise AssertionError("interrupted run was silently retried")
    with TemporaryDirectory(prefix="greencert-outcome-test-") as tmp:
        gate, protocol = fixture()
        gate.update(decision="route_abstention", bracket=None)
        execute_once(EvidenceReader(tmp), gate=gate, protocol=protocol, protocol_sha256="b"*64,
            run_folder="run", outcome_path="reveal.json", prepare=lambda: CounterObserver([0,1,2,2,1]),
            recheck=lambda: None)
        saved, _ = EvidenceReader(tmp).read_json("reveal.json")
        assert saved["observed_float64_crossing_in_bracket"] is None
        publications += 1
    for mode in ("check", "execute"):
        with TemporaryDirectory(prefix="greencert-outcome-test-") as tmp, patch.object(driver,"ROOT",Path(tmp)):
            with patch.object(driver,"NeuralObserver",side_effect=AssertionError("model accessed before gate")):
                try:
                    result = driver.main(SimpleNamespace(mode=mode, power=1))
                except EvidencePending:
                    assert mode == "execute"
                    rejected += 1
                else:
                    assert mode == "check" and result["future_outcome_access"] is False
                assert not (Path(tmp)/driver.RUN).exists()
    paths = 0
    for H in range(1,7):
        for counts in itertools.product((0,2), repeat=H+1):
            for K in range(1,H+2):
                expected = None
                streak = 0
                for j,value in enumerate(counts):
                    streak = streak+1 if value >= 2 else 0
                    if streak >= K:
                        expected = j-K+1
                        break
                assert first_persistent(list(counts),2,K) == expected
                paths += 1
    with TemporaryDirectory(prefix="greencert-outcome-test-") as tmp:
        path = Path(tmp)/"record.json"
        publish_json(path,{"original":True})
        try:
            publish_json(path,{"replacement":True})
        except FileExistsError:
            assert json.loads(path.read_text()) == {"original":True}
            rejected += 1
        else:
            raise AssertionError("existing outcome overwritten")
    assert "torch" not in sys.modules, "scalar checks unexpectedly imported torch"
    return {"semantic_rejections":rejected, "synthetic_publications":publications,
            "retained_interruptions":interruptions, "enumerated_event_paths":paths,
            "model_imported":False}


def tiny_neural_test():
    assert driver.memory_available_mib() >= 1536, "insufficient memory for optional tiny fixture"
    import numpy as np
    import torch
    import transformer_hvp_grokking as neural
    config = neural.TransformerConfig(modulus=3, model_dim=4, hidden_dim=8, heads=1, depth=1,
        train_fraction=0.6, learning_rate=0.003, momentum=0.9, weight_decay=0.01, seed=1709,
        steps=4, threads=1, normalization="layernorm")
    template = neural.make_template(config)
    spec = neural.flat_spec(template)
    theta = neural.flatten_parameters(template)
    velocity = torch.arange(len(theta),dtype=torch.float64)*1e-7
    data = neural.make_disjoint_split(config)
    examples = lambda i,k: [{"index":j,"pair":pair,"label":label}
        for j,(pair,label) in enumerate(zip(data[i].tolist(),data[k].tolist()))]
    with TemporaryDirectory(prefix="greencert-neural-outcome-test-") as tmp:
        path = Path(tmp)/driver.SOURCE/"anchor.npz"
        path.parent.mkdir(parents=True)
        # A generated numerical fixture, not an edit to an existing artifact.
        with path.open("xb") as stream:
            np.savez(stream,parameter=theta.numpy(),velocity=velocity.numpy())
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        protocol = {"config":asdict(config), "torch_interop_threads":1,"torch_mha_fastpath":False,
                    "deterministic_algorithms":True,"identity":{"parameters":len(theta)},
                    "checkpoint_sha256":sha,"training_examples":examples(0,1),"evaluation_examples":examples(4,5)}
        observer = driver.NeuralObserver(EvidenceReader(tmp),protocol)
        assert torch.equal(observer.parameter,theta) and torch.equal(observer.velocity,velocity)
        coordinates = 2*len(theta)
        for step in range(4):
            with torch.no_grad():
                output = neural.logits(theta,data[4],template,spec)
            row = observer.observe()
            assert row["predictions"] == output.argmax(1).tolist()
            assert row["logits_float64_hex"] == [[float(v).hex() for v in line] for line in output.tolist()]
            if step < 3:
                velocity = config.momentum*velocity + neural.gradient(theta,data[0],data[1],template,spec,config)
                theta = theta-config.learning_rate*velocity
                observer.advance()
                assert torch.equal(observer.parameter,theta) and torch.equal(observer.velocity,velocity)
                coordinates += 2*len(theta)
        return {"fixture":"independent mod-3 width-4 one-block LayerNorm model; not current candidate",
                "parameters":len(theta),"future_steps":3,"bitwise_state_coordinates_compared":coordinates,
                "count_and_full_logit_rows_compared":4,"original_unscaled_velocity_preserved":True}


def main(neural):
    report = {"utc":utc(),"scalar":scalar_tests(), "current_candidate_future_access":False,
              "scope":"software tests; not additional certificates or neural experimental results"}
    if neural:
        report["tiny_neural"] = tiny_neural_test()
    names = driver.OWN_SOURCES | {"verified_artifact_io.py", "anchor_response_evidence.py"}
    report["sources"] = {name:hashlib.sha256((ROOT/"scripts"/name).read_bytes()).hexdigest() for name in sorted(names)}
    output = Path("results")/("registered_outcome_regression_"+report["utc"].replace(":","").replace("-","")+".json")
    sha = publish_json(ROOT/output, report)
    print(json.dumps({"output":str(output),"sha256":sha,**report},indent=2))


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--neural",action="store_true")
    main(parser.parse_args().neural)
