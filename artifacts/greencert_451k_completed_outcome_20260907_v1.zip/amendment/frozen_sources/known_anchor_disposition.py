"""Separate terminal decisions for freshly verified known-anchor windows.

The planner checks semantics, not neural mathematics. Publication requires
the production caller's fresh complete join and a reauthenticated policy.
Neither publication nor record authentication authorizes future training.
The original window-disposition module and its policies are not amended.
"""
from dataclasses import asdict
import json

from flint import arb, ctx

from file_backed_window_assembly import fingerprint
from green_family_evidence import number, require
from known_anchor_window_assembly import SCHEMA as ASSEMBLY_SCHEMA, SCOPE
from registered_outcome_continuation import publish_json
from verified_artifact_io import IntegrityError, require_sha256
from window_disposition import family_fingerprint
from window_event_assembly import first_persistent

SCHEMA = "known_anchor_window_disposition_v1"
POLICY_SCHEMA = "known_anchor_window_disposition_policy_v1"


def decision_fields(plan):
    return {key:value for key,value in plan.items() if key not in ("event_certificate_issued","outcome_join_authorized")}


def primitive(value):
    """Canonical JSON representation, including tuple/list normalization."""
    try:
        return json.loads(json.dumps(value, sort_keys=True, allow_nan=False))
    except (TypeError, ValueError, OverflowError) as error:
        raise IntegrityError("nonfinite or unserializable disposition evidence") from error


def plan_disposition(request, result, *, allowed_powers, method_sha256):
    """Plan a certificate or a route-specific abstention without publishing.

    Full, file-authenticated bounds are supplied by the caller. This function
    rejects inconsistent recorded claims, preserves the physical tail and
    independently recomputes first passage from complete integer count paths.
    """
    try:
        require_sha256(method_sha256)
        require(isinstance(allowed_powers, tuple) and allowed_powers and
                all(type(q) is int for q in allowed_powers) and
                allowed_powers == tuple(range(1,len(allowed_powers)+1)) and
                type(request.power) is int and request.power in allowed_powers,
                "outside the declared ordinary power budget")
        H = request.identity.horizon
        require(type(H) is int and H > 0 and type(request.target) is int and
                0 < request.target <= len(request.example_ids) and type(request.persistence) is int and
                0 < request.persistence <= H+1, "invalid fixed event")
        require(result["schema"] == ASSEMBLY_SCHEMA and result["scope"] == SCOPE and
                result["request_sha256"] == fingerprint(request) and
                result["identity"] == asdict(request.identity) and result["method_sha256"] == method_sha256 and
                result["event_definition"] == {"target":request.target,"persistence":request.persistence},
                "known-anchor decision identity, method or scope differs")
        require(all(result[key] is False for key in ("event_certificate_issued","construction_disposition_sealed",
                    "future_outcome_access","outcome_join_authorized","original_issuance_policy_changed",
                    "neural_kernels_replayed")) and result["conditional_on_validated_producers"] is True,
                "pre-disposition authority or numerical scope changed")
        base = {"terminal":False,"decision":None,"bracket":None,"event_certificate_issued":False,
                "outcome_join_authorized":False,"original_issuance_policy_changed":False}
        if result["status"] == "pending":
            require(isinstance(result["missing"],list) and result["missing"] and result["assembly"] is None,
                    "pending result contains no missing evidence or an assembly")
            return {**base,"reason":"evidence_pending"}
        require(result["missing"] == [] and result["authenticated_derivative_steps"] == list(range(1,H+1)),
                "incomplete window cannot receive a terminal decision")
        expected = {"known_anchor_response","reference_margins","green"} | {
            f"derivative_row_{j:03d}" for j in range(1,H+1)}
        require(isinstance(result["authenticated_components"],list) and
                len(result["authenticated_components"]) == len(expected) and
                set(result["authenticated_components"]) == set(result["provenance"]) == expected,
                "missing or duplicate authenticated component")
        response = result["provenance"]["known_anchor_response"]
        require(response["method_sha256"] == method_sha256 and response["physical_encoding_replayed"] is True and
                response["neural_hvps_replayed"] is False and type(response["response_artifact_count"]) is int and
                response["response_artifact_count"] > 0, "unreplayed or foreign physical response")
        require_sha256(response["construction_sha256"])
        profile = response["profile"]
        require(profile["identity"] == asdict(request.identity), "response profile identity differs")
        for key in ("original_summary_sha256","homogeneous_summary_sha256"):
            require_sha256(profile[key])
        norms = profile["parameter_norms"]
        require(isinstance(norms,(tuple,list)) and len(norms) == H+1 and norms[0] == 0.,
                "incomplete response profile or nonzero parameter anchor")
        norms = tuple(number(v,"parameter response norm") for v in norms)
        number(profile["residual_upper"],"combined recurrence residual")
        number(profile["original_first_injection_upper"],"original injection bound")
        tail = number(profile["encoding_injection_tail_upper"],"physical encoding injection tail")
        assembly = result["assembly"]
        if result["status"] == "no_finite_green_bound_at_requested_power":
            require(assembly is None,"nonfinite Green result carries an assembly")
            reason = "no_finite_green_bound"
        else:
            require(isinstance(assembly,dict) and assembly["inputs_compatible"] is True and
                    assembly["conditional_on_supplied_bounds"] is True and
                    assembly["artifact_authentication_performed"] is False and assembly["certificate_issued"] is False,
                    "scalar assembly validity or authority changed")
            require(assembly["probability_scope"] == "ideal_gaussian_probes" and
                    type(assembly["failure_probability"]) is float and
                    0 < assembly["failure_probability"] == request.failure_probability < 1,
                    "original Green probability scope changed")
            closure = assembly["state_closure"]
            require(closure["conditional_scalar_only"] is True and closure["anchor_error_included"] is True and
                    type(closure["horizon"]) is int and closure["horizon"] == H and
                    number(closure["first_injection_error"],"closure anchor tail") == tail,
                    "closure drops the physical encoding tail or changes the window")
            if closure["closure"] is True:
                E = number(closure["radius"],"certified remainder radius")
                prior = ctx.prec; ctx.prec = 256
                try:
                    require(bool(arb(max(norms))+arb(E) <= arb(request.domain)),
                            "certified tube leaves the original derivative domain")
                finally:
                    ctx.prec = prior
                low,high = assembly["lower_counts"],assembly["upper_counts"]
                require(isinstance(low,list) and isinstance(high,list) and len(low) == len(high) == H+1 and
                        all(type(l) is int and type(u) is int and 0 <= l <= u <= len(request.example_ids)
                            for l,u in zip(low,high)), "invalid or incomplete count paths")
                left = first_persistent(high,request.target,request.persistence)
                right = first_persistent(low,request.target,request.persistence)
                bracket = [left,right] if left is not None and right is not None and 0 < left <= right else None
                require(assembly["bracket"] is None or (isinstance(assembly["bracket"],list) and
                        len(assembly["bracket"]) == 2 and all(type(v) is int for v in assembly["bracket"])),
                        "invalid bracket endpoint types")
                require(assembly["bracket"] == bracket,"bracket differs from complete persistent count paths")
                if bracket is not None:
                    require(result["status"] == "enclosure_available_for_separate_disposition" and
                            assembly["reason"] is None,"inconsistent positive enclosure")
                    return {**base,"terminal":True,"decision":"certificate","bracket":bracket,"reason":None,
                            "numerical_scope":SCOPE,"failure_probability":request.failure_probability}
                require(result["status"] == "assembly_abstention" and
                        assembly["reason"] == "persistent_event_not_enclosed","inconsistent output abstention")
                reason = "persistent_event_not_enclosed"
            else:
                require(closure["closure"] is False and closure["radius"] is None and assembly["bracket"] is None and
                        result["status"] == "assembly_abstention" and assembly["reason"] == "state_closure_failed",
                        "inconsistent state-closure abstention")
                reason = "state_closure_failed"
        if request.power < allowed_powers[-1]:
            return {**base,"reason":"remaining_declared_powers","current_power_reason":reason}
        return {**base,"terminal":True,"decision":"route_abstention","reason":reason,
                "numerical_scope":SCOPE,"failure_probability":request.failure_probability,
                "interpretation":"this declared known-anchor route exhausted; not an impossibility result"}
    except (KeyError,TypeError,IndexError,OverflowError) as error:
        raise IntegrityError("malformed known-anchor disposition evidence") from error


def _checked_policy(reader,request,*,policy_path,policy_sha256,recheck_policy):
    """The production callback also authenticates the linked assembly policy."""
    require_sha256(policy_sha256)
    checked = recheck_policy()
    saved,_ = reader.read_json(policy_path,policy_sha256)
    require(saved == checked and saved["schema"] == POLICY_SCHEMA and
            saved["window_family_sha256"] == family_fingerprint(request) and saved["scope"] == SCOPE and
            saved["original_issuance_policy_changed"] is False and saved["outcome_join_authorized"] is False and
            saved["future_outcome_access"] is False and saved["terminal_disposition_authorized"] is True,
            "unauthenticated or incompatible terminal policy")
    require_sha256(saved["homogeneous_method_sha256"])
    require_sha256(saved["assembly_policy_sha256"])
    require(saved["failure_probability"] == request.failure_probability,"terminal policy changes probability")
    return saved


def publish_fresh(reader,*,request,result,audit_path,audit_sha256,policy_path,policy_sha256,
                  disposition_path,recheck_policy,barrier):
    """Publish only the production caller's freshly recomputed enclosure.

    The result argument is not loaded from a user-supplied file. Policy/source
    authentication and the outcome barrier are callbacks fixed by the driver.
    Hashes and semantic checks alone do not replace the fresh numerical join.
    """
    barrier()
    policy = _checked_policy(reader,request,policy_path=policy_path,policy_sha256=policy_sha256,
                             recheck_policy=recheck_policy)
    plan = plan_disposition(request,result,allowed_powers=tuple(policy["allowed_powers"]),
                            method_sha256=policy["homogeneous_method_sha256"])
    if not plan["terminal"]:
        return {"published":False,"reason":plan["reason"],"event_certificate_issued":False,
                "outcome_join_authorized":False}
    require_sha256(audit_sha256)
    audit,_ = reader.read_json(audit_path,audit_sha256)
    require(audit["result"] == primitive(result) and audit["plan"] == primitive(plan) and
            audit["request"] == primitive(asdict(request)) and audit["policy_sha256"] == policy_sha256,
            "saved final audit differs from fresh verification")
    artifacts = audit["observed_artifact_hashes"]
    require(isinstance(artifacts,dict) and artifacts,"missing final input provenance")
    for path,sha in artifacts.items():
        reader.check_blob(path,sha)
    _checked_policy(reader,request,policy_path=policy_path,policy_sha256=policy_sha256,recheck_policy=recheck_policy)
    barrier()
    record = {"schema":SCHEMA,"policy_path":str(policy_path),"policy_sha256":policy_sha256,
        "audit_path":str(audit_path),"audit_sha256":audit_sha256,"request_sha256":fingerprint(request),
        "window_family_sha256":family_fingerprint(request),"identity":asdict(request.identity),
        "event_definition":{"target":request.target,"persistence":request.persistence},
        "decision":primitive(decision_fields(plan)),"numerical_scope":SCOPE,"failure_probability":request.failure_probability,
        "homogeneous_method_sha256":policy["homogeneous_method_sha256"],
        "assembly_policy_sha256":policy["assembly_policy_sha256"],
        "event_certificate_issued":plan["decision"] == "certificate","construction_disposition_sealed":True,
        "outcome_join_authorized":False,"future_outcome_access":False,"original_issuance_policy_changed":False,
        "independent_neural_kernel_replay":False,"population_generalization_claim":False,
        "whole_prior_training_program_certified":False}
    sha = publish_json(reader.resolve(disposition_path),record)
    saved,_ = reader.read_json(disposition_path,sha)
    require(saved == record,"published terminal record differs")
    return {"published":True,"disposition_sha256":sha,"decision":plan["decision"],"bracket":plan["bracket"],
            "event_certificate_issued":record["event_certificate_issued"],"outcome_join_authorized":False}


def authenticate_record(reader,*,request,disposition_path,disposition_sha256,policy_path,policy_sha256,
                        recheck_policy,barrier):
    """Read-only semantic/provenance audit, deliberately not an outcome gate."""
    barrier()
    policy = _checked_policy(reader,request,policy_path=policy_path,policy_sha256=policy_sha256,
                             recheck_policy=recheck_policy)
    record,sha = reader.read_json(disposition_path,require_sha256(disposition_sha256))
    try:
        require(record["schema"] == SCHEMA and record["policy_sha256"] == policy_sha256 and
                reader.resolve(record["policy_path"]) == reader.resolve(policy_path) and
                record["request_sha256"] == fingerprint(request) and
                record["window_family_sha256"] == family_fingerprint(request) and
                record["identity"] == asdict(request.identity) and
                record["event_definition"] == {"target":request.target,"persistence":request.persistence} and
                record["homogeneous_method_sha256"] == policy["homogeneous_method_sha256"] and
                record["assembly_policy_sha256"] == policy["assembly_policy_sha256"],"foreign terminal record")
        require(record["construction_disposition_sealed"] is True and record["numerical_scope"] == SCOPE and
                record["failure_probability"] == request.failure_probability and all(record[key] is False for key in
                ("outcome_join_authorized","future_outcome_access","original_issuance_policy_changed",
                 "independent_neural_kernel_replay","population_generalization_claim","whole_prior_training_program_certified")),
                "terminal record expands its authority or numerical claim")
        audit,asha = reader.read_json(record["audit_path"],record["audit_sha256"])
        require(audit["policy_sha256"] == policy_sha256 and audit["request"] == primitive(asdict(request)),
                "foreign final verification audit")
        plan = plan_disposition(request,audit["result"],allowed_powers=tuple(policy["allowed_powers"]),
                                method_sha256=policy["homogeneous_method_sha256"])
        require(plan["terminal"] is True and record["decision"] == primitive(decision_fields(plan)) and
                audit["plan"] == primitive(plan) and
                record["event_certificate_issued"] is (plan["decision"] == "certificate"),
                "terminal marker changes the recomputed decision")
        artifacts = audit["observed_artifact_hashes"]
        require(isinstance(artifacts,dict) and artifacts,"missing final input provenance")
        for path,expected in artifacts.items():
            reader.check_blob(path,expected)
        barrier()
        return {"record_authenticated":True,"decision":plan["decision"],"bracket":plan["bracket"],
            "disposition_sha256":sha,"audit_sha256":asha,"event_certificate_issued":record["event_certificate_issued"],
            "numerical_scope":SCOPE,"failure_probability":request.failure_probability,
            "neural_kernel_replay_performed":False,"outcome_join_authorized":False,"future_outcome_access":False}
    except (KeyError,TypeError,IndexError) as error:
        raise IntegrityError("malformed known-anchor terminal record") from error
