"""Decision/publication integrity fixtures; no neural certificates are issued.

Complete join inputs are controlled scalar fixtures with stubbed producers.
These tests establish sequencing and claim preservation, not neural bounds.
"""
from contextlib import ExitStack
import copy
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import shutil
import tempfile

from checkpointed_green_products import save_json
from file_backed_window_assembly import assemble_window_evidence, fingerprint
from test_file_backed_window_assembly import setup, fake_adapters
from verified_artifact_io import EvidenceReader, IntegrityError
from window_disposition import (SCOPE, family_fingerprint, plan_disposition, publish_disposition,
                                authenticate_outcome_gate)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def made_join(reader, request, evidence):
    with ExitStack() as stack:
        fake_adapters(stack, evidence)
        return assemble_window_evidence(reader, request)


def refused(function):
    try:
        function()
    except (IntegrityError, FileExistsError):
        return 1
    raise AssertionError("unsafe decision or publication accepted")


def write(root, name, value):
    path = root/name
    save_json(path, value)
    return digest(path)


def publication_fixture(root, *, abstain=False, power=1):
    root.mkdir()
    reader = EvidenceReader(root)
    request, _, evidence = setup()
    protocol = root/"LARGER_CANDIDATE_OUTWARD_GREEN_PROTOCOL.md"
    protocol.write_text("synthetic route policy\n", encoding="utf-8")
    method_sha = write(root, "green/method.json", {"powers": [1,2], "protocol_sha256": digest(protocol)})
    request = replace(request, green_method_sha256=method_sha, power=power)
    result = made_join(reader, request, evidence)
    if abstain:
        result["status"] = "no_finite_green_bound_at_requested_power"
        result["assembly"] = None
    (root/"scripts").mkdir()
    source = root/"scripts/verifier.py"
    source.write_text("# synthetic publication test only\n", encoding="utf-8")
    policy = {"schema": "outward_window_disposition_policy_v1", "window_family_sha256": family_fingerprint(request),
        "green_method_sha256": method_sha, "green_protocol_sha256": digest(protocol), "allowed_powers": [1,2],
        "failure_probability": request.failure_probability, "sources": {"verifier.py": digest(source)},
        "future_outcome_access": False, "automatic_outcome_join": False, "numerical_scope": SCOPE}
    policy_sha = write(root, "policy.json", policy)
    blob_sha = write(root, "evidence.json", {"scope": "controlled synthetic scalar premise"})
    audit = {"policy_sha256": policy_sha, "request_sha256": fingerprint(request), "result": result,
             "observed_artifact_hashes": {"evidence.json": blob_sha}}
    audit_sha = write(root, "audit.json", audit)
    kwargs = dict(reader=reader, request=request, result=result, audit_path="audit.json", audit_sha256=audit_sha,
        policy_path="policy.json", policy_sha256=policy_sha, disposition_path="disposition.json",
        required_source_names=frozenset({"verifier.py"}))
    return kwargs


def gate_kwargs(kwargs, published):
    return {key: value for key, value in kwargs.items() if key not in ("result", "audit_path", "audit_sha256")} | {
        "disposition_sha256": published["disposition_sha256"]}


def main():
    parent = Path(__file__).resolve().parents[1]/"tmp"
    parent.mkdir(exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix="window_disposition_test_", dir=parent))
    report = {"all_passed": True, "planner_semantic_rejections": 0, "nonterminal_routes": 0,
        "controlled_terminal_publications": 0, "publication_or_gate_rejections": 0,
        "neural_certificates_issued": 0, "scope": "scalar and immutable-publication fixtures only"}
    try:
        reader = EvidenceReader(temp)
        request, _, evidence = setup()
        result = made_join(reader, request, evidence)
        plan = plan_disposition(request, result, allowed_powers=(1,2))
        assert plan["terminal"] and plan["decision"] == "certificate" and plan["bracket"] == [1,3]
        assert not plan["event_certificate_issued"] and not plan["outcome_join_authorized"]
        pending = copy.deepcopy(result)
        pending.update(status="pending", missing=[{"component": "green"}], assembly=None)
        assert plan_disposition(request, pending, allowed_powers=(1,2))["reason"] == "evidence_pending"
        report["nonterminal_routes"] += 1
        abstention = copy.deepcopy(result)
        abstention.update(status="assembly_abstention")
        abstention["assembly"].update(bracket=None, reason="persistent_event_not_enclosed",
            lower_counts=[0]*7, upper_counts=[0]*7)
        for value in (abstention, {**result, "status": "no_finite_green_bound_at_requested_power", "assembly": None}):
            early = plan_disposition(request, value, allowed_powers=(1,2))
            assert not early["terminal"] and early["reason"] == "remaining_declared_powers"
            report["nonterminal_routes"] += 1
            later = replace(request, power=2)
            record = {**value, "request_sha256": fingerprint(later)}
            final = plan_disposition(later, record, allowed_powers=(1,2))
            assert final["terminal"] and final["decision"] == "route_abstention" and not final["outcome_join_authorized"]
        mutations = [
            lambda r: r.update(event_certificate_issued=True),
            lambda r: r.update(construction_disposition_sealed=True),
            lambda r: r.update(future_outcome_access=True),
            lambda r: r.update(registered_outcome_files_absent=False),
            lambda r: r.update(neural_kernels_replayed=True),
            lambda r: r.update(conditional_on_validated_producers=False),
            lambda r: r.update(scope="unconditional exact-real guarantee"),
            lambda r: r.update(request_sha256="0"*64),
            lambda r: r.update(event_definition={"target": 2, "persistence": 2}),
            lambda r: r.update(missing=[{"component":"green"}]),
            lambda r: r.update(authenticated_derivative_steps=[1,2]),
            lambda r: r["authenticated_components"].append("green"),
            lambda r: r["provenance"].pop("reference_margins"),
            lambda r: r["assembly"].update(certificate_issued=True),
            lambda r: r["assembly"].update(conditional_on_supplied_bounds=False),
            lambda r: r["assembly"].update(probability_scope="deterministic"),
            lambda r: r["assembly"].update(failure_probability=0.),
            lambda r: r["assembly"]["state_closure"].update(first_injection_error=0.),
            lambda r: r["assembly"]["state_closure"].update(radius=float("inf")),
            lambda r: r["assembly"]["state_closure"].update(horizon=2),
            lambda r: r["assembly"].update(lower_counts=[0]*6),
            lambda r: r["assembly"]["lower_counts"].__setitem__(0, True),
            lambda r: r["assembly"]["lower_counts"].__setitem__(0, 99),
            lambda r: r["assembly"].update(bracket=[1,4]),
            lambda r: r["assembly"].update(bracket=[True,3]),
            lambda r: r.update(status="assembly_abstention"),
        ]
        for mutate in mutations:
            bad = copy.deepcopy(result); mutate(bad)
            report["planner_semantic_rejections"] += refused(lambda: plan_disposition(request, bad, allowed_powers=(1,2)))
        for powers in ((), (1,3), (True,2), (2,), [1,2]):
            report["planner_semantic_rejections"] += refused(lambda: plan_disposition(request, result, allowed_powers=powers))
        # Publication is independent of outcome execution. Every fixture has
        # a private root and is deleted only after resolved containment checks.
        for index, (abstain,power) in enumerate(((False,1),(True,2))):
            kwargs = publication_fixture(temp/f"complete_{index}", abstain=abstain, power=power)
            published = publish_disposition(**kwargs)
            assert published["published"] and not published["outcome_join_authorized"]
            authorized = authenticate_outcome_gate(**gate_kwargs(kwargs, published))
            assert authorized["outcome_join_authorized"] and not authorized["future_outcome_access"]
            assert not (kwargs["reader"].root/"future.json").exists()
            report["controlled_terminal_publications"] += 1
            report["publication_or_gate_rejections"] += refused(lambda: publish_disposition(**kwargs))
        kwargs = publication_fixture(temp/"early", abstain=True, power=1)
        assert publish_disposition(**kwargs) == {"published":False, "reason":"remaining_declared_powers", "outcome_join_authorized":False}
        assert not (kwargs["reader"].root/"disposition.json").exists()
        report["nonterminal_routes"] += 1
        for index, change in enumerate(("changed_result", "wrong_audit_sha", "no_audit_sha", "no_policy_sha",
                                        "empty_source_policy", "source_changed", "input_changed", "future_exists")):
            kwargs = publication_fixture(temp/f"reject_{index}")
            root = kwargs["reader"].root
            if change == "changed_result": kwargs["result"] = {**kwargs["result"], "scope":"unverified"}
            elif change == "wrong_audit_sha": kwargs["audit_sha256"] = "0"*64
            elif change == "no_audit_sha": kwargs["audit_sha256"] = None
            elif change == "no_policy_sha": kwargs["policy_sha256"] = None
            elif change == "empty_source_policy": kwargs["required_source_names"] = frozenset()
            elif change == "source_changed": (root/"scripts/verifier.py").write_text("# changed\n",encoding="utf-8")
            elif change == "input_changed": (root/"evidence.json").write_text("{}",encoding="utf-8")
            elif change == "future_exists": (root/"future.json").write_text("{}",encoding="utf-8")
            report["publication_or_gate_rejections"] += refused(lambda: publish_disposition(**kwargs))
            assert not (root/"disposition.json").exists()
        for index, change in enumerate(("no_pin", "wrong_pin", "future_exists", "input_changed", "source_changed",
                                        "fake_coverage", "fake_scope", "fake_pending")):
            kwargs = publication_fixture(temp/f"gate_reject_{index}")
            published = publish_disposition(**kwargs)
            args = gate_kwargs(kwargs,published)
            root = kwargs["reader"].root
            if change == "no_pin": args["disposition_sha256"] = None
            elif change == "wrong_pin": args["disposition_sha256"] = "0"*64
            elif change == "future_exists": (root/"future.json").write_text("{}",encoding="utf-8")
            elif change == "input_changed": (root/"evidence.json").write_text("{}",encoding="utf-8")
            elif change == "source_changed": (root/"scripts/verifier.py").write_text("# changed\n",encoding="utf-8")
            else:
                # Coherent rehashing cannot turn changed semantics into a seal.
                record = json.loads((root/"disposition.json").read_text())
                if change == "fake_coverage": record["decision"]["bracket"] = [1,4]
                elif change == "fake_scope": record["population_generalization_claim"] = True
                else: record["construction_disposition_sealed"] = False
                args["disposition_path"] = "forged.json"
                args["disposition_sha256"] = write(root,"forged.json",record)
                args["reader"] = EvidenceReader(root)
            report["publication_or_gate_rejections"] += refused(lambda: authenticate_outcome_gate(**args))
        print(json.dumps(report, indent=2))
        return report
    finally:
        assert temp.resolve().parent == parent.resolve() and temp.name.startswith("window_disposition_test_")
        shutil.rmtree(temp)


if __name__ == "__main__":
    main()
