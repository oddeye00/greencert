"""Candidate-specific mixed-runtime q1 audit; no event or outcome authority."""
import argparse
import ast
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
import json

from audit_candidate_window_assembly import load_request
from dgx_green_transition_pilot import ROOT, REL, CON, GREEN, METHOD_SHA, sha, save, barriers
from green_family_evidence import require
from runtime_green_contract import compare_methods
from runtime_green_evidence import authenticate_runtime_green_family
from verified_artifact_io import EvidenceReader, EvidencePending

BUNDLE = Path("results/dgx_green_continuation_20260907")
NEW = CON / "outward_green_dgx"
PLAN_SHA = "b245257d7b2fd599137fed157fe3ea358b051e171c2a47eadfe8d8dc923b118f"
READY_SHA = "5ac0b38e0cbe2affe8edf35b71302bc9d957df01accd330c190c5d9218fb669c"
EXECUTION_SHA = "ff61df14814f7cdebb3c127e6610abbebf8e741f3008ea24b547044877ad5402"
RETIREMENT_SHA = "3d362e4a7e9a5d677cb5e962befb856d52fe04eb1dda4c4d13e3e5db09bcea7c"
POLICY = CON / "runtime_green_audit_policy.json"


def sources():
    pending = [Path(__file__), ROOT / "scripts/test_runtime_green_evidence.py",
               ROOT / "scripts/test_runtime_green_contract.py"]
    result = {}
    while pending:
        path = pending.pop()
        if path.name in result:
            continue
        result[path.name] = sha(path)
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
            imports = [v.name for v in node.names] if isinstance(node, ast.Import) else (
                [node.module] if isinstance(node, ast.ImportFrom) and node.module else [])
            for module in imports:
                candidate = ROOT / "scripts" / (module.replace(".", "/") + ".py")
                if candidate.is_file() and candidate.name not in result:
                    pending.append(candidate)
    return result


def context(reader):
    barriers(ROOT)
    request, provenance = load_request(reader, source=REL, construction=CON, power=1)
    require(request.green_method_sha256 == METHOD_SHA and request.identity.parameters == 451008
            and request.identity.horizon == 64 and len(request.original_probe_hashes) == 4,
            "candidate scope differs")
    plan, _ = reader.read_json(BUNDLE / "execution_plan.json", PLAN_SHA)
    ready, _ = reader.read_json(BUNDLE / "remote_ready.json", READY_SHA)
    execution, _ = reader.read_json(BUNDLE / "remote_execution_method.json", EXECUTION_SHA)
    retired, _ = reader.read_json(CON / "dgx_green_handover/receipt.json", RETIREMENT_SHA)
    require(ready["plan_sha256"] == PLAN_SHA and ready["execution_method_sha256"] == EXECUTION_SHA
            and ready["future_outcome_access"] is False and
            retired["status"] == "original_worker_retired_records_preserved" and
            retired["remote_plan_sha256"] == PLAN_SHA and retired["remote_ready_sha256"] == READY_SHA
            and retired["exit_code"] == 130 and retired["proof_files_removed"] is False,
            "execution handover differs")
    origin, _ = reader.read_json(GREEN / "method.json", METHOD_SHA)
    common = compare_methods(origin, execution, origin_sha256=METHOD_SHA,
        protocol_sha256=plan["execution_protocol_sha256"], execution_sources=plan["execution_sources"])
    require(common == ready["common_operator_sha256"], "common operator differs")
    reader.check_blob("DGX_GREEN_CONTINUATION_PROTOCOL.md", plan["execution_protocol_sha256"])
    for name, digest in execution["sources"].items():
        reader.check_blob(Path("scripts") / name, digest)
    registry = {"dgx": {"method_path": str(BUNDLE / "remote_execution_method.json"), "method_sha256": EXECUTION_SHA,
        "protocol_path": "DGX_GREEN_CONTINUATION_PROTOCOL.md", "protocol_sha256": plan["execution_protocol_sha256"],
        "execution_sources": plan["execution_sources"]}}
    sequences = tuple(({phase: {"folder": str((NEW if probe == 3 else GREEN) / f"probe_{probe}/power_01/{phase}"),
        "method": "dgx" if probe == 3 else "origin"} for phase in ("forward", "adjoint")},) for probe in range(4))
    return request, provenance, registry, sequences, common


def main(args):
    reader = EvidenceReader(ROOT)
    request, provenance, registry, sequences, common = context(reader)
    tests_path = Path("results/runtime_green_evidence_contract_20260907.json")
    tests, tsha = reader.read_json(tests_path)
    require(tests["status"] == "PASS" and tests["complete_mixed_quadratic_families"] == 4
            and tests["same_gain_as_original"] == 4, "complete-family regression report missing")
    for path, digest in tests["sources"].items():
        reader.check_blob(path, digest)
    payload = {"schema": "candidate_runtime_green_audit_v1", "sources": sources(),
        "origin_method_sha256": METHOD_SHA, "execution_method_sha256": EXECUTION_SHA,
        "common_operator_sha256": common, "execution_plan_sha256": PLAN_SHA,
        "remote_ready_sha256": READY_SHA, "retirement_sha256": RETIREMENT_SHA,
        "identity": asdict(request.identity), "original_probe_hashes": list(request.original_probe_hashes),
        "power": 1, "failure_probability": request.failure_probability,
        "execution_registry": registry, "sequence_plan": sequences,
        "tests_path": str(tests_path), "tests_sha256": tsha,
        "future_outcome_access": False, "event_issuance_authorized": False, "outcome_observer_authorized": False,
        "scope": "Execution-only audit during construction; no new experiment or original-record relabeling."}
    # Canonical JSON containers avoid platform tuple/list representation drift.
    payload = json.loads(json.dumps(payload))
    if args.mode == "freeze":
        require(not (ROOT / POLICY).exists(), "audit policy already frozen")
        barriers(ROOT)
        save(ROOT / POLICY, payload)
        print(json.dumps({"status": "frozen", "policy_sha256": sha(ROOT / POLICY),
                          "source_count": len(payload["sources"]), "future_outcome_access": False}, indent=2))
        return
    saved, psha = reader.read_json(POLICY, args.policy_sha256)
    require(saved == payload, "caller policy or code changed")
    missing = []
    for probe, powers in enumerate(sequences):
        for phase, location in powers[0].items():
            path = Path(location["folder"]) / "summary.json"
            if not reader.resolve(path).exists():
                missing.append({"probe": probe, "phase": phase, "summary": str(path)})
    result = None
    status = "pending" if missing else "ready_for_full_audit"
    if not missing and args.mode == "audit":
        from continue_candidate_sealed_outcome import memory_available_mib
        require(memory_available_mib() >= 1536, "full-family audit requires 1536MiB free")
        result = authenticate_runtime_green_family(reader, origin_folder=str(GREEN), origin_method_sha256=METHOD_SHA,
            executions=registry, sequence_plan=sequences, identity=request.identity, power=1,
            original_probe_hashes=request.original_probe_hashes, failure_probability=request.failure_probability,
            learning_rate=request.learning_rate, momentum=request.momentum,
            forbidden_paths=tuple(str(path) for path in (REL / "reveal.json", REL / "registered_outcome_run",
                CON / "outward_window_disposition.json", CON / "known_anchor_window_disposition.json")))
        status = "complete_family_audited" if result["bound"] is not None else "no_finite_green_bound"
        if result["bound"] is not None:
            result = {**result, "bound": asdict(result["bound"])}
    barriers(ROOT)
    record = {"utc": datetime.now(timezone.utc).isoformat(), "status": status, "policy_sha256": psha,
        "missing": missing, "result": result, "original_context": provenance, "observed_artifacts": reader.observed,
        "event_certificate": False, "future_outcome_access": False}
    target = ROOT / CON / "runtime_green_audits" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + ".json")
    save(target, record)
    print(json.dumps({"status": status, "missing": missing, "report": str(target.relative_to(ROOT)),
        "sha256": sha(target), "event_certificate": False}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("freeze", "check", "audit"), required=True)
    parser.add_argument("--policy-sha256")
    main(parser.parse_args())
