"""Execute only the original second Gram power, in a separate runtime lineage."""
import argparse
import ast
from datetime import datetime, timezone
import gc
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time

import dgx_green_continuation as old
from runtime_green_contract import execution_method, compare_methods

ROOT, REL, CON, GREEN = old.ROOT, old.REL, old.CON, old.GREEN
sha, read, save, check = old.sha, old.read, old.save, old.check
NEW = CON/"outward_green_dgx_q2"
BASE = ROOT/"results/dgx_green_power2_20260907"
PROTOCOL = "DGX_GREEN_POWER2_PROTOCOL.md"
AUDIT = CON/"runtime_anchor_final_verifications/20260907T114757.873608+0000.json"
AUDIT_SHA = "5c9c75b5362d64e908c0d3f62414742ad27e2c723c39b1374ab30a13f0da48ee"
EXTRA = ("dgx_green_power2.py", "dgx_green_continuation.py", "runtime_green_contract.py", "dgx_green_transition_pilot.py")


def barrier():
    old.barriers(ROOT)
    check(not (ROOT/CON/"runtime_anchor_window_disposition.json").exists(), "runtime disposition exists")


def validate_plan(plan):
    fixed = {"origin_method_sha256": old.METHOD_SHA, "power": 2, "probes": [0,1,2,3],
             "phases": ["forward", "adjoint"], "threads_per_process": 1, "maximum_parallel_probes": 4,
             "minimum_free_mib": 4096, "q1_audit_sha256": AUDIT_SHA,
             "regenerate_probes": False, "automatic_retry": False, "automatic_import": False,
             "event_certificate": False, "future_outcome_access": False}
    check(all(type(plan.get(k)) is type(v) and plan[k] == v for k,v in fixed.items()), "q2 execution scope differs")
    check(len(plan["inputs"]) == 4 and [v["probe"] for v in plan["inputs"]] == [0,1,2,3], "q2 input family differs")
    for item in plan["inputs"]:
        probe = item["probe"]
        folder = (GREEN if probe < 3 else CON/"outward_green_dgx")/f"probe_{probe}/power_01/adjoint"
        check(item["folder"] == folder.as_posix() and len(item["summary_sha256"]) == 64,
              "q2 must start from original q1 adjoints")


def prepare():
    barrier()
    check(not BASE.exists() and not BASE.with_suffix(".tar").exists(), "q2 export already reserved")
    check(sha(ROOT/AUDIT) == AUDIT_SHA and sha(ROOT/GREEN/"method.json") == old.METHOD_SHA, "q1/origin evidence differs")
    audited = read(ROOT/AUDIT)
    origin = read(ROOT/GREEN/"method.json")
    check(origin["powers"] == [1,2] and origin["probes"] == 4 and origin["delta"] == 1e-7, "original budget differs")
    test = ROOT/"results/dgx_green_power2_contract_20260907.json"
    tested = read(test)
    check(tested["status"] == "PASS", "q2 orchestration untested")
    for rel, value in tested["sources"].items():
        check(sha(ROOT/rel) == value, "tested q2 source changed")
    for name, value in origin["sources"].items():
        check(sha(ROOT/"scripts"/name) == value, "original numerical source changed")
    pending = [Path("scripts")/name for name in (*origin["sources"], *EXTRA, "test_dgx_green_power2.py")]
    rels = set()
    while pending:
        rel = pending.pop()
        if rel in rels:
            continue
        rels.add(rel)
        for node in ast.walk(ast.parse((ROOT/rel).read_text(encoding="utf-8"))):
            modules = ([node.module] if isinstance(node, ast.ImportFrom) and node.module else
                       [v.name for v in node.names] if isinstance(node, ast.Import) else [])
            for module in modules:
                path = Path("scripts")/(module.replace(".", "/")+".py")
                if (ROOT/path).is_file():
                    pending.append(path)
    rels |= {Path(PROTOCOL), test.relative_to(ROOT), GREEN/"method.json", REL/"candidate.json", AUDIT}
    inputs = []
    from checkpointed_green_products import StoredRows
    for probe in range(4):
        folder = (GREEN if probe < 3 else CON/"outward_green_dgx")/f"probe_{probe}/power_01/adjoint"
        source = StoredRows(ROOT/folder)
        # The full q1 audit already authenticated the physical arrays and
        # recurrence chains; retain and bind its observed bytes, not flags.
        observed = {str(k).replace("\\", "/"): v for k,v in audited["observed_artifact_hashes"].items()}
        for path in (ROOT/folder).iterdir():
            check(path.is_file() and not path.is_symlink(), "unexpected q1 input entry")
            rel = path.relative_to(ROOT)
            check(observed.get(rel.as_posix()) == sha(path), "q1 input missing from final audit")
            rels.add(rel)
        inputs.append({"probe": probe, "folder": folder.as_posix(), "summary_sha256": source.identity,
                       "method_sha256": sha(ROOT/folder/"method.json")})
    BASE.mkdir(exist_ok=False)
    files = {}
    # Copy only metadata/sources; stream large immutable rows into the tar.
    for rel in sorted(rels):
        files[rel.as_posix()] = sha(ROOT/rel)
    expected = ROOT/"results/dgx_green_transition_pilot_20260907/expected_runtime.json"
    shutil.copyfile(expected, BASE/"expected_runtime.json")
    files["expected_runtime.json"] = sha(BASE/"expected_runtime.json")
    plan = {"utc": datetime.now(timezone.utc).isoformat(), "origin_method_sha256": old.METHOD_SHA,
            "power": 2, "probes": [0,1,2,3], "phases": ["forward", "adjoint"],
            "threads_per_process": 1, "maximum_parallel_probes": 4, "minimum_free_mib": 4096,
            "q1_audit_sha256": AUDIT_SHA, "inputs": inputs, "files": files,
            "execution_sources": {name: sha(ROOT/"scripts"/name) for name in EXTRA},
            "execution_protocol_sha256": sha(ROOT/PROTOCOL),
            "reference_sha256": old.PATH_SHA, "regenerate_probes": False, "automatic_retry": False,
            "automatic_import": False, "event_certificate": False, "future_outcome_access": False}
    validate_plan(plan)
    save(BASE/"execution_plan.json", plan)
    with tarfile.open(BASE.with_suffix(".tar"), "x") as archive:
        for rel in sorted(rels):
            check(sha(ROOT/rel) == files[rel.as_posix()], "input changed during export")
            archive.add(ROOT/rel, arcname=rel.as_posix(), recursive=False)
        for name in ("expected_runtime.json", "execution_plan.json"):
            archive.add(BASE/name, arcname=name, recursive=False)
    barrier()
    receipt = {"plan_sha256": sha(BASE/"execution_plan.json"), "archive_sha256": sha(BASE.with_suffix(".tar")),
               "archive_bytes": BASE.with_suffix(".tar").stat().st_size, "files": len(files),
               "future_outcome_access": False}
    save(BASE/"export_receipt.json", receipt)
    print(json.dumps(receipt, indent=2), flush=True)


def authenticate(expected, full=True):
    barrier()
    check(sha(ROOT/"execution_plan.json") == expected, "q2 plan differs")
    plan = read(ROOT/"execution_plan.json")
    validate_plan(plan)
    for rel, value in plan["files"].items():
        if full or not rel.endswith(".npy"):
            path = (ROOT/rel).resolve()
            check(path.is_relative_to(ROOT.resolve()) and sha(path) == value, "q2 input changed: "+rel)
    check(sha(ROOT/CON/"corrected_scaled.npy") == old.PATH_SHA == plan["reference_sha256"], "q2 reference differs")
    return plan


def run_pair(target, source, hvp, *, eta, mu, method_sha, probe, guard=None, progress=None):
    from checkpointed_green_products import StoredRows, product
    check(type(probe) is int and 0 <= probe < 4 and not target.exists(), "probe already reserved or invalid")
    target.mkdir(parents=True, exist_ok=False)
    summaries = {}
    for transpose in (False, True):
        phase = "adjoint" if transpose else "forward"
        result = product(target/phase, source, hvp, learning_rate=eta, momentum=mu, transpose=transpose,
                         precision_bits=128, contract={"method_sha256": method_sha, "probe": probe, "power": 2},
                         guard=guard, progress=(None if progress is None else lambda row: progress(phase, row)))
        check(result["complete"] is True and result["hvp_calls"] == source.H-1, "incomplete q2 phase")
        summaries[phase] = sha(target/phase/"summary.json")
        source = StoredRows(target/phase)
    return summaries


def bootstrap(expected):
    check(sha(ROOT/"execution_plan.json") == expected, "q2 plan differs before bootstrap")
    target = ROOT/CON/"corrected_scaled.npy"
    donor = ROOT.parent/"green-continuation"/CON/"corrected_scaled.npy"
    check(not target.exists() and not (ROOT/NEW).exists() and sha(donor) == old.PATH_SHA, "q2 reference donor/target differs")
    os.link(donor, target)
    plan = authenticate(expected)
    runtime = old.environment()
    old.runtime_context()
    from test_checkpointed_green_products import main as streaming_test
    from test_factored_neural_green_products import main as neural_test
    from test_dgx_green_power2 import regression
    tests = {"streaming": streaming_test(), "neural": neural_test(), "q2": regression()}
    check(tests["streaming"]["all_passed"] and tests["neural"]["all_passed"] and tests["q2"]["status"] == "PASS",
          "destination regressions failed")
    method = execution_method(read(ROOT/GREEN/"method.json"), origin_sha256=old.METHOD_SHA,
                              protocol_sha256=plan["execution_protocol_sha256"],
                              execution_sources=plan["execution_sources"], runtime=runtime)
    save(ROOT/NEW/"method.json", method)
    save(ROOT/NEW/"ready.json", {"status": "ready_q2_no_candidate_queries", "plan_sha256": expected,
         "execution_method_sha256": sha(ROOT/NEW/"method.json"), "tests": tests,
         "future_outcome_access": False, "event_certificate": False})
    authenticate(expected)
    print(json.dumps({"ready_sha256": sha(ROOT/NEW/"ready.json"),
                      "execution_method_sha256": sha(ROOT/NEW/"method.json")}, indent=2), flush=True)


def run(expected, probe):
    plan = authenticate(expected)
    check(type(probe) is int and probe in plan["probes"], "invalid probe")
    memory = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
    check(int(memory["MemAvailable"].split()[0])/1024 >= plan["minimum_free_mib"], "memory admission")
    runtime = old.environment()
    cfg, spec, data, eps = old.runtime_context()
    method = read(ROOT/NEW/"method.json")
    mh = sha(ROOT/NEW/"method.json")
    check(method["runtime_versions"] == runtime and read(ROOT/NEW/"ready.json")["execution_method_sha256"] == mh,
          "q2 runtime/method changed")
    compare_methods(read(ROOT/GREEN/"method.json"), method, origin_sha256=old.METHOD_SHA,
                    protocol_sha256=plan["execution_protocol_sha256"], execution_sources=plan["execution_sources"])
    from checkpointed_green_products import StoredRows
    from arb_factored_regularizer_hvp import factored_chunked_hvp
    import numpy as np
    source = StoredRows(ROOT/plan["inputs"][probe]["folder"])
    check(source.identity == plan["inputs"][probe]["summary_sha256"], "q1 adjoint source changed")
    raw = np.load(ROOT/CON/"corrected_scaled.npy", mmap_mode="r", allow_pickle=False)
    check(raw.shape == (65,902016) and raw.dtype == np.float64, "q2 reference layout differs")
    execution = ROOT/NEW/f"execution_probe_{probe}"
    execution.mkdir(parents=True, exist_ok=False)
    save(execution/"start.json", {"pid": os.getpid(), "utc": datetime.now(timezone.utc).isoformat(),
         "proc_stat": Path("/proc/self/stat").read_text(), "plan_sha256": expected,
         "execution_method_sha256": mh, "probe": probe, "power": 2, "future_outcome_access": False})
    def guard():
        authenticate(expected, full=False)
        check(sha(ROOT/NEW/"method.json") == mh, "q2 execution method changed")
    def hvp(j, direction):
        return factored_chunked_hvp(raw[j,:451008], data[0], data[1], spec, cfg,
                                   normalization_eps=eps, direction=direction, chunk_size=8)
    def progress(phase, row):
        print(json.dumps({"probe": probe, "phase": phase, "row": row["index"], "seconds": row["seconds"],
                          "residual": row["local_residual_norm_upper"]}), flush=True)
        gc.collect()
    started = time.perf_counter()
    try:
        manifests = run_pair(ROOT/NEW/f"probe_{probe}/power_02", source, hvp, eta=cfg.learning_rate,
                             mu=cfg.momentum, method_sha=mh, probe=probe, guard=guard, progress=progress)
        guard()
        save(execution/"summary.json", {"status": "complete_q2_probe_not_family", "probe": probe, "power": 2,
             "execution_method_sha256": mh, "product_manifests": manifests, "seconds": time.perf_counter()-started,
             "event_certificate": False, "future_outcome_access": False})
    except Exception as error:
        save(execution/"failure.json", {"type": type(error).__name__, "error": str(error)})
        raise


def launch(expected):
    authenticate(expected)
    folder = ROOT/"q2_launch"
    folder.mkdir(exist_ok=False)
    dispatched = []
    for probe in range(4):
        with (folder/f"probe_{probe}_stdout.log").open("x") as out, (folder/f"probe_{probe}_stderr.log").open("x") as err:
            child = subprocess.Popen([sys.executable, "-u", str(Path(__file__).resolve()), "run",
                                      "--plan-sha256", expected, "--probe", str(probe)],
                                     cwd=ROOT, stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
        row = {"pid": child.pid, "probe": probe, "plan_sha256": expected,
               "utc": datetime.now(timezone.utc).isoformat(), "automatic_retry": False}
        save(folder/f"probe_{probe}_dispatch.json", row)
        dispatched.append(row)
    print(json.dumps({"dispatched": dispatched}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "bootstrap", "launch", "run"))
    parser.add_argument("--plan-sha256")
    parser.add_argument("--probe", type=int)
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare()
    elif args.mode == "run":
        run(args.plan_sha256, args.probe)
    else:
        {"bootstrap": bootstrap, "launch": launch}[args.mode](args.plan_sha256)
