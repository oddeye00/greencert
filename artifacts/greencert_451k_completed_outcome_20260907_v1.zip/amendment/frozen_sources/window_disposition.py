"""Decision and immutable-publication gate for authenticated window joins.

The pure planner checks decision semantics, not neural bounds. The production
caller must run the file-backed join itself under the pinned policy sources.
No function in this module simulates or reads a future training trajectory.
"""
from dataclasses import asdict, replace
import math
from pathlib import Path

from checkpointed_green_products import save_json
from file_backed_window_assembly import fingerprint
from green_family_evidence import require
from verified_artifact_io import IntegrityError, require_sha256
from window_event_assembly import first_persistent

SCOPE = "outward validated-producer arithmetic conditional on the original ideal-Gaussian projection event"


def family_fingerprint(request):
    """The same operator, event and evidence plan at every ordinary power."""
    return fingerprint(replace(request, power=1))


def plan_disposition(request, result, *, allowed_powers):
    """Return a proposed terminal decision or a nonterminal refusal.

Even a positive plan is not a seal, an authenticated certificate by itself,
or permission for an outcome join. Its numerical premises are supplied by
the production file-backed verifier, never inferred from a passed flag.
"""
    try:
        require(isinstance(allowed_powers, tuple) and len(allowed_powers) > 0 and
                all(type(q) is int for q in allowed_powers) and
                allowed_powers == tuple(range(1, len(allowed_powers)+1)) and type(request.power) is int and
                request.power in allowed_powers,
                "power is outside the declared contiguous route budget")
        require(result["request_sha256"] == fingerprint(request) and result["identity"] == asdict(request.identity) and
                result["event_definition"] == {"target": request.target, "persistence": request.persistence},
                "disposition request/event differs from assembled evidence")
        require(result["event_certificate_issued"] is False and result["construction_disposition_sealed"] is False and
                result["future_outcome_access"] is False and result["registered_outcome_files_absent"] is True and
                result["conditional_on_validated_producers"] is True and result["neural_kernels_replayed"] is False,
                "pre-disposition numerical or outcome scope changed")
        require(result["scope"] == "file-authenticated outward bounds; Green gain conditional on original ideal-Gaussian event",
                "pre-disposition claim scope changed")
        base = {"terminal": False, "decision": None, "bracket": None,
                "event_certificate_issued": False, "outcome_join_authorized": False}
        if result["status"] == "pending":
            require(isinstance(result["missing"], list) and len(result["missing"]) > 0 and result["assembly"] is None,
                    "pending audit has no missing evidence or already contains an assembly")
            return {**base, "reason": "evidence_pending"}
        require(result["missing"] == [] and result["authenticated_derivative_steps"] == list(range(1, request.identity.horizon+1)),
                "incomplete window cannot receive a disposition")
        expected = {"anchor", "response", "reference_margins", "green"} | {
            f"derivative_row_{j:03d}" for j in range(1, request.identity.horizon+1)}
        require(len(result["authenticated_components"]) == len(expected) and
                set(result["authenticated_components"]) == set(result["provenance"]) == expected,
                "incomplete or duplicate authenticated components")
        assembly = result["assembly"]
        if result["status"] == "no_finite_green_bound_at_requested_power":
            require(assembly is None, "nonfinite Green route contains an event assembly")
            reason = "no_finite_green_bound"
        else:
            require(isinstance(assembly, dict) and assembly["inputs_compatible"] is True and
                    assembly["conditional_on_supplied_bounds"] is True and
                    assembly["artifact_authentication_performed"] is False and assembly["certificate_issued"] is False,
                    "scalar assembly contract or numerical premise changed")
            require(assembly["probability_scope"] == "ideal_gaussian_probes" and
                    type(assembly["failure_probability"]) is float and
                    assembly["failure_probability"] == request.failure_probability,
                    "probability assumption changed at final disposition")
            closure = assembly["state_closure"]
            require(closure["conditional_scalar_only"] is True and closure["anchor_error_included"] is True and
                    closure["horizon"] == request.identity.horizon and
                    closure["first_injection_error"] == result["provenance"]["anchor"]["first_injection_error_upper"],
                    "closure drops anchor error or changes the horizon")
            if closure["closure"] is True:
                require(type(closure["radius"]) in (int, float) and math.isfinite(closure["radius"]) and closure["radius"] >= 0,
                        "invalid certified remainder radius")
                low, high = assembly["lower_counts"], assembly["upper_counts"]
                require(isinstance(low, list) and isinstance(high, list) and
                        len(low) == len(high) == request.identity.horizon+1 and
                        all(type(l) is int and type(u) is int and 0 <= l <= u <= len(request.example_ids)
                            for l, u in zip(low, high)), "invalid or incomplete certified count paths")
                left = first_persistent(high, request.target, request.persistence)
                right = first_persistent(low, request.target, request.persistence)
                bracket = [left, right] if left is not None and right is not None and 0 < left <= right else None
                require(assembly["bracket"] is None or (isinstance(assembly["bracket"], list) and
                        len(assembly["bracket"]) == 2 and all(type(v) is int for v in assembly["bracket"])),
                        "invalid bracket endpoint types")
                require(assembly["bracket"] == bracket, "first-passage bracket differs from strict count paths")
                if bracket is not None:
                    require(result["status"] == "enclosure_available_for_separate_disposition" and assembly["reason"] is None,
                            "inconsistent issued-enclosure status")
                    return {**base, "terminal": True, "decision": "certificate", "bracket": bracket,
                            "reason": None, "numerical_scope": SCOPE,
                            "failure_probability": request.failure_probability}
                require(result["status"] == "assembly_abstention" and
                        assembly["reason"] == "persistent_event_not_enclosed", "inconsistent event abstention")
                reason = "persistent_event_not_enclosed"
            else:
                require(closure["closure"] is False and closure["radius"] is None and assembly["bracket"] is None and
                        result["status"] == "assembly_abstention" and assembly["reason"] == "state_closure_failed",
                        "inconsistent nonlinear closure abstention")
                reason = "state_closure_failed"
        if request.power < allowed_powers[-1]:
            return {**base, "reason": "remaining_declared_powers", "current_power_reason": reason}
        return {**base, "terminal": True, "decision": "route_abstention", "reason": reason,
                "numerical_scope": SCOPE, "failure_probability": request.failure_probability,
                "interpretation": "this declared numerical route exhausted; other methods may still certify"}
    except (KeyError, TypeError, IndexError) as error:
        raise IntegrityError("malformed completed-window decision evidence") from error


def check_policy(reader, request, *, policy_path, policy_sha256, required_source_names):
    require_sha256(policy_sha256)
    policy, sha = reader.read_json(policy_path, policy_sha256)
    require(policy["schema"] == "outward_window_disposition_policy_v1" and
            policy["window_family_sha256"] == family_fingerprint(request) and
            policy["future_outcome_access"] is False and policy["automatic_outcome_join"] is False and
            policy["numerical_scope"] == SCOPE, "foreign or incompatible disposition policy")
    reader.check_sources(policy, required_names=required_source_names)
    method, _ = reader.read_json(Path(request.green_folder)/"method.json", request.green_method_sha256)
    require(policy["green_method_sha256"] == request.green_method_sha256 and
            policy["allowed_powers"] == method["powers"] and policy["failure_probability"] == request.failure_probability,
            "disposition budget differs from the registered outward route")
    reader.check_blob("LARGER_CANDIDATE_OUTWARD_GREEN_PROTOCOL.md", policy["green_protocol_sha256"])
    require(policy["green_protocol_sha256"] == method["protocol_sha256"], "foreign outward route protocol")
    return policy, sha


def publish_disposition(reader, *, request, result, audit_path, audit_sha256,
                        policy_path, policy_sha256, disposition_path, required_source_names):
    """Publish a unique final record only after a live, authenticated join.

The production driver, not a user-supplied audit JSON, supplies request/result.
The saved audit must match those freshly computed values. Publication never
launches training. A separate reader must authenticate the completed marker
and its audit before allowing an outcome join.
"""
    require_sha256(audit_sha256)
    policy, psha = check_policy(reader, request, policy_path=policy_path, policy_sha256=policy_sha256,
                                required_source_names=required_source_names)
    plan = plan_disposition(request, result, allowed_powers=tuple(policy["allowed_powers"]))
    if not plan["terminal"]:
        return {"published": False, "reason": plan["reason"], "outcome_join_authorized": False}
    for path in request.forbidden_outcome_files:
        require(not reader.resolve(path).exists(), "future outcome exists before disposition")
    audit, asha = reader.read_json(audit_path, audit_sha256)
    require(audit["result"] == result and audit["policy_sha256"] == psha and
            audit["request_sha256"] == fingerprint(request), "saved audit differs from fresh verification")
    for path, sha in audit["observed_artifact_hashes"].items():
        reader.check_blob(path, sha)
    # Input immutability and absence checks are repeated immediately before
    # publication. This is application-level sequencing, not a filesystem ACL.
    reader.check_sources(policy, required_names=required_source_names)
    for path in request.forbidden_outcome_files:
        require(not reader.resolve(path).exists(), "future outcome appeared during disposition")
    target = reader.resolve(disposition_path)
    require(not target.exists(), "a final disposition already exists")
    record = {"schema": "outward_window_disposition_v1", "policy_path": str(policy_path), "policy_sha256": psha,
        "audit_path": str(audit_path), "audit_sha256": asha, "request_sha256": fingerprint(request),
        "window_family_sha256": family_fingerprint(request), "identity": asdict(request.identity),
        "event_definition": {"target": request.target, "persistence": request.persistence},
        "decision": {key: value for key, value in plan.items() if key not in
                     ("event_certificate_issued", "outcome_join_authorized")},
        "numerical_scope": SCOPE, "failure_probability": request.failure_probability,
        "event_certificate_issued": plan["decision"] == "certificate", "construction_disposition_sealed": True,
        "future_outcome_access": False, "outcome_join_authorized": False,
        "eligible_for_separate_outcome_gate": True, "independent_neural_kernel_replay": False,
        "population_generalization_claim": False, "whole_prior_training_program_certified": False}
    save_json(target, record)
    # Reopen the published bytes; a partial temporary file is never a marker.
    saved, sha = reader.read_json(disposition_path)
    require(saved == record, "published disposition differs from computed record")
    return {"published": True, "disposition_sha256": sha, "decision": plan["decision"],
            "bracket": plan["bracket"], "outcome_join_authorized": False}


def authenticate_outcome_gate(reader, *, request, disposition_path, disposition_sha256,
                              policy_path, policy_sha256, required_source_names):
    """Authenticate a completed marker for a separate, explicitly run join.

This rechecks publication/decision integrity and all bound input hashes. It
does not repeat the neural kernels or execute training. An externally pinned
disposition digest is required; a file named 'certificate' is insufficient.
"""
    require_sha256(disposition_sha256)
    policy, psha = check_policy(reader, request, policy_path=policy_path, policy_sha256=policy_sha256,
                                required_source_names=required_source_names)
    record, dsha = reader.read_json(disposition_path, disposition_sha256)
    try:
        require(record["schema"] == "outward_window_disposition_v1" and
                record["policy_sha256"] == psha and reader.resolve(record["policy_path"]) == reader.resolve(policy_path) and
                record["request_sha256"] == fingerprint(request) and
                record["window_family_sha256"] == family_fingerprint(request) and
                record["identity"] == asdict(request.identity) and
                record["event_definition"] == {"target": request.target, "persistence": request.persistence},
                "disposition belongs to another window/event/policy")
        require(record["construction_disposition_sealed"] is True and record["future_outcome_access"] is False and
                record["outcome_join_authorized"] is False and record["eligible_for_separate_outcome_gate"] is True and
                record["independent_neural_kernel_replay"] is False and record["population_generalization_claim"] is False and
                record["whole_prior_training_program_certified"] is False and record["numerical_scope"] == SCOPE and
                record["failure_probability"] == request.failure_probability, "sealed claim/numerical scope changed")
        audit, asha = reader.read_json(record["audit_path"], record["audit_sha256"])
        require(audit["policy_sha256"] == psha and audit["request_sha256"] == fingerprint(request),
                "foreign completed verification audit")
        plan = plan_disposition(request, audit["result"], allowed_powers=tuple(policy["allowed_powers"]))
        decision = {key: value for key, value in plan.items() if key not in
                    ("event_certificate_issued", "outcome_join_authorized")}
        require(plan["terminal"] is True and record["decision"] == decision and
                record["event_certificate_issued"] is (plan["decision"] == "certificate"),
                "marker changes the verified terminal decision")
        for path, sha in audit["observed_artifact_hashes"].items():
            reader.check_blob(path, sha)
        for path in request.forbidden_outcome_files:
            require(not reader.resolve(path).exists(), "future outcome already exists at gate")
        return {"outcome_join_authorized": True, "disposition_sha256": dsha, "audit_sha256": asha,
                "decision": plan["decision"], "bracket": plan["bracket"], "numerical_scope": SCOPE,
                "failure_probability": request.failure_probability, "future_outcome_access": False,
                "neural_kernel_replay_performed": False}
    except (KeyError, TypeError, IndexError) as error:
        raise IntegrityError("malformed sealed disposition") from error
