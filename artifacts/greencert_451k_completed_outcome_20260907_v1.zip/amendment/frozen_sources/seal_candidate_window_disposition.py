"""Freeze/check/execute the separate final disposition; never reveal training.

The default check mode only lists missing completion markers. Commit mode
performs a fresh complete evidence join, not promotion of an old audit flag.
"""
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

from audit_candidate_window_assembly import ROOT, SOURCE, CON, NAMES as JOIN_SOURCES, load_request
from checkpointed_green_products import save_json
from file_backed_window_assembly import assemble_window_evidence, fingerprint
from green_family_evidence import require
from verified_artifact_io import EvidenceReader, EvidencePending
from window_disposition import SCOPE, family_fingerprint, check_policy, plan_disposition, publish_disposition

NAMES = tuple(dict.fromkeys(JOIN_SOURCES + ("window_disposition.py", "test_window_disposition.py",
    "seal_candidate_window_disposition.py", "checkpointed_green_products.py")))
POLICY = CON / "outward_window_disposition_policy.json"
DISPOSITION = CON / "outward_window_disposition.json"


def completion_markers(request):
    return [Path(request.response_folder)/"summary.json", Path(request.reference_margin_folder)/"summary.json",
            Path(request.green_folder)/f"power_{request.power:02d}.json",
            *(Path(location.folder)/"summary.json" for location in request.row_plan)]


def check_markers(reader, request):
    missing = []
    for path in completion_markers(request):
        try:
            reader.read_json(path, allow_in_progress=True)
        except EvidencePending as error:
            missing.append({"path": str(path), "reason": str(error)})
    return missing


def freeze_policy(reader, request):
    if reader.resolve(POLICY).exists():
        _, sha = reader.read_json(POLICY)
        check_policy(reader, request, policy_path=POLICY, policy_sha256=sha, required_source_names=frozenset(NAMES))
        return sha, False
    method, _ = reader.read_json(Path(request.green_folder)/"method.json", request.green_method_sha256)
    require(method["powers"] == list(range(1, len(method["powers"])+1)), "invalid registered route ladder")
    require(all(not reader.resolve(path).exists() for path in request.forbidden_outcome_files), "future already opened")
    sources = {name: hashlib.sha256((ROOT/"scripts"/name).read_bytes()).hexdigest() for name in NAMES}
    policy = {"schema": "outward_window_disposition_policy_v1", "created_utc": datetime.now(timezone.utc).isoformat(),
        "window_family_sha256": family_fingerprint(request), "green_method_sha256": request.green_method_sha256,
        "green_protocol_sha256": method["protocol_sha256"], "allowed_powers": method["powers"],
        "failure_probability": request.failure_probability, "numerical_scope": SCOPE,
        "sources": sources, "future_outcome_access": False, "automatic_outcome_join": False,
        "selection_scope": "outcome-blind method development; not a fresh confirmatory cohort",
        "terminal_rule": "issue on a complete enclosure; route abstention only at the declared final power",
        "prior_diagnostic_maximum_is_not_this_route_budget": True}
    reader.check_sources(policy, required_names=frozenset(NAMES))
    save_json(reader.resolve(POLICY), policy)
    _, sha = reader.read_json(POLICY)
    return sha, True


def main(args):
    reader = EvidenceReader(ROOT)
    request, context = load_request(reader, source=SOURCE, construction=CON, power=args.power)
    require(not reader.resolve(DISPOSITION).exists(), "final disposition already exists; do not overwrite it")
    if args.mode == "freeze-policy":
        sha, created = freeze_policy(reader, request)
        print(json.dumps({"policy_path": str(POLICY), "policy_sha256": sha, "created": created,
                          "construction_disposition_sealed": False, "future_outcome_access": False}, indent=2))
        return
    _, psha = reader.read_json(POLICY)
    policy, psha = check_policy(reader, request, policy_path=POLICY, policy_sha256=psha,
                                required_source_names=frozenset(NAMES))
    missing = check_markers(reader, request)
    if missing:
        print(json.dumps({"status": "pending_markers", "missing_count": len(missing), "missing": missing,
            "scope": "completion-marker inventory only; numerical evidence not reverified",
            "event_certificate_issued": False, "construction_disposition_sealed": False,
            "outcome_join_authorized": False, "future_outcome_access": False}, indent=2))
        return
    if args.mode == "check":
        print(json.dumps({"status": "completion_markers_present", "numerical_verification_performed": False,
            "event_certificate_issued": False, "construction_disposition_sealed": False,
            "outcome_join_authorized": False, "future_outcome_access": False}, indent=2))
        return
    # Commit mode repeats all numerical/interface checks against the artifacts.
    result = assemble_window_evidence(reader, request, progress=lambda name, status:
        print(json.dumps({"component": name, "status": status}), flush=True))
    reader.check_sources(policy, required_names=frozenset(NAMES))
    plan = plan_disposition(request, result, allowed_powers=tuple(policy["allowed_powers"]))
    now = datetime.now(timezone.utc)
    audit_path = CON/"final_window_verifications"/(now.strftime("%Y%m%dT%H%M%S%fZ")+".json")
    audit = {"utc": now.isoformat(), "policy_sha256": psha, "request_sha256": fingerprint(request),
        "request": json.loads(json.dumps(asdict(request), default=str)), "context_provenance": context,
        "result": result, "plan": plan, "observed_artifact_hashes": dict(reader.observed)}
    save_json(reader.resolve(audit_path), audit)
    _, asha = reader.read_json(audit_path)
    publication = publish_disposition(reader, request=request, result=result, audit_path=audit_path, audit_sha256=asha,
        policy_path=POLICY, policy_sha256=psha, disposition_path=DISPOSITION, required_source_names=frozenset(NAMES))
    print(json.dumps({**publication, "audit_path": str(audit_path), "audit_sha256": asha,
                      "future_outcome_access": False}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("check", "freeze-policy", "commit"), default="check")
    parser.add_argument("--power", type=int, default=1)
    main(parser.parse_args())
