"""Explicit one-shot observation after the frozen two-power terminal gate."""
import argparse
import hashlib
import json
from pathlib import Path

import continue_candidate_sealed_outcome as original
from registered_outcome_continuation import execute_once,publish_json,require,unopened,utc
from verified_artifact_io import EvidenceReader,EvidencePending,require_sha256

ROOT,SOURCE,CON = original.ROOT,original.SOURCE,original.CON
RUN,OUTCOME = original.RUN,original.OUTCOME
DISPOSITION = CON/"runtime_anchor_window_disposition.json"
PROTOCOL = CON/"runtime_power2_outcome_protocol.json"
DOCUMENT = Path("RUNTIME_POWER2_OUTCOME_PROTOCOL.md")
REGRESSION = Path("results/runtime_power2_outcome_contract_20260907.json")
BASE_SHA = "b0aad0f4047ee2dd6f27e03aa02c695d68fedbd89a4cb4b6aa72907fc62368cf"
POLICY_SHA = "2ae641a84b01ec6bcadd425fbe68d0476dce819905140720cf7872ce95125952"
OWN_SOURCES = {"continue_power2_sealed_outcome.py","test_runtime_power2_outcome.py","test_runtime_anchor_outcome.py"}
SCHEMA = "runtime_power2_registered_outcome_protocol_v1"


def context(reader):
    import audit_candidate_power2_window as terminal
    request,provenance,registry,sequences,common = terminal.context(reader)
    require(request.power == 2,"not the two-power context")
    recheck = lambda:terminal.check_policy(reader,request,registry,sequences,common,POLICY_SHA)
    policy = recheck()
    return request,provenance,terminal,recheck,policy


def protocol_payload(reader,request,provenance,terminal):
    from seal_candidate_window_disposition import NAMES as original_names
    base,bsha = original.check_protocol(reader,request,provenance,original_names,BASE_SHA)
    regression,rsha = reader.read_json(REGRESSION)
    require(regression["status"] == "PASS" and regression["current_candidate_future_access"] is False,
            "two-power observer regression missing")
    for name,digest in regression["sources"].items():
        reader.check_blob(Path("scripts")/name,digest)
    sources = {**base["sources"],**terminal.sources(),**{name:hashlib.sha256(
        reader.resolve(Path("scripts")/name).read_bytes()).hexdigest() for name in OWN_SOURCES}}
    return {**base,"schema":SCHEMA,"created_utc":utc(),"sources":sources,
        "original_continuation_protocol_sha256":bsha,"disposition_policy_sha256":POLICY_SHA,
        "runtime_anchor_protocol_document_sha256":hashlib.sha256(reader.resolve(DOCUMENT).read_bytes()).hexdigest(),
        "regression_report":str(REGRESSION),"regression_sha256":rsha,
        "shared_single_outcome_reservation":str(RUN),"registered_outcome_path":str(OUTCOME),
        "authorization_rule":"Explicit observation only after authenticated two-power terminal decision; pending is never permission.",
        "selection_scope":"Outcome-sealed execution of the original power ladder; not a fresh cohort.",
        "original_protocol_or_terminal_record_changed":False,"future_outcome_access":False,
        "automatic_outcome_join":False,"automatic_retry_or_resume":False}


def check_protocol(reader,request,provenance,terminal,expected_sha):
    saved,sha = reader.read_json(PROTOCOL,require_sha256(expected_sha))
    expected = protocol_payload(reader,request,provenance,terminal)
    expected["created_utc"] = saved.get("created_utc")
    require(saved == expected,"two-power observer protocol/runtime/sources changed")
    reader.check_sources(saved,required_names=frozenset(OWN_SOURCES|set(terminal.sources())))
    reader.check_blob(DOCUMENT,saved["runtime_anchor_protocol_document_sha256"])
    return saved,sha


def authorize_record(reader,request,terminal,recheck,disposition_sha,protocol_sha):
    from runtime_anchor_disposition import authenticate_record
    record = authenticate_record(reader,request=request,disposition_path=DISPOSITION,
        disposition_sha256=require_sha256(disposition_sha),policy_path=terminal.POLICY,policy_sha256=POLICY_SHA,
        recheck_policy=recheck,barrier=lambda:terminal.barrier(reader,request))
    require(record["record_authenticated"] is True and record["outcome_join_authorized"] is False and
            record["future_outcome_access"] is False and record["decision"] in ("certificate","route_abstention"),
            "invalid two-power terminal record")
    require_sha256(protocol_sha)
    return {**record,"outcome_join_authorized":True,
        "authorization_basis":"separately frozen two-power observation protocol",
        "observation_protocol_sha256":protocol_sha,
        "original_terminal_record_outcome_join_authorized":False,"original_terminal_record_changed":False}


def main(args):
    reader = EvidenceReader(ROOT)
    unopened(reader,RUN,OUTCOME)
    if args.mode != "freeze-protocol" and not reader.resolve(DISPOSITION).exists():
        if args.mode == "execute":
            raise EvidencePending("no two-power terminal decision; model not loaded")
        require(args.mode == "check","unknown observation mode")
        return {"status":"pending_runtime_anchor_disposition","model_loaded":False,"future_outcome_access":False}
    request,provenance,terminal,recheck,_ = context(reader)
    if args.mode == "freeze-protocol":
        require(not reader.resolve(DISPOSITION).exists() and not reader.resolve(PROTOCOL).exists(),
                "freeze observer before terminal decision; no overwrite")
        payload = protocol_payload(reader,request,provenance,terminal)
        reader.check_sources(payload,required_names=frozenset(OWN_SOURCES|set(terminal.sources())))
        unopened(reader,RUN,OUTCOME)
        sha = publish_json(reader.resolve(PROTOCOL),payload)
        check_protocol(reader,request,provenance,terminal,sha)
        return {"status":"power2_observer_frozen","protocol_path":str(PROTOCOL),"protocol_sha256":sha,
                "model_loaded":False,"future_outcome_access":False}
    protocol,psha = check_protocol(reader,request,provenance,terminal,args.protocol_sha256)
    gate = authorize_record(reader,request,terminal,recheck,args.disposition_sha256,psha)
    if args.mode == "check":
        return {"status":"authenticated_for_explicit_separate_execution","gate":gate,"model_loaded":False,"future_outcome_access":False}
    require(args.mode == "execute" and original.memory_available_mib() >= protocol["minimum_free_mib"],
            "explicit execution and memory admission required")
    observed = dict(reader.observed)
    def recheck_inputs():
        for path,digest in observed.items():
            reader.check_blob(path,digest)
        require(not reader.resolve(OUTCOME).exists(),"outcome appeared during execution")
    return execute_once(reader,gate=gate,protocol=protocol,protocol_sha256=psha,run_folder=RUN,outcome_path=OUTCOME,
        prepare=lambda:original.NeuralObserver(reader,protocol),recheck=recheck_inputs,
        progress=lambda j,n:print(json.dumps({"observed_step":j,"correct_count":n}),flush=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode",choices=("check","freeze-protocol","execute"),default="check")
    parser.add_argument("--protocol-sha256")
    parser.add_argument("--disposition-sha256")
    print(json.dumps(main(parser.parse_args()),indent=2))
