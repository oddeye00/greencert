"""Verify the known initial injection; no neural query or future continuation."""
import os
os.environ["OPENBLAS_NUM_THREADS"]="1"
os.environ["OMP_NUM_THREADS"]="1"
os.environ["MKL_NUM_THREADS"]="1"
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import time
import numpy as np

from audit_candidate_window_assembly import ROOT,SOURCE,CON,load_request
from green_family_evidence import checked_array,require
from known_anchor_propagation import first_homogeneous_step
from registered_outcome_continuation import publish_json,utc
from verified_artifact_io import EvidenceReader

ENCODING_SOURCES=frozenset({"audit_candidate_known_anchor.py","known_anchor_response.py","test_known_anchor_response.py",
    "anchor_response_evidence.py","audit_candidate_window_assembly.py","candidate_evidence_context.py",
    "verified_artifact_io.py","registered_outcome_continuation.py"})


def main(args):
    started=time.perf_counter()
    reader=EvidenceReader(ROOT)
    request,context=load_request(reader,source=SOURCE,construction=CON,power=1)
    forbidden=(SOURCE/"reveal.json",SOURCE/"registered_outcome_run")
    require(all(not reader.resolve(path).exists() for path in forbidden),"outcome barrier open")
    names=("audit_candidate_anchor_first_step.py","known_anchor_propagation.py","test_known_anchor_propagation.py",
           "known_anchor_response.py","green_family_evidence.py","registered_outcome_continuation.py")
    sources={name:hashlib.sha256((ROOT/"scripts"/name).read_bytes()).hexdigest() for name in names}
    for name,sha in sources.items(): reader.check_blob(Path("scripts")/name,sha)
    record,encoding_sha=reader.read_json(args.encoding_record,args.encoding_sha256)
    reader.check_sources(record,required_names=ENCODING_SOURCES)
    require(record["identity"]==asdict(request.identity) and record["candidate_sha256"]==request.identity.candidate_sha256 and
            record["reference_sha256"]==request.identity.reference_sha256 and record["parameters"]==request.identity.parameters and
            record["horizon"]==request.identity.horizon and record["future_outcome_access"] is False and
            record["original_certificate_gamma_replaced"] is False and record["homogeneous_response_computed"] is False and
            record["offset_sign"]=="eta*original_unscaled_velocity - reference_scaled_velocity","foreign or relabeled anchor encoding")
    for path,sha in record["observed_artifact_hashes"].items(): reader.check_blob(path,sha)
    delta=checked_array(reader,record["vector_path"],record["vector_sha256"],request.identity.parameters)
    result=first_homogeneous_step(delta,momentum=request.momentum)
    state=result.pop("next_state")
    for path,sha in tuple(reader.observed.items()): reader.check_blob(path,sha)
    require(all(not reader.resolve(path).exists() for path in forbidden),"outcome barrier changed")
    timestamp=utc()
    folder=CON/"known_anchor_first_step"/timestamp.replace(":","").replace("-","")
    reader.resolve(folder).mkdir(parents=True,exist_ok=False)
    path=folder/"response_001.npy"
    with reader.resolve(path).open("xb") as stream: np.save(stream,state,allow_pickle=False)
    state_sha=hashlib.sha256(reader.resolve(path).read_bytes()).hexdigest()
    output={"utc":timestamp,"identity":asdict(request.identity),"encoding_record":args.encoding_record,
        "encoding_sha256":encoding_sha,"encoded_velocity_sha256":record["vector_sha256"],
        "state_path":str(path),"state_sha256":state_sha,"step":1,**result,
        "initial_encoding_injection_tail_upper":record["unrepresented_first_injection_norm_upper"],
        "full_homogeneous_response_verified":False,"remaining_homogeneous_steps":request.identity.horizon-1,
        "original_first_injection_bound_still_in_force":record["original_first_injection_bound_still_in_force"],
        "event_certificate_issued":False,"future_outcome_access":False,"sources":sources,
        "observed_artifact_hashes":reader.observed,"seconds":time.perf_counter()-started,
        "scope":"one exact-rational verified initial homogeneous step; not a full-window response"}
    audit=folder/"audit.json"
    sha=publish_json(reader.resolve(audit),output)
    print(json.dumps({key:output[key] for key in ("step","local_residual_norm_upper","parameter_response_norm_upper",
        "remaining_homogeneous_steps","seconds","event_certificate_issued")} |
        {"output":str(audit),"sha256":sha,"state_sha256":state_sha},indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--encoding-record",required=True)
    parser.add_argument("--encoding-sha256",required=True)
    main(parser.parse_args())
