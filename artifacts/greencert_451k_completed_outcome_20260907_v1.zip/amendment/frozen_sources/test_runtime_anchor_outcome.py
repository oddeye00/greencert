"""One-shot runtime observation tests on synthetic records and counter orbits."""
from contextlib import ExitStack, redirect_stdout
import copy
import hashlib
import io
from pathlib import Path
import json
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import continue_runtime_anchor_sealed_outcome as driver
from registered_outcome_continuation import publish_json
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError


def rejects(operation, error=IntegrityError):
    try:
        operation()
    except error:
        return 1
    raise AssertionError("invalid observer operation accepted")


def pending_tests():
    count = 0
    assert "torch" not in sys.modules and "numpy" not in sys.modules
    assert driver.RUN == driver.original.RUN and driver.OUTCOME == driver.original.OUTCOME
    for existing in ("none", "run", "reveal"):
        with TemporaryDirectory(prefix="greencert_runtime_pending_") as temp, ExitStack() as stack:
            root = Path(temp)
            stack.enter_context(patch.object(driver, "ROOT", root))
            context = stack.enter_context(patch.object(driver, "context", side_effect=AssertionError("early context load")))
            model = stack.enter_context(patch.object(driver.original, "NeuralObserver", side_effect=AssertionError("early model load")))
            if existing == "run": (root / driver.RUN).mkdir(parents=True)
            elif existing == "reveal": publish_json(root / driver.OUTCOME, {"synthetic": True})
            if existing == "none":
                assert driver.main(SimpleNamespace(mode="check"))["status"] == "pending_runtime_anchor_disposition"
                count += rejects(lambda: driver.main(SimpleNamespace(mode="execute")), EvidencePending)
                assert not (root / driver.RUN).exists()
            else:
                for mode in ("check", "execute", "freeze-protocol"):
                    count += rejects(lambda: driver.main(SimpleNamespace(mode=mode)))
            assert not context.called and not model.called
    assert "torch" not in sys.modules and "numpy" not in sys.modules
    return count


def integration():
    from runtime_anchor_disposition import publish_fresh
    from test_runtime_anchor_disposition import publication_fixture
    from test_registered_outcome_continuation import CounterObserver, scalar_tests
    totals = {"protocol_freezes": 0, "real_record_authentications": 0, "synthetic_observations": 0,
              "refusals": 0, "retained_interruptions": 0}
    for scenario in ("correct", "wrong", "absent", "interruption", "source_change"):
        with TemporaryDirectory(prefix="greencert_runtime_observer_") as temp, ExitStack() as stack:
            root = Path(temp) / "fixture"
            f = publication_fixture(root)
            request = f["request"]
            for name in driver.OWN_SOURCES | {"base_observer.py"}:
                (root / "scripts" / name).write_text("# synthetic observer source\n")
            (root / driver.DOCUMENT).write_text("synthetic protocol\n")
            publish_json(root / driver.REGRESSION, {"status": "PASS", "current_candidate_future_access": False, "sources": {}})
            base = {"schema": "synthetic_original_observer", "created_utc": "fixture",
                "sources": {"base_observer.py": hashlib.sha256((root / "scripts/base_observer.py").read_bytes()).hexdigest()},
                "horizon": request.identity.horizon, "target": request.target, "persistence": request.persistence,
                "evaluation_count": len(request.example_ids), "anchor": 100, "predicted_offset": 2,
                "minimum_free_mib": 2048, "runtime": {"fixture": True}, "initial_velocity": "original physical state"}
            terminal = SimpleNamespace(POLICY=Path("policy.json"),
                sources=lambda: {"verifier.py": hashlib.sha256((root / "scripts/verifier.py").read_bytes()).hexdigest()},
                barrier=lambda *a: f["barrier"]())
            stack.enter_context(patch.object(driver, "ROOT", root))
            stack.enter_context(patch.object(driver, "POLICY_SHA", f["policy_sha256"]))
            stack.enter_context(patch.object(driver, "context", return_value=(request, {}, terminal, f["recheck_policy"], {})))
            stack.enter_context(patch.object(driver.original, "check_protocol", side_effect=lambda *a: (copy.deepcopy(base), driver.BASE_SHA)))
            model = stack.enter_context(patch.object(driver.original, "NeuralObserver"))
            args = SimpleNamespace(mode="freeze-protocol", protocol_sha256=None, disposition_sha256=None)
            frozen = driver.main(args)
            assert not frozen["model_loaded"] and not model.called
            totals["protocol_freezes"] += 1
            totals["refusals"] += rejects(lambda: driver.main(args))
            args.protocol_sha256 = frozen["protocol_sha256"]
            args.mode = "execute"
            totals["refusals"] += rejects(lambda: driver.main(args), EvidencePending)
            assert not (root / driver.RUN).exists() and not model.called
            f["disposition_path"] = driver.DISPOSITION
            published = publish_fresh(**f)
            terminal_bytes = (root / driver.DISPOSITION).read_bytes()
            args.disposition_sha256 = published["disposition_sha256"]
            args.mode = "check"
            checked = driver.main(args)
            assert checked["gate"]["outcome_join_authorized"] and not checked["gate"]["original_terminal_record_outcome_join_authorized"]
            assert not model.called and (root / driver.DISPOSITION).read_bytes() == terminal_bytes
            totals["real_record_authentications"] += 1
            for field in ("protocol_sha256", "disposition_sha256"):
                value = getattr(args, field)
                setattr(args, field, "0" * 64)
                totals["refusals"] += rejects(lambda: driver.main(args))
                setattr(args, field, value)
            args.mode = "execute"
            with patch.object(driver.original, "memory_available_mib", return_value=2047):
                totals["refusals"] += rejects(lambda: driver.main(args))
                assert not model.called and not (root / driver.RUN).exists()
            if scenario == "source_change":
                (root / "scripts/base_observer.py").write_text("changed")
                totals["refusals"] += rejects(lambda: driver.main(args))
                assert not model.called and not (root / driver.RUN).exists()
                continue
            counts = [0, 0] + [request.target] * (request.identity.horizon - 1)
            if scenario == "wrong": counts[1] = request.target
            elif scenario == "absent": counts = [0] * (request.identity.horizon + 1)
            model.side_effect = lambda *a: CounterObserver(counts, fail=1 if scenario == "interruption" else None)
            with patch.object(driver.original, "memory_available_mib", return_value=4096), redirect_stdout(io.StringIO()):
                if scenario == "interruption":
                    totals["refusals"] += rejects(lambda: driver.main(args), RuntimeError)
                    assert (root / driver.RUN / "interrupted.json").exists() and not (root / driver.OUTCOME).exists()
                    assert (root / driver.RUN / "intent_001.json").exists()
                    totals["retained_interruptions"] += 1
                else:
                    result = driver.main(args)
                    record, _ = EvidenceReader(root).read_json(driver.OUTCOME, result["outcome_sha256"])
                    assert record["observed_first_persistent_offset"] == {"correct": 2, "wrong": 1, "absent": None}[scenario]
                    assert record["observed_float64_crossing_in_bracket"] is (scenario == "correct")
                    assert record["exact_real_continuation_verified"] is False
                    totals["synthetic_observations"] += 1
                calls = model.call_count
                totals["refusals"] += rejects(lambda: driver.main(args))
                assert model.call_count == calls
            assert (root / driver.DISPOSITION).read_bytes() == terminal_bytes
    totals["unchanged_logger_regression"] = scalar_tests()
    return totals


def main():
    pending = pending_tests()
    result = integration()
    assert "torch" not in sys.modules
    root = Path(__file__).resolve().parents[1]
    names = driver.OWN_SOURCES | driver.original.OWN_SOURCES | {
        "runtime_anchor_disposition.py", "test_runtime_anchor_disposition.py", "verified_artifact_io.py"}
    report = {"status": "PASS", "pending_or_shared_barrier_refusals": pending, **result,
        "sources": {name: hashlib.sha256((root / "scripts" / name).read_bytes()).hexdigest() for name in sorted(names)},
        "torch_imported": False, "current_candidate_future_access": False,
        "scope": "real terminal authentication and one-shot dispatch on synthetic premises; no current-candidate observation"}
    digest = publish_json(root / driver.REGRESSION, report)
    print(json.dumps({**report, "report": str(driver.REGRESSION), "sha256": digest}, indent=2))


if __name__ == "__main__":
    main()
