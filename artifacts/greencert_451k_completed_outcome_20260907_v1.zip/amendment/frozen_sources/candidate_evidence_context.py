"""Bind a constructed candidate to its audited fixed example populations.

This exports identity, not a Green gain, derivative bound or certificate.
No future outcomes or neural computations are accessed.
"""
from pathlib import Path
from bound_row_evidence import PRODUCERS
from green_family_evidence import REQUIRED_SOURCES, canonical_sha, require
from window_event_assembly import Identity


def load_context(reader, *, source, construction):
    source,con=Path(source),Path(construction)
    require(not reader.resolve(source/"reveal.json").exists(),"future outcome already revealed")
    candidate,csha=reader.read_json(source/"candidate.json")
    reference,rsha=reader.read_json(con/"reference.json")
    gm,gsha=reader.read_json(con/"outward_green/method.json")
    reader.check_sources(gm,required_names=REQUIRED_SOURCES)
    require(reference["candidate_sha256"]==csha==gm["candidate_sha256"] and
            reference["corrected_scaled_sha256"]==gm["path_sha256"],"candidate/reference/Green identity mismatch")
    n,H=gm["parameters"],gm["horizon"]
    require(type(n) is int and n>0 and type(H) is int and H>0 and gm["state_dimension"]==2*n and
            reference["parameters"]==n and reference["horizon"]==H,"constructed dimension mismatch")
    require(gm["learning_rate"]==candidate["config"]["learning_rate"] and
            gm["momentum"]==candidate["config"]["momentum"],"optimizer identity mismatch")
    baseline=con/"outward_bound_rows/step_001"
    bm,bsha=reader.read_json(baseline/"method.json")
    required,protocol=PRODUCERS["original"]
    reader.check_sources(bm,required_names=required)
    reader.check_blob(protocol,bm["protocol_sha256"])
    independent,isha=reader.read_json(baseline/"independent_audit_231.json")
    reader.check_blob("scripts/audit_outward_bound_row_records.py",independent["auditor_sha256"])
    require(independent["method_sha256"]==bsha and independent["all_examples_verified"] is True and
            bm["candidate_sha256"]==csha and bm["path_sha256"]==gm["path_sha256"] and bm["parameters"]==n,
            "baseline example population not authenticated")
    populations={}
    for split,count in (("training",bm["training_examples"]),("certification",bm["certification_examples"])):
        require(type(count) is int and count>0,"invalid audited population size")
        values=[]
        for index in range(count):
            path=baseline/f"{split}_{index:03d}.json"
            row,sha=reader.read_json(path,independent["record_hashes"][str(path)])
            require(row["method_sha256"]==bsha and row["split"]==split and row["index"]==index and
                    row["status"]=="verified","audited population row mismatch")
            values.append({"index":index,"pair":row["pair"],"label":row["label"]})
        populations[split]=values
    require([v["pair"] for v in populations["training"]]==gm["training_pairs"] and
            [v["label"] for v in populations["training"]]==gm["training_labels"] and
            len(populations["training"])==gm["training_examples"],"explicit training population mismatch")
    identity=Identity(csha,gm["path_sha256"],canonical_sha(populations["training"]),
                      canonical_sha(populations["certification"]),n,H,"scaled_momentum_euclidean")
    return {"identity":identity,"candidate":candidate,"reference":reference,"green_method":gm,
            "baseline_method":bm,"populations":populations,
            "provenance":{"candidate_sha256":csha,"reference_record_sha256":rsha,"green_method_sha256":gsha,
                          "baseline_method_sha256":bsha,"population_audit_sha256":isha},
            "anchor_paths":{"candidate_path":source/"candidate.json","reference_record_path":con/"reference.json",
                "checkpoint_path":source/"anchor.npz","corrected_path":con/"corrected_scaled.npy",
                "original_path":con/"reference_scaled.npy","audit_path":con/"anchor_scaling_audit.json"}}
