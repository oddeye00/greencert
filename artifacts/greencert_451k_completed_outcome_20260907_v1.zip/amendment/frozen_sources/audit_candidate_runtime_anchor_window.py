"""Explicit runtime-lineage composition of the physical-anchor window audit.

No numerical method, event rule, probability budget or original policy is
replaced. This wrapper can audit an enclosure, not seal an event disposition
or authorize an optimizer continuation. Marker checks perform no numerics.
"""
import argparse
import ast
from dataclasses import asdict
import json
from pathlib import Path
from types import SimpleNamespace

import audit_candidate_combined_anchor_response as response_audit
import audit_candidate_known_anchor_window as original_anchor
import audit_candidate_runtime_green as runtime_green
from continue_candidate_sealed_outcome import memory_available_mib
from dgx_green_transition_pilot import ROOT, REL, CON, sha
from green_family_evidence import require
from registered_outcome_continuation import publish_json, utc
from runtime_anchor_window_assembly import SCOPE, assemble_runtime_anchor_evidence
from verified_artifact_io import EvidenceReader, EvidencePending, require_sha256
from window_disposition import family_fingerprint

POLICY = CON / "runtime_anchor_window_policy.json"
PROTOCOL = Path("RUNTIME_ANCHOR_WINDOW_PROTOCOL.md")
HOMOGENEOUS_SHA = "1289675372f9341af8a59ab02571b88e208b7de048a77aa74bbddce228ce4376"
ANCHOR_POLICY_SHA = "fde3d4787aa8e51e9a0d3115878fffcf747de8efd93e1e0df19e3acc0889c051"
GREEN_POLICY_SHA = "544db443b38e29b90b2c4997476d5199b54a336dc6528e19e2319b316cf6490e"
JOIN_TEST = Path("results/runtime_anchor_window_contract_20260907.json")
POLICY_TEST = Path("results/runtime_anchor_window_policy_contract_20260907_attempt02.json")


def json_ready(value):
    def path_only(item):
        if isinstance(item, Path):
            return str(item)
        raise TypeError("unsupported audit JSON value: " + type(item).__name__)
    return json.loads(json.dumps(value, default=path_only, allow_nan=False))


def source_hashes():
    pending = [ROOT / "scripts" / name for name in (
        "audit_candidate_runtime_anchor_window.py", "test_candidate_runtime_anchor_window_policy.py",
        "test_runtime_anchor_window_assembly.py")]
    result = {}
    while pending:
        path = pending.pop()
        if path.name in result:
            continue
        result[path.name] = sha(path)
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
            names = [v.name for v in node.names] if isinstance(node, ast.Import) else (
                [node.module] if isinstance(node, ast.ImportFrom) and node.module else [])
            for name in names:
                candidate = ROOT / "scripts" / (name.replace(".", "/") + ".py")
                if candidate.is_file() and candidate.name not in result:
                    pending.append(candidate)
    return result


def forbidden_paths(request):
    return tuple(dict.fromkeys((*request.forbidden_outcome_files, str(REL / "reveal.json"),
        str(REL / "registered_outcome_run"), str(CON / "outward_window_disposition.json"),
        str(CON / "known_anchor_window_disposition.json"), str(CON / "runtime_anchor_window_disposition.json"))))


def barrier(reader, request):
    require(all(not reader.resolve(path).exists() for path in forbidden_paths(request)),
            "future or terminal disposition barrier opened")


def check_parents(reader, request, registry, sequences, common):
    original_anchor.check_policy(reader, request, policy_sha256=ANCHOR_POLICY_SHA,
                                 method_sha256=HOMOGENEOUS_SHA)
    parent, _ = reader.read_json(runtime_green.POLICY, GREEN_POLICY_SHA)
    reader.check_sources(parent, required_names=frozenset(runtime_green.sources()))
    canonical = lambda value: json.loads(json.dumps(value))
    require(parent["schema"] == "candidate_runtime_green_audit_v1" and
            parent["origin_method_sha256"] == request.green_method_sha256 and
            parent["execution_method_sha256"] == runtime_green.EXECUTION_SHA and
            parent["common_operator_sha256"] == common and
            parent["execution_plan_sha256"] == runtime_green.PLAN_SHA and
            parent["remote_ready_sha256"] == runtime_green.READY_SHA and
            parent["retirement_sha256"] == runtime_green.RETIREMENT_SHA and
            parent["identity"] == asdict(request.identity) and parent["power"] == request.power == 1 and
            parent["original_probe_hashes"] == list(request.original_probe_hashes) and
            parent["failure_probability"] == request.failure_probability and
            parent["execution_registry"] == canonical(registry) and
            parent["sequence_plan"] == canonical(sequences) and
            parent["future_outcome_access"] is False and parent["event_issuance_authorized"] is False and
            parent["outcome_observer_authorized"] is False, "runtime Green parent differs")


def expected_policy(reader, request, registry, sequences, common):
    barrier(reader, request)
    check_parents(reader, request, registry, sequences, common)
    reports = {}
    for path in (JOIN_TEST, POLICY_TEST):
        report, digest = reader.read_json(path)
        require(report["status"] == "PASS" and report["event_certificates_issued"] == 0,
                "unverified composition regression report")
        for source, source_sha in report["sources"].items():
            reader.check_blob(source, source_sha)
        reports[str(path)] = digest
    payload = {"schema": "candidate_runtime_anchor_window_policy_v1", "scope": SCOPE,
        "window_family_sha256": family_fingerprint(request), "request": asdict(request),
        "homogeneous_method_sha256": HOMOGENEOUS_SHA, "original_anchor_policy_sha256": ANCHOR_POLICY_SHA,
        "runtime_green_policy_sha256": GREEN_POLICY_SHA, "common_operator_sha256": common,
        "execution_registry": registry, "sequence_plan": sequences,
        "sources": source_hashes(), "protocol_sha256": sha(reader.resolve(PROTOCOL)),
        "regression_reports": reports, "power": 1, "failure_probability": request.failure_probability,
        "original_numerical_methods_changed": False, "original_event_rule_changed": False,
        "original_records_relabelled": False, "event_issuance_authorized": False,
        "outcome_join_authorized": False, "future_outcome_access": False,
        "development_scope": "execution-lineage composition after partial construction; not fresh confirmation",
        "rule": "fresh physical-response audit and complete runtime Green family plus original derivative/output evidence"}
    return json_ready(payload)


def completion_markers(request, sequences):
    result = [Path(request.response_folder) / "summary.json",
        Path(request.reference_margin_folder) / "summary.json",
        CON / "known_anchor_homogeneous/construction_summary.json"]
    result.extend(Path(row.folder) / "summary.json" for row in request.row_plan)
    result.extend(Path(location["folder"]) / "summary.json"
                  for powers in sequences for pair in powers for location in pair.values())
    require(len(set(result)) == len(result), "duplicate completion dependency")
    return result


def run(args):
    reader = EvidenceReader(ROOT)
    request, context, registry, sequences, common = runtime_green.context(reader)
    payload = expected_policy(reader, request, registry, sequences, common)
    if args.mode == "freeze-policy":
        require(not reader.resolve(POLICY).exists(), "runtime-anchor policy already frozen")
        barrier(reader, request)
        digest = publish_json(reader.resolve(POLICY), payload)
        return {"status": "assembly_policy_frozen", "policy_sha256": digest,
            "source_count": len(payload["sources"]), "event_certificate_issued": False,
            "outcome_join_authorized": False, "future_outcome_access": False}
    require_sha256(args.policy_sha256)
    policy, digest = reader.read_json(POLICY, args.policy_sha256)
    require(policy == payload, "runtime-anchor policy, code or protocol changed")
    missing = []
    for path in completion_markers(request, sequences):
        try:
            reader.read_json(path, allow_in_progress=True)
        except EvidencePending as error:
            missing.append({"path": str(path), "reason": str(error)})
    barrier(reader, request)
    if missing or args.mode == "check":
        return {"status": "pending_markers" if missing else "completion_markers_present",
            "policy_sha256": digest, "missing": missing, "missing_count": len(missing),
            "numerical_verification_performed": False, "event_certificate_issued": False,
            "outcome_join_authorized": False, "future_outcome_access": False,
            "scope": "completion-marker inventory, not a numerical bound or event certificate"}
    require(memory_available_mib() >= 1536, "full-window audit requires 1536MiB free")
    result = assemble_runtime_anchor_evidence(reader, request, executions=registry, sequence_plan=sequences,
        fresh_response_audit=lambda: response_audit.audit(SimpleNamespace(method_sha256=HOMOGENEOUS_SHA)),
        method_sha256=HOMOGENEOUS_SHA, required_audit_sources=frozenset(response_audit.NAMES),
        additional_forbidden_paths=forbidden_paths(request),
        progress=lambda name, status: print(json.dumps({"component": name, "status": status}), flush=True))
    require(expected_policy(reader, request, registry, sequences, common) == policy,
            "composition policy changed during numerical audit")
    for path, observed in tuple(reader.observed.items()):
        reader.check_blob(path, observed)
    barrier(reader, request)
    record = {"utc": utc(), "policy_sha256": digest, "request": asdict(request), "context": context,
        "result": result, "observed_artifact_hashes": reader.observed,
        "event_certificate_issued": False, "outcome_join_authorized": False, "future_outcome_access": False}
    path = CON / "runtime_anchor_window_audits" / (record["utc"].replace(":", "").replace("-", "") + ".json")
    result_sha = publish_json(reader.resolve(path), json_ready(record))
    return {"status": result["status"], "policy_sha256": digest, "output": str(path), "sha256": result_sha,
        "numerical_verification_performed": True, "event_certificate_issued": False,
        "outcome_join_authorized": False, "future_outcome_access": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("freeze-policy", "check", "audit"), default="check")
    parser.add_argument("--policy-sha256")
    print(json.dumps(run(parser.parse_args()), indent=2))
