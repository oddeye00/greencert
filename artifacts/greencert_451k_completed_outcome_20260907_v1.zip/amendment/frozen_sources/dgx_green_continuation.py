"""Separate recorded-runtime Green worker; never relabel origin products."""
import argparse
import ast
from datetime import datetime, timezone
import gc
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tarfile
import time

from dgx_green_transition_pilot import ROOT, REL, CON, GREEN, METHOD_SHA, PATH_SHA, sha, read, save, barriers, check
from runtime_green_contract import compare_methods, execution_method

INITIAL = GREEN / "probe_3/initial"
NEW = CON / "outward_green_dgx"
EXTRA = ("dgx_green_continuation.py", "runtime_green_contract.py", "dgx_green_transition_pilot.py")
PROTOCOL = "DGX_GREEN_CONTINUATION_PROTOCOL.md"
CONTROL_SHA = "7a8fd2591e94d813a7673c43e2e6687d441f02170e21405e7c971cc3ef7d8cf6"


def prepare():
    barriers(ROOT)
    origin = read(ROOT / GREEN / "method.json")
    check(sha(ROOT / GREEN / "method.json") == METHOD_SHA, "origin method differs")
    folder = ROOT / "results/dgx_green_continuation_20260907"
    check(not folder.exists(), "export already reserved")
    source = ROOT / "results/dgx_green_transition_pilot_20260907/arm64_execution/summary.json"
    check(sha(source) == CONTROL_SHA and read(source)["status"] == "PASS", "full-size portability control missing")
    test_path = ROOT / "results/runtime_green_contract_20260907.json"
    tests = read(test_path)
    check(tests["status"] == "PASS", "runtime identity tests missing")
    for rel, value in tests["sources"].items():
        check(sha(ROOT / rel) == value, "untested identity source")
    pending = [Path("scripts") / name for name in (*origin["sources"], *EXTRA, "test_runtime_green_contract.py")]
    sources = set()
    while pending:
        rel = pending.pop()
        if rel in sources:
            continue
        sources.add(rel)
        for node in ast.walk(ast.parse((ROOT / rel).read_text(encoding="utf-8"))):
            names = [v.name for v in node.names] if isinstance(node, ast.Import) else (
                [node.module] if isinstance(node, ast.ImportFrom) and node.module else [])
            for name in names:
                path = Path("scripts") / (name.replace(".", "/") + ".py")
                if (ROOT / path).is_file() and path not in sources:
                    pending.append(path)
    for name, value in origin["sources"].items():
        check(sha(ROOT / "scripts" / name) == value, "original kernel source changed")
    initial = read(ROOT / INITIAL / "summary.json")
    im = read(ROOT / INITIAL / "method.json")
    check(initial["complete"] is True and initial["method_sha256"] == sha(ROOT / INITIAL / "method.json")
          and initial["shape"] == [64, 902016] and len(initial["rows"]) == 64
          and im["contract"] == {"method_sha256": METHOD_SHA, "probe": 3}
          and initial["flat_npy_sha256"] == origin["initial_probe_flat_npy_sha256"][3], "original probe3 differs")
    rels = sources | {Path(PROTOCOL), test_path.relative_to(ROOT), GREEN / "method.json",
                     INITIAL / "method.json", INITIAL / "summary.json", REL / "candidate.json"}
    for j, row in enumerate(initial["rows"]):
        check(row["index"] == j and row["file"] == f"row_{j:03d}.npy"
              and sha(ROOT / INITIAL / row["file"]) == row["sha256"], "injection row differs")
        rels.add(INITIAL / row["file"])
    folder.mkdir(exist_ok=False)
    files = {}
    for rel in sorted(rels):
        target = folder / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / rel, target)
        check(sha(target) == sha(ROOT / rel), "export copy changed")
        files[rel.as_posix()] = sha(target)
    runtime = ROOT / "results/dgx_green_transition_pilot_20260907/expected_runtime.json"
    for path, name in ((source, "portability_control.json"), (runtime, "expected_runtime.json")):
        shutil.copyfile(path, folder / name)
        files[name] = sha(folder / name)
    plan = {"utc": datetime.now(timezone.utc).isoformat(), "origin_method_sha256": METHOD_SHA,
        "probe": 3, "power": 1, "phases": ["forward", "adjoint"], "threads": 1,
        "minimum_free_mib": 4096, "files": files,
        "external_blob": {"relative": str(CON / "corrected_scaled.npy").replace("\\", "/"), "sha256": PATH_SHA},
        "execution_sources": {name: sha(ROOT / "scripts" / name) for name in EXTRA},
        "execution_protocol_sha256": sha(ROOT / PROTOCOL), "portability_control_sha256": CONTROL_SHA,
        "requires_verified_local_worker_retirement": True, "regenerate_probes": False,
        "automatic_retry": False, "automatic_import": False, "event_certificate": False,
        "future_outcome_access": False}
    barriers(ROOT)
    save(folder / "execution_plan.json", plan)
    archive = folder.with_suffix(".tar")
    with tarfile.open(archive, "x") as handle:
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                handle.add(path, arcname=path.relative_to(folder).as_posix(), recursive=False)
    receipt = {"plan_sha256": sha(folder / "execution_plan.json"), "archive_sha256": sha(archive),
        "archive_bytes": archive.stat().st_size, "files": len(files), "python_sources": len(sources),
        "external_reference_must_be_authenticated_before_use": True, "future_outcome_access": False}
    save(folder / "export_receipt.json", receipt)
    print(__import__("json").dumps(receipt, indent=2), flush=True)


def authenticate(expected, *, full=True):
    check(sha(ROOT / "execution_plan.json") == expected, "execution plan differs")
    plan = read(ROOT / "execution_plan.json")
    check(plan["origin_method_sha256"] == METHOD_SHA and plan["probe"] == 3 and plan["power"] == 1
          and plan["phases"] == ["forward", "adjoint"] and plan["threads"] == 1
          and plan["future_outcome_access"] is False and plan["regenerate_probes"] is False
          and plan["automatic_retry"] is False and plan["automatic_import"] is False
          and plan["event_certificate"] is False and plan["requires_verified_local_worker_retirement"] is True,
          "execution scope differs")
    for rel, value in plan["files"].items():
        if full or not rel.endswith(".npy"):
            target = (ROOT / rel).resolve()
            check(target.is_relative_to(ROOT) and sha(target) == value, "execution input changed: " + rel)
    check(sha(ROOT / CON / "corrected_scaled.npy") == PATH_SHA, "reference changed")
    barriers(ROOT)
    return plan


def environment():
    check(sys.platform == "linux" and platform.machine() == "aarch64" and __debug__, "native ARM64 Linux without -O required")
    for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[key] = "1"
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    os.environ["MPLBACKEND"] = "Agg"
    import numpy as np
    import torch
    import flint
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.backends.mha.set_fastpath_enabled(False)
    torch.use_deterministic_algorithms(True)
    return {"python": sys.version, "numpy": np.__version__, "torch": torch.__version__,
            "python_flint": flint.__version__, "machine": platform.machine(), "platform": sys.platform,
            "accelerator": "cpu"}


def runtime_context():
    from transformer_hvp_grokking import TransformerConfig, make_template, flat_spec, make_disjoint_split
    origin = read(ROOT / GREEN / "method.json")
    config = TransformerConfig(**read(ROOT / REL / "candidate.json")["config"])
    model, data = make_template(config), make_disjoint_split(config)
    spec = flat_spec(model)
    eps = [[b.norm1.eps, b.norm2.eps] for b in model.blocks]
    expected = read(ROOT / "expected_runtime.json")
    actual = {"names": list(spec.names), "shapes": [list(s) for s in spec.shapes], "sizes": list(spec.sizes)}
    check(actual == expected["spec"] and eps == expected["normalization_eps"] == origin["normalization_eps"], "operator layout differs")
    check(data[0].tolist() == origin["training_pairs"] and data[1].tolist() == origin["training_labels"]
          and sum(spec.sizes) == 451008, "operator population differs")
    return config, spec, data, eps


def bootstrap(expected):
    # Reuse the already transferred immutable reference. No shared source or
    # file is rewritten; this new hard link names the same fixed dyadic data.
    check(sha(ROOT / "execution_plan.json") == expected, "plan differs before reference installation")
    reference = ROOT / CON / "corrected_scaled.npy"
    donor = ROOT.parent / "green-transition-pilot" / CON / "corrected_scaled.npy"
    check(sha(donor) == PATH_SHA and not reference.exists() and not (ROOT / NEW).exists(), "bootstrap target or donor differs")
    os.link(donor, reference)
    plan = authenticate(expected)
    runtime = environment()
    runtime_context()
    from checkpointed_green_products import StoredRows, save_json
    from test_checkpointed_green_products import main as stored_tests
    from test_factored_neural_green_products import main as neural_tests
    old = StoredRows(ROOT / INITIAL)
    check(old.flat_npy_sha256() == read(ROOT / GREEN / "method.json")["initial_probe_flat_npy_sha256"][3], "original Gaussian bytes differ")
    regressions = {"streaming": stored_tests(), "neural": neural_tests()}
    check(all(v["all_passed"] for v in regressions.values()), "original regressions failed")
    origin = read(ROOT / GREEN / "method.json")
    method = execution_method(origin, origin_sha256=METHOD_SHA, protocol_sha256=plan["execution_protocol_sha256"],
                              execution_sources=plan["execution_sources"], runtime=runtime)
    save_json(ROOT / NEW / "method.json", method)
    ready = {"status": "ready_without_neural_candidate_queries", "plan_sha256": expected,
        "execution_method_sha256": sha(ROOT / NEW / "method.json"), "runtime": runtime,
        "original_probe_sha256": old.flat_npy_sha256(), "regressions": regressions,
        "common_operator_sha256": compare_methods(origin, method, origin_sha256=METHOD_SHA,
            protocol_sha256=plan["execution_protocol_sha256"], execution_sources=plan["execution_sources"]),
        "future_outcome_access": False, "original_worker_may_still_be_live": True}
    authenticate(expected)
    save(ROOT / NEW / "ready.json", ready)
    print(__import__("json").dumps({"status": ready["status"], "ready_sha256": sha(ROOT / NEW / "ready.json"),
        "execution_method_sha256": ready["execution_method_sha256"]}, indent=2), flush=True)


def retirement(expected, plan_sha):
    path = ROOT / "windows_green_retirement.json"
    check(sha(path) == expected, "retirement receipt differs")
    value = read(path)
    check(value["status"] == "original_worker_retired_records_preserved" and value["exit_code"] == 130
          and value["origin_method_sha256"] == METHOD_SHA and value["remote_plan_sha256"] == plan_sha
          and value["remote_ready_sha256"] == sha(ROOT / NEW / "ready.json")
          and value["proof_files_removed"] is False and value["future_outcome_access"] is False,
          "local worker retirement is not authenticated")
    return value


def run(expected, handover):
    plan = authenticate(expected)
    retirement(handover, expected)
    out = ROOT / NEW / "execution"
    check(not out.exists(), "execution already reserved")
    memory = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
    check(int(memory["MemAvailable"].split()[0]) / 1024 >= plan["minimum_free_mib"], "memory admission")
    runtime = environment()
    cfg, spec, data, eps = runtime_context()
    import numpy as np
    from checkpointed_green_products import StoredRows, product
    from arb_factored_regularizer_hvp import factored_chunked_hvp
    method = read(ROOT / NEW / "method.json")
    check(method["runtime_versions"] == runtime, "runtime changed since bootstrap")
    compare_methods(read(ROOT / GREEN / "method.json"), method, origin_sha256=METHOD_SHA,
        protocol_sha256=plan["execution_protocol_sha256"], execution_sources=plan["execution_sources"])
    mh = sha(ROOT / NEW / "method.json")
    check(read(ROOT / NEW / "ready.json")["execution_method_sha256"] == mh, "ready method differs")
    out.mkdir(exist_ok=False)
    save(out / "start.json", {"utc": datetime.now(timezone.utc).isoformat(), "pid": os.getpid(),
        "proc_stat": Path("/proc/self/stat").read_text(), "plan_sha256": expected,
        "execution_method_sha256": mh, "retirement_sha256": handover, "future_outcome_access": False})
    raw = np.load(ROOT / CON / "corrected_scaled.npy", mmap_mode="r", allow_pickle=False)
    check(raw.shape == (65, 902016) and raw.dtype == np.float64, "reference layout differs")
    def guard():
        authenticate(expected, full=False)
        check(sha(ROOT / NEW / "method.json") == mh, "execution method changed")
        retirement(handover, expected)
    try:
        summaries = {}
        source = StoredRows(ROOT / INITIAL)
        check(source.flat_npy_sha256() == method["initial_probe_flat_npy_sha256"][3], "original probe identity changed")
        began = time.perf_counter()
        for transpose in (False, True):
            phase = "adjoint" if transpose else "forward"
            target = ROOT / NEW / "probe_3/power_01" / phase
            check(not target.exists(), "phase already reserved; no automatic retry")
            def hvp(j, direction):
                return factored_chunked_hvp(raw[j, :451008], data[0], data[1], spec, cfg,
                    normalization_eps=eps, direction=direction, chunk_size=8,
                    progress=lambda a, b: print(__import__("json").dumps({"phase": phase, "hvp_step": j,
                        "example_start": a, "example_end": b}), flush=True))
            def progress(row):
                print(__import__("json").dumps({"phase": phase, "completed_row": row["index"],
                    "seconds": row["seconds"], "local_residual_norm_upper": row["local_residual_norm_upper"]}), flush=True)
                gc.collect()
            result = product(target, source, hvp, learning_rate=cfg.learning_rate, momentum=cfg.momentum,
                transpose=transpose, precision_bits=128, contract={"method_sha256": mh, "probe": 3, "power": 1},
                progress=progress, guard=guard)
            check(result["complete"] is True and result["hvp_calls"] == 63, "incomplete product")
            summaries[phase] = sha(target / "summary.json")
            source = StoredRows(target)
        guard()
        save(out / "summary.json", {"status": "complete_single_probe_not_family", "probe": 3, "power": 1,
            "execution_method_sha256": mh, "product_manifests": summaries, "seconds": time.perf_counter() - began,
            "future_outcome_access": False, "event_certificate": False, "full_Green_bound": None})
    except Exception as error:
        save(out / "failure.json", {"type": type(error).__name__, "error": str(error)})
        raise


def launch(expected, handover):
    authenticate(expected)
    retirement(handover, expected)
    folder = ROOT / "green_launch"
    folder.mkdir(exist_ok=False)
    with (folder / "stdout.log").open("x") as out, (folder / "stderr.log").open("x") as err:
        child = subprocess.Popen([sys.executable, "-u", str(Path(__file__).resolve()), "run",
            "--plan-sha256", expected, "--handover-sha256", handover], cwd=ROOT,
            stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
    save(folder / "dispatch.json", {"pid": child.pid, "utc": datetime.now(timezone.utc).isoformat(),
        "plan_sha256": expected, "handover_sha256": handover,
        "proc_stat": Path(f"/proc/{child.pid}/stat").read_text(), "automatic_retry": False})
    print(__import__("json").dumps({"pid": child.pid, "dispatch_sha256": sha(folder / "dispatch.json")}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "bootstrap", "launch", "run"))
    parser.add_argument("--plan-sha256")
    parser.add_argument("--handover-sha256")
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare()
    elif args.mode == "bootstrap":
        bootstrap(args.plan_sha256)
    elif args.mode == "launch":
        launch(args.plan_sha256, args.handover_sha256)
    else:
        run(args.plan_sha256, args.handover_sha256)
