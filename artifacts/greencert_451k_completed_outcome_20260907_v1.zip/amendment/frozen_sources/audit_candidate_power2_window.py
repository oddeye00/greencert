"""Frozen two-power execution composition; no numerical kernels are changed."""
import argparse
import ast
from dataclasses import asdict
import json
from pathlib import Path
from types import SimpleNamespace

import seal_candidate_runtime_anchor_disposition as previous
from audit_candidate_window_assembly import load_request
import dgx_green_power2 as execution
from green_family_evidence import canonical_sha, require
from registered_outcome_continuation import publish_json, utc
from runtime_anchor_disposition import (POLICY_SCHEMA, SCOPE, primitive, plan_for,
                                        publish_fresh, authenticate_record)
from verified_artifact_io import EvidenceReader, EvidencePending, require_sha256
from window_disposition import family_fingerprint

ROOT, REL, CON = previous.ROOT, previous.REL, previous.CON
ASSEMBLY = CON/"runtime_power2_window_policy.json"
POLICY = CON/"runtime_power2_disposition_policy.json"
DISPOSITION = previous.DISPOSITION
DOCUMENT = Path("RUNTIME_POWER2_WINDOW_PROTOCOL.md")
REGRESSION = Path("results/runtime_power2_window_contract_20260907.json")
PREVIOUS_SHA = "0b19735580b1342e3de8d97edc13ca419077ff74ad9987b3f337b428963255a1"
BUNDLE = Path("results/dgx_green_power2_20260907")
PLAN_SHA = "ca55b71f5e86f39ca14f89e16f66a2483dfc29f04660c0f1227beb634faa12d6"
METHOD_SHA = "4260a4fa9fd31f79e0b382512a28b184265d3165e56935083131dea79ed4e160"
READY_SHA = "8dbe5d71e990ccf757158eb1a675787194f4c9ab16c3d9f0e607bbf356f4c1a7"


def sources():
    pending = [Path(__file__), ROOT/"scripts/test_runtime_power2_window.py"]
    result = {}
    while pending:
        path = pending.pop()
        if path.name in result:
            continue
        result[path.name] = execution.sha(path)
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
            imports = ([node.module] if isinstance(node,ast.ImportFrom) and node.module else
                       [a.name for a in node.names] if isinstance(node,ast.Import) else [])
            for module in imports:
                target = ROOT/"scripts"/(module.replace(".","/")+".py")
                if target.is_file() and target.name not in result:
                    pending.append(target)
    return result


def validate_extension(old, new, registry1, sequences1, registry2, sequences2):
    require(type(old.power) is int and type(new.power) is int, "integer powers required")
    before, after = primitive(asdict(old)), primitive(asdict(new))
    require(before.pop("power") == 1 and after.pop("power") == 2 and before == after,
            "power extension changed candidate, event or numerical premises")
    require(len(old.original_probe_hashes) == len(sequences1) == len(sequences2) == 4 and
            set(registry2) == set(registry1) | {"dgx_q2"} and "dgx_q2" not in registry1 and
            all(registry2[key] == value for key,value in registry1.items()), "original family/lineage changed")
    locations = []
    for probe,(first,powers) in enumerate(zip(sequences1,sequences2)):
        require(len(first) == 1 and len(powers) == 2 and powers[0] == first[0], "q1 sequence chain changed")
        expected = {phase:{"folder":str(execution.NEW/f"probe_{probe}/power_02/{phase}"),"method":"dgx_q2"}
                    for phase in ("forward","adjoint")}
        require(powers[1] == expected, "q2 sequence chain changed")
        locations.extend(str(Path(row["folder"])) for pair in powers for row in pair.values())
    require(len(set(locations)) == 16, "Green sequence role reused")


def barrier(reader, request):
    previous.barrier(reader,request)


def context(reader):
    old, provenance, registry1, sequences1, common = previous.context(reader)
    parent = previous.check_policy(reader,old,registry1,sequences1,common,PREVIOUS_SHA)
    require(parent["allowed_powers"] == [1,2] and parent["configured_execution_power"] == 1,
            "original decision budget differs")
    request, provenance2 = load_request(reader,source=REL,construction=CON,power=2)
    require(provenance2 == provenance,"request provenance changed")
    plan,_ = reader.read_json(BUNDLE/"execution_plan.json",PLAN_SHA)
    execution.validate_plan(plan)
    reader.check_blob(execution.AUDIT,execution.AUDIT_SHA)
    ready,_ = reader.read_json(BUNDLE/"manual_deployment/ready.json",READY_SHA)
    method,_ = reader.read_json(BUNDLE/"manual_deployment/method.json",METHOD_SHA)
    require(ready["status"] == "ready_q2_no_candidate_queries" and ready["plan_sha256"] == PLAN_SHA and
            ready["execution_method_sha256"] == METHOD_SHA and ready["future_outcome_access"] is False and
            ready["event_certificate"] is False and ready["tests"]["streaming"]["all_passed"] is True and
            ready["tests"]["neural"]["all_passed"] is True and ready["tests"]["q2"]["status"] == "PASS",
            "q2 runtime not admitted")
    for name,sha in ready["tests"]["q2"]["sources"].items():
        reader.check_blob(name,sha)
    reader.check_blob(execution.PROTOCOL,plan["execution_protocol_sha256"])
    origin,_ = reader.read_json(execution.GREEN/"method.json",execution.old.METHOD_SHA)
    require(execution.compare_methods(origin,method,origin_sha256=execution.old.METHOD_SHA,
            protocol_sha256=plan["execution_protocol_sha256"],execution_sources=plan["execution_sources"]) == common,
            "q2 operator differs")
    reader.check_sources(method,required_names=frozenset(method["sources"]))
    registry = {**registry1,"dgx_q2":{"method_path":str(BUNDLE/"manual_deployment/method.json"),
        "method_sha256":METHOD_SHA,"protocol_path":execution.PROTOCOL,
        "protocol_sha256":plan["execution_protocol_sha256"],"execution_sources":plan["execution_sources"]}}
    sequences = tuple((sequences1[p][0],{phase:{"folder":str(execution.NEW/f"probe_{p}/power_02/{phase}"),
                        "method":"dgx_q2"} for phase in ("forward","adjoint")}) for p in range(4))
    validate_extension(old,request,registry1,sequences1,registry,sequences)
    for item in plan["inputs"]:
        folder = Path(item["folder"])
        reader.read_json(folder/"summary.json",item["summary_sha256"])
        reader.read_json(folder/"method.json",item["method_sha256"])
        require(folder == Path(sequences[item["probe"]][0]["adjoint"]["folder"]), "q2 export used wrong q1 injection")
    barrier(reader,request)
    return request,provenance,registry,sequences,common


def expected_assembly(reader,request,registry,sequences,common):
    report, rsha = reader.read_json(REGRESSION)
    require(report["status"] == "PASS" and report["real_two_power_bridges"] == 2 and
            report["neural_certificates_issued"] == 0 and report["driver_pending_without_numerics"] >= 1,
            "two-power composition tests missing")
    for name,sha in report["sources"].items():
        reader.check_blob(name,sha)
    return primitive({"schema":"candidate_runtime_power2_anchor_window_policy_v1","scope":SCOPE,
        "request":asdict(request),"window_family_sha256":family_fingerprint(request),
        "previous_terminal_policy_sha256":PREVIOUS_SHA,"execution_plan_sha256":PLAN_SHA,
        "runtime_method_sha256":METHOD_SHA,"runtime_ready_sha256":READY_SHA,
        "execution_registry":registry,"sequence_plan":sequences,"common_operator_sha256":common,
        "homogeneous_method_sha256":previous.assembly.HOMOGENEOUS_SHA,"sources":sources(),
        "protocol_sha256":execution.sha(reader.resolve(DOCUMENT)),"regression_report":str(REGRESSION),
        "regression_sha256":rsha,"allowed_powers":[1,2],"power":2,
        "failure_probability":request.failure_probability,"original_records_relabelled":False,
        "event_rule_changed":False,"event_issuance_authorized":False,"outcome_join_authorized":False,
        "future_outcome_access":False})


def expected_policy(reader,request,registry,sequences,common,assembly_sha):
    parent,_ = reader.read_json(ASSEMBLY,require_sha256(assembly_sha))
    require(parent == expected_assembly(reader,request,registry,sequences,common),"power2 assembly policy changed")
    return primitive({"schema":POLICY_SCHEMA,"scope":SCOPE,"sources":sources(),
        "protocol_document_sha256":execution.sha(reader.resolve(DOCUMENT)),
        "regression_report":str(REGRESSION),"regression_sha256":parent["regression_sha256"],
        "window_family_sha256":family_fingerprint(request),"assembly_policy_sha256":assembly_sha,
        "previous_terminal_policy_sha256":PREVIOUS_SHA,
        "homogeneous_method_sha256":previous.assembly.HOMOGENEOUS_SHA,"common_operator_sha256":common,
        "execution_registry":registry,"sequence_plan":sequences,
        "execution_plan_sha256":canonical_sha({"executions":registry,"sequence_plan":sequences}),
        "allowed_powers":[1,2],"configured_execution_power":2,"failure_probability":request.failure_probability,
        "terminal_disposition_authorized":True,"outcome_join_authorized":False,"future_outcome_access":False,
        "original_issuance_policy_changed":False,
        "selection_scope":"Outcome-sealed execution of the original power ladder; not fresh confirmation.",
        "terminal_rule":"Fresh complete two-power enclosure may issue or exhaust the original [1,2] budget; missing or corrupt evidence cannot."})


def check_policy(reader,request,registry,sequences,common,expected_sha):
    saved,_ = reader.read_json(POLICY,require_sha256(expected_sha))
    require(saved == expected_policy(reader,request,registry,sequences,common,saved["assembly_policy_sha256"]),
            "power2 terminal policy changed")
    return saved


def run(args):
    reader = EvidenceReader(ROOT)
    request, provenance, registry, sequences, common = context(reader)
    if args.mode in ("freeze-assembly","freeze-terminal"):
        require(not reader.resolve(DISPOSITION).exists(),"disposition already exists")
        target = ASSEMBLY if args.mode == "freeze-assembly" else POLICY
        require(not reader.resolve(target).exists(),"policy already frozen")
        payload = (expected_assembly(reader,request,registry,sequences,common) if args.mode == "freeze-assembly" else
                   expected_policy(reader,request,registry,sequences,common,args.assembly_sha256))
        barrier(reader,request)
        return {"status":"power2_policy_frozen","path":str(target),
                "sha256":publish_json(reader.resolve(target),payload),"source_count":len(payload["sources"]),
                "event_certificate_issued":False,"future_outcome_access":False}
    recheck = lambda:check_policy(reader,request,registry,sequences,common,args.policy_sha256)
    policy = recheck()
    if args.mode == "audit-record":
        return authenticate_record(reader,request=request,disposition_path=DISPOSITION,
            disposition_sha256=args.disposition_sha256,policy_path=POLICY,policy_sha256=args.policy_sha256,
            recheck_policy=recheck,barrier=lambda:barrier(reader,request))
    require(not reader.resolve(DISPOSITION).exists(),"terminal record exists")
    missing = []
    for path in previous.assembly.completion_markers(request,sequences):
        try:
            reader.read_json(path,allow_in_progress=True)
        except EvidencePending as error:
            missing.append({"path":str(path),"reason":str(error)})
    if missing or args.mode == "check":
        return {"status":"pending_markers" if missing else "completion_markers_present","missing":missing,
                "missing_count":len(missing),"numerical_verification_performed":False,
                "event_certificate_issued":False,"outcome_join_authorized":False,"future_outcome_access":False}
    require(args.mode == "commit" and previous.assembly.memory_available_mib() >= 1536,
            "explicit fresh commit and1536MiB required")
    result = previous.assembly.assemble_runtime_anchor_evidence(reader,request,executions=registry,sequence_plan=sequences,
        fresh_response_audit=lambda:previous.assembly.response_audit.audit(SimpleNamespace(method_sha256=previous.assembly.HOMOGENEOUS_SHA)),
        method_sha256=previous.assembly.HOMOGENEOUS_SHA,required_audit_sources=frozenset(previous.assembly.response_audit.NAMES),
        additional_forbidden_paths=previous.assembly.forbidden_paths(request),
        progress=lambda name,status:print(json.dumps({"component":name,"status":status}),flush=True))
    plan = plan_for(request,result,policy)
    recheck()
    barrier(reader,request)
    for path,sha in tuple(reader.observed.items()):
        reader.check_blob(path,sha)
    record = {"utc":utc(),"policy_sha256":args.policy_sha256,"request":asdict(request),"context":provenance,
              "result":result,"plan":plan,"observed_artifact_hashes":dict(reader.observed)}
    path = CON/"runtime_power2_final_verifications"/(record["utc"].replace(":","").replace("-","")+".json")
    digest = publish_json(reader.resolve(path),primitive(record))
    outcome = publish_fresh(reader,request=request,result=result,audit_path=path,audit_sha256=digest,
        policy_path=POLICY,policy_sha256=args.policy_sha256,disposition_path=DISPOSITION,
        recheck_policy=recheck,barrier=lambda:barrier(reader,request))
    return {**outcome,"audit_path":str(path),"audit_sha256":digest,"future_outcome_access":False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode",choices=("freeze-assembly","freeze-terminal","check","commit","audit-record"),default="check")
    parser.add_argument("--assembly-sha256")
    parser.add_argument("--policy-sha256")
    parser.add_argument("--disposition-sha256")
    print(json.dumps(run(parser.parse_args()),indent=2))
