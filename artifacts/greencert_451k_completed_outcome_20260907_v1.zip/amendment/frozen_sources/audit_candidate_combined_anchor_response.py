"""Audit the larger candidate's combined response; never issue or reveal.

Missing full products return pending before expensive response verification.
The numerical audit, when possible, rechecks the physical encoding relation,
the original response, all homogeneous rows, and exact dyadic vector sums.
"""
import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path

import numpy as np

from anchor_response_evidence import (authenticate_anchor, authenticate_response,
                                      original_checkpoint, reference_prefix)
from build_candidate_known_anchor_response import prepare
from audit_candidate_window_assembly import ROOT, SOURCE, CON
from checkpointed_green_products import json_bytes
from combined_anchor_response import combine
from continue_candidate_sealed_outcome import memory_available_mib
from green_family_evidence import require
from homogeneous_response_evidence import authenticate
from known_anchor_response import encode_velocity_offset
from registered_outcome_continuation import publish_json, utc
from verified_artifact_io import EvidenceReader, EvidencePending, require_sha256

NAMES = ("audit_candidate_combined_anchor_response.py", "homogeneous_response_evidence.py",
    "combined_anchor_response.py", "test_combined_anchor_evidence.py", "known_anchor_response.py",
    "anchor_response_evidence.py", "green_family_evidence.py", "bulk_gram_evidence.py",
    "outward_optimizer_bulk.py", "verified_artifact_io.py", "build_candidate_known_anchor_response.py",
    "continue_candidate_sealed_outcome.py", "registered_outcome_continuation.py",
    "test_candidate_combined_anchor_audit.py")


def audit(args):
    require_sha256(args.method_sha256)
    reader = EvidenceReader(ROOT)
    def barrier():
        require(not reader.resolve(SOURCE/"reveal.json").exists() and
                not reader.resolve(SOURCE/"registered_outcome_run").exists(), "future barrier open")
    barrier()
    folder = CON/"known_anchor_homogeneous"
    # Never pass an unfinished prefix to a scalar closure, even for diagnostics.
    method, mh = reader.read_json(folder/"method.json", args.method_sha256)
    construction, _ = reader.read_json(folder/"construction_summary.json")
    require(construction["complete"] is True and construction["method_sha256"] == mh,
            "incomplete/foreign homogeneous construction")
    require(memory_available_mib() >= 1536, "full combined audit requires1536MiB free memory")
    reader, request, context, encoded, expected, guard = prepare(method["encoding_record"], method["encoding_sha256"])
    require(method == expected and hashlib.sha256(json_bytes(expected)).hexdigest() == mh,
            "construction method differs from current authenticated inputs")
    reader.check_blob(folder/"method.json", mh)
    construction, construction_sha = reader.read_json(folder/"construction_summary.json")
    require(construction["complete"] is True and construction["method_sha256"] == mh,
            "homogeneous construction changed")
    product = folder/"product"
    saved, product_sha = reader.read_json(product/"summary.json")
    require(construction == {"method_sha256":mh, **saved}, "construction/product summaries disagree")
    sources = {name:hashlib.sha256((ROOT/"scripts"/name).read_bytes()).hexdigest() for name in NAMES}
    for name, sha in sources.items():
        reader.check_blob(Path("scripts")/name,sha)
    anchor = authenticate_anchor(reader,identity=request.identity,**request.anchor_paths)
    candidate = context["candidate"]
    n,H = request.identity.parameters,request.identity.horizon
    cp = original_checkpoint(reader,request.anchor_paths["checkpoint_path"],candidate["anchor_sha256"],n)
    center = reference_prefix(reader,request.anchor_paths["corrected_path"],request.identity.reference_sha256,
                              shape=(H+1,2*n))[0]
    # Recompute the exact rational conversion rather than trusting a zero-tail flag.
    replay = encode_velocity_offset(cp["velocity"],center[n:],learning_rate=request.learning_rate,
                                    momentum=request.momentum)
    require(np.array_equal(replay["encoded_velocity_offset"],encoded), "physical anchor encoding differs")
    tail = replay["unrepresented_first_injection_norm_upper"]
    require(tail == method["initial_encoding_injection_tail_upper"] and
            method["original_first_injection_bound_still_in_force"] == anchor.first_injection_error_upper,
            "encoding tail or original anchor bound differs")
    original = authenticate_response(reader,request.response_folder,identity=request.identity,anchor=anchor,
        gradient_folder=request.gradient_folder,training_count=len(request.training_examples),
        progress=lambda j,h:print(json.dumps({"phase":"original_response","row":j,"horizon":h}),flush=True))
    homogeneous = authenticate(reader,product,identity=request.identity,summary_sha256=product_sha,
        operator_sha256=mh,encoding_sha256=method["encoding_sha256"],encoded_velocity_offset=encoded,
        learning_rate=request.learning_rate,momentum=request.momentum)
    profile = combine(reader,request.response_folder,original_evidence=original,homogeneous=homogeneous,
        encoding_injection_tail_upper=tail,block_size=4096,
        progress=lambda j,h:print(json.dumps({"phase":"combined_norm","row":j,"horizon":h}),flush=True))
    guard(); barrier()
    for path, sha in tuple(reader.observed.items()):
        reader.check_blob(path,sha)
    return {"status":"combined_response_audited_not_event_certified","profile":asdict(profile),
        "method_sha256":mh,"construction_sha256":construction_sha,
        "physical_encoding_replayed":True,"neural_hvps_replayed":False,
        "sources":sources,"observed_artifact_hashes":reader.observed,
        "original_issuance_policy_changed":False,"event_certificate_issued":False,"future_outcome_access":False}


def main(args):
    try:
        result = audit(args)
    except EvidencePending as error:
        result = {"status":"pending_complete_homogeneous_response","missing":str(error),"profile":None,
            "method_sha256":args.method_sha256,"event_certificate_issued":False,"future_outcome_access":False}
    record = {"utc":utc(),**result}
    path = CON/"combined_anchor_audits"/(record["utc"].replace(":","").replace("-","")+".json")
    sha = publish_json(ROOT/path,record)
    print(json.dumps({"status":record["status"],"output":str(path),"sha256":sha,
                      "event_certificate_issued":False},indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--method-sha256",required=True)
    main(parser.parse_args())
