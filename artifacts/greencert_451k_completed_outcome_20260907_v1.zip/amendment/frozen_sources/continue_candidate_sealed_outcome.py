"""Explicit, one-shot float64 outcome join for the registered larger candidate.

Default mode is read-only. The model module is imported only inside the
post-gate observer. This command is never called by a verification worker.
"""
import argparse
from dataclasses import asdict
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys

from registered_outcome_continuation import execute_once, publish_json, require, unopened, utc
from verified_artifact_io import EvidenceReader, EvidencePending, require_sha256

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path("results/larger_transformer_third_pass")
CON = SOURCE/"construction_03925"
PROTOCOL = CON/"outcome_continuation_protocol.json"
RUN = SOURCE/"registered_outcome_run"
OUTCOME = SOURCE/"reveal.json"
DISPOSITION = CON/"outward_window_disposition.json"
POLICY = CON/"outward_window_disposition_policy.json"
POLICY_SHA = "e798b53fa26c4db0788aa580de7af6ea873fd4ed59da5ee884084c9cf807b96e"
OWN_SOURCES = {"continue_candidate_sealed_outcome.py", "registered_outcome_continuation.py",
               "test_registered_outcome_continuation.py", "transformer_hvp_grokking.py"}


def runtime_versions():
    # Package metadata does not import torch or initialize a model.
    return {"python": platform.python_version(), "numpy": version("numpy"),
            "torch": version("torch"), "platform": platform.platform(),
            "machine": platform.machine()}


def memory_available_mib():
    if sys.platform == "win32":
        import ctypes
        class MemoryStatus(ctypes.Structure):
            _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong),
                        *((key, ctypes.c_ulonglong) for key in ("total_physical", "available_physical",
                          "total_page", "available_page", "total_virtual", "available_virtual", "extended"))]
        status = MemoryStatus()
        status.length = ctypes.sizeof(status)
        require(ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)) != 0,
                "cannot determine available memory")
        return status.available_physical / 2**20
    try:
        lines = Path("/proc/meminfo").read_text().splitlines()
        return float(next(line.split()[1] for line in lines if line.startswith("MemAvailable:"))) / 1024
    except (OSError, StopIteration, ValueError):
        raise RuntimeError("no memory availability backend on this platform") from None


def protocol_payload(reader, request, provenance, policy_sources):
    from window_disposition import family_fingerprint
    candidate, _ = reader.read_json(SOURCE/"candidate.json", request.identity.candidate_sha256)
    method, msha = reader.read_json(SOURCE/"method.json", provenance["selection_method_sha256"])
    sources = {name: hashlib.sha256(reader.resolve(Path("scripts")/name).read_bytes()).hexdigest()
               for name in sorted(OWN_SOURCES | set(policy_sources) | set(method["sources"]))}
    return {"schema": "registered_outcome_protocol_v1", "created_utc": utc(),
        "window_family_sha256": family_fingerprint(request), "identity": asdict(request.identity),
        "disposition_policy_sha256": POLICY_SHA, "selection_method_sha256": msha,
        "checkpoint_sha256": candidate["anchor_sha256"], "config": candidate["config"],
        "anchor": candidate["anchor"], "predicted_offset": candidate["predicted_offset"],
        "horizon": request.identity.horizon, "target": request.target, "persistence": request.persistence,
        "evaluation_count": len(request.evaluation_examples),
        "training_examples": request.training_examples, "evaluation_examples": request.evaluation_examples,
        "optimizer_update": "v = momentum*v + gradient(theta); theta = theta - learning_rate*v",
        "initial_velocity": "original unscaled dyadic checkpoint; not scaled reference coordinates",
        "runtime": runtime_versions(), "minimum_free_mib": 2048,
        "torch_interop_threads": 1, "torch_mha_fastpath": False, "deterministic_algorithms": True,
        "observation_scope": "float64 continuation; not an independent exact-real orbit enclosure",
        "protocol_document_sha256": hashlib.sha256(reader.resolve("REGISTERED_OUTCOME_CONTINUATION.md").read_bytes()).hexdigest(),
        "automatic_retry_or_resume": False, "automatic_outcome_join": False,
        "future_outcome_access": False, "sources": sources}


def check_protocol(reader, request, provenance, source_names, expected_sha):
    from window_disposition import family_fingerprint
    require_sha256(expected_sha)
    saved, sha = reader.read_json(PROTOCOL, expected_sha)
    expected = protocol_payload(reader, request, provenance, source_names)
    expected["created_utc"] = saved.get("created_utc")
    require(saved == expected, "continuation protocol, runtime, identity, or sources changed")
    require(saved["window_family_sha256"] == family_fingerprint(request), "foreign continuation family")
    reader.check_sources(saved, required_names=frozenset(OWN_SOURCES | set(source_names)))
    reader.check_blob("REGISTERED_OUTCOME_CONTINUATION.md", saved["protocol_document_sha256"])
    return saved, sha


class NeuralObserver:
    """Literal registered optimizer and evaluation-set observer, initialized after gate."""
    def __init__(self, reader, protocol):
        import numpy as np
        import torch
        import transformer_hvp_grokking as neural
        from anchor_response_evidence import original_checkpoint
        self.np, self.torch, self.neural = np, torch, neural
        self.config = neural.TransformerConfig(**protocol["config"])
        require(self.config.dtype == "float64" and self.config.loss == "cross_entropy",
                "unsupported registered continuation dtype/loss")
        torch.set_num_threads(self.config.threads)
        torch.set_num_interop_threads(protocol["torch_interop_threads"])
        torch.backends.mha.set_fastpath_enabled(protocol["torch_mha_fastpath"])
        torch.use_deterministic_algorithms(protocol["deterministic_algorithms"])
        self.template = neural.make_template(self.config)
        self.spec = neural.flat_spec(self.template)
        n = protocol["identity"]["parameters"]
        require(sum(self.spec.sizes) == n, "model parameter count changed")
        values = original_checkpoint(reader, SOURCE/"anchor.npz", protocol["checkpoint_sha256"], n)
        self.parameter = torch.from_numpy(values["parameter"].copy())
        self.velocity = torch.from_numpy(values["velocity"].copy())
        data = neural.make_disjoint_split(self.config)
        for examples, pair_index, label_index in ((protocol["training_examples"],0,1),
                                                 (protocol["evaluation_examples"],4,5)):
            require(data[pair_index].tolist() == [x["pair"] for x in examples] and
                    data[label_index].tolist() == [x["label"] for x in examples],
                    "registered data split/order mismatch")
        self.data = data
        self.runtime = {**runtime_versions(), "threads": torch.get_num_threads(),
                        "interop_threads": torch.get_num_interop_threads(), "device": "cpu",
                        "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
                        "mha_fastpath": torch.backends.mha.get_fastpath_enabled()}

    def advance(self):
        gradient = self.neural.gradient(self.parameter, self.data[0], self.data[1],
                                        self.template, self.spec, self.config)
        self.velocity = self.config.momentum * self.velocity + gradient
        self.parameter = self.parameter - self.config.learning_rate * self.velocity
        require(bool(self.torch.isfinite(self.parameter).all()) and
                bool(self.torch.isfinite(self.velocity).all()), "nonfinite optimizer state")

    def observe(self):
        with self.torch.no_grad():
            values = self.neural.logits(self.parameter, self.data[4], self.template, self.spec)
            require(bool(self.torch.isfinite(values).all()), "nonfinite evaluation logits")
            predictions = values.argmax(1)
            count = int((predictions == self.data[5]).sum())
            tied = int((values == values.max(1, keepdim=True).values).sum(1).gt(1).sum())
        return {"correct_count": count, "evaluation_count": len(self.data[4]),
            "argmax_ties": tied, "argmax_tie_rule": "lowest class index (torch.argmax)",
            "predictions": predictions.tolist(),
            "logits_float64_hex": [[float(v).hex() for v in row] for row in values.tolist()],
            "parameter_sha256": hashlib.sha256(self.parameter.numpy().tobytes(order="C")).hexdigest(),
            "unscaled_velocity_sha256": hashlib.sha256(self.velocity.numpy().tobytes(order="C")).hexdigest()}


def main(args):
    reader = EvidenceReader(ROOT)
    unopened(reader, RUN, OUTCOME)
    # The incomplete-candidate path imports no numerical or model modules.
    if args.mode != "freeze-protocol" and not reader.resolve(DISPOSITION).exists():
        if args.mode == "execute":
            raise EvidencePending("no sealed disposition; model not loaded and continuation refused")
        return {"status": "pending_disposition", "model_loaded": False, "future_outcome_access": False}
    from audit_candidate_window_assembly import load_request
    from seal_candidate_window_disposition import NAMES
    from window_disposition import check_policy, authenticate_outcome_gate
    request, provenance = load_request(reader, source=SOURCE, construction=CON, power=args.power)
    check_policy(reader, request, policy_path=POLICY, policy_sha256=POLICY_SHA,
                 required_source_names=frozenset(NAMES))
    if args.mode == "freeze-protocol":
        require(not reader.resolve(DISPOSITION).exists(), "freeze continuation before final disposition")
        payload = protocol_payload(reader, request, provenance, NAMES)
        require(not reader.resolve(PROTOCOL).exists(), "continuation protocol already frozen")
        reader.check_sources(payload, required_names=frozenset(OWN_SOURCES | set(NAMES)))
        reader.check_blob("REGISTERED_OUTCOME_CONTINUATION.md", payload["protocol_document_sha256"])
        unopened(reader, RUN, OUTCOME)
        sha = publish_json(reader.resolve(PROTOCOL), payload)
        return {"protocol_path": str(PROTOCOL), "protocol_sha256": sha,
                "model_loaded": False, "future_outcome_access": False}
    protocol, psha = check_protocol(reader, request, provenance, NAMES, args.protocol_sha256)
    gate = authenticate_outcome_gate(reader, request=request, disposition_path=DISPOSITION,
        disposition_sha256=args.disposition_sha256, policy_path=POLICY, policy_sha256=POLICY_SHA,
        required_source_names=frozenset(NAMES))
    if args.mode == "check":
        return {"status": "authenticated_for_explicit_separate_execution", "gate": gate,
                "model_loaded": False, "future_outcome_access": False}
    require(args.mode == "execute", "unknown outcome mode")
    require(memory_available_mib() >= protocol["minimum_free_mib"], "insufficient free memory; no run reserved")
    observed = dict(reader.observed)
    def recheck():
        for path, sha in observed.items():
            reader.check_blob(path, sha)
        require(not reader.resolve(OUTCOME).exists(), "future output appeared during execution")
    return execute_once(reader, gate=gate, protocol=protocol, protocol_sha256=psha,
        run_folder=RUN, outcome_path=OUTCOME, prepare=lambda: NeuralObserver(reader, protocol), recheck=recheck,
        progress=lambda j, n: print(json.dumps({"observed_step": j, "correct_count": n}), flush=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("check", "freeze-protocol", "execute"), default="check")
    parser.add_argument("--power", type=int, choices=(1,2), default=1)
    parser.add_argument("--protocol-sha256")
    parser.add_argument("--disposition-sha256")
    print(json.dumps(main(parser.parse_args()), indent=2))
