"""Runtime terminal semantics/publication tests; no real neural event issued."""
import copy
from contextlib import ExitStack, redirect_stdout
from dataclasses import asdict, replace
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

from checkpointed_green_products import digest, save_json
from file_backed_window_assembly import fingerprint
from green_family_evidence import canonical_sha
import known_anchor_disposition as old
from registered_outcome_continuation import publish_json
import runtime_anchor_disposition as gate
import seal_candidate_runtime_anchor_disposition as driver
from test_known_anchor_disposition import complete
from verified_artifact_io import EvidenceReader, IntegrityError
from window_disposition import family_fingerprint


def runtime_fixture(root, H=6):
    request, previous = complete(root, H)
    request = replace(request, response_folder=Path(request.response_folder),
        reference_margin_folder=Path(request.reference_margin_folder), green_folder=Path(request.green_folder),
        row_plan=tuple(replace(row, folder=Path(row.folder)) for row in request.row_plan))
    previous["request_sha256"] = fingerprint(request)
    registry = {"dgx": {"method_sha256": "b" * 64}}
    sequences = tuple(({phase: {"folder": f"runtime/probe_{i}/{phase}", "method": "dgx"}
                        for phase in ("forward", "adjoint")},) for i in range(len(request.original_probe_hashes)))
    result = copy.deepcopy(previous)
    result["schema"] = gate.ASSEMBLY_SCHEMA
    result["execution_plan_sha256"] = canonical_sha({"executions": registry, "sequence_plan": sequences})
    result["original_records_relabelled"] = False
    result["authenticated_components"] = ["runtime_green" if name == "green" else name
                                           for name in result["authenticated_components"]]
    result["provenance"].pop("green")
    result["provenance"]["runtime_green"] = {"original_records_relabelled": False, "neural_hvps_replayed": False,
        "array_norms_replayed": True, "event_certificate_issued": False, "future_outcome_access": False,
        "power": request.power, "complete_probes": len(request.original_probe_hashes),
        "origin_method_sha256": request.green_method_sha256, "executions": registry}
    return request, result, previous, registry, sequences


def refuses(operation):
    try:
        operation()
    except (IntegrityError, FileExistsError):
        return 1
    raise AssertionError("invalid terminal operation accepted")


def publication_fixture(root):
    request, result, _, registry, sequences = runtime_fixture(root)
    verifier = root / "scripts/verifier.py"
    verifier.write_text("# synthetic verifier\n")
    policy = {"schema": gate.POLICY_SCHEMA, "scope": gate.SCOPE,
        "window_family_sha256": family_fingerprint(request), "homogeneous_method_sha256": "a" * 64,
        "assembly_policy_sha256": "f" * 64, "allowed_powers": [1, 2],
        "failure_probability": request.failure_probability, "terminal_disposition_authorized": True,
        "outcome_join_authorized": False, "future_outcome_access": False, "original_issuance_policy_changed": False,
        "execution_registry": registry, "sequence_plan": gate.primitive(sequences),
        "execution_plan_sha256": result["execution_plan_sha256"], "sources": {"verifier.py": digest(verifier)}}
    save_json(root / "policy.json", policy)
    psha = digest(root / "policy.json")
    reader = EvidenceReader(root)
    def recheck():
        value, _ = reader.read_json("policy.json", psha)
        reader.check_sources(value, required_names=frozenset({"verifier.py"}))
        return value
    def barrier():
        gate.require(not (root / "future.json").exists(), "future open")
    plan = gate.plan_for(request, result, policy)
    audit = {"policy_sha256": psha, "request": asdict(request), "result": result, "plan": plan,
             "observed_artifact_hashes": {"witness.txt": digest(root / "witness.txt")}}
    save_json(root / "audit.json", gate.primitive(audit))
    return dict(reader=reader, request=request, result=result, audit_path="audit.json",
        audit_sha256=digest(root / "audit.json"), policy_path="policy.json", policy_sha256=psha,
        disposition_path="disposition.json", recheck_policy=recheck, barrier=barrier)


def driver_fixture(root, stack):
    request, result, _, registry, sequences = runtime_fixture(root)
    result["method_sha256"] = driver.assembly.HOMOGENEOUS_SHA
    result["provenance"]["known_anchor_response"]["method_sha256"] = driver.assembly.HOMOGENEOUS_SHA
    con, rel = Path("construction"), Path("source")
    for name in ("seal_candidate_runtime_anchor_disposition.py", "test_runtime_anchor_disposition.py"):
        (root / "scripts" / name).write_text("# synthetic policy source\n")
    document = Path("terminal.md")
    (root / document).write_text("synthetic terminal protocol\n")
    for name, value in (("ROOT", root), ("CON", con), ("REL", rel), ("DOCUMENT", document),
                        ("POLICY", con / "policy.json"), ("DISPOSITION", con / "terminal.json")):
        stack.enter_context(patch.object(driver, name, value))
    stack.enter_context(patch.object(driver.assembly, "CON", con))
    stack.enter_context(patch.object(driver.assembly, "REL", rel))
    context = stack.enter_context(patch.object(driver, "context", return_value=(request, {}, registry, sequences, "c" * 64)))
    stack.enter_context(patch.object(driver, "check_assembly_parent", return_value=({}, [1, 2])))
    save_json(root / driver.REGRESSION, {"status": "PASS", "neural_certificates_issued": 0, "sources": {}})
    return request, result, registry, sequences, context


def main():
    counts = {"unchanged_semantic_comparisons": 0, "nonterminal_cases": 0, "semantic_refusals": 0,
        "synthetic_publications": 0, "record_and_publication_refusals": 0,
        "driver_pending_checks": 0, "driver_fresh_commits": 0, "driver_post_publication_audits": 0,
        "driver_refusals": 0, "neural_certificates_issued": 0}
    with tempfile.TemporaryDirectory(prefix="greencert_runtime_terminal_") as temp:
        top = Path(temp)
        request, result, previous, _, _ = runtime_fixture(top / "semantics")
        def plan(req=request, value=result):
            return gate.plan_disposition(req, value, allowed_powers=(1, 2), method_sha256="a" * 64,
                                          execution_plan_sha256=result["execution_plan_sha256"])
        assert plan() == old.plan_disposition(request, previous, allowed_powers=(1, 2), method_sha256="a" * 64)
        counts["unchanged_semantic_comparisons"] += 1
        for kind in ("missing", "green", "closure", "event"):
            value = copy.deepcopy(result)
            if kind == "missing": value.update(status="pending", missing=[{"component": "runtime_green"}], assembly=None)
            elif kind == "green": value.update(status="no_finite_green_bound_at_requested_power", assembly=None)
            elif kind == "closure":
                value["status"] = "assembly_abstention"
                value["assembly"].update(bracket=None, reason="state_closure_failed")
                value["assembly"]["state_closure"].update(closure=False, radius=None)
            else:
                value["status"] = "assembly_abstention"
                value["assembly"].update(bracket=None, reason="persistent_event_not_enclosed", lower_counts=[0] * 7, upper_counts=[0] * 7)
            assert plan(value=value)["terminal"] is False
            counts["nonterminal_cases"] += 1
            if kind != "missing":
                later = replace(request, power=2)
                value["request_sha256"] = fingerprint(later)
                value["provenance"]["runtime_green"]["power"] = 2
                assert plan(req=later, value=value)["decision"] == "route_abstention"
                counts["unchanged_semantic_comparisons"] += 1
        mutations = (
            lambda r: r.update(schema="wrong"), lambda r: r.update(scope="unconditional"),
            lambda r: r.update(execution_plan_sha256="e" * 64), lambda r: r.update(original_records_relabelled=True),
            lambda r: r["authenticated_components"].append("green"),
            lambda r: r["provenance"]["runtime_green"].update(power=True),
            lambda r: r["provenance"]["runtime_green"].update(complete_probes=0),
            lambda r: r["provenance"]["runtime_green"].update(origin_method_sha256="e" * 64),
            lambda r: r["provenance"]["runtime_green"].update(executions={}),
            lambda r: r["provenance"]["runtime_green"].update(array_norms_replayed=False),
            lambda r: r["provenance"]["runtime_green"].update(neural_hvps_replayed=True),
            lambda r: r.update(event_certificate_issued=True), lambda r: r.update(outcome_join_authorized=True),
            lambda r: r.update(future_outcome_access=True), lambda r: r.update(authenticated_derivative_steps=[1]),
            lambda r: r["provenance"]["known_anchor_response"].update(physical_encoding_replayed=False),
            lambda r: r["assembly"]["state_closure"].update(first_injection_error=0.),
            lambda r: r["assembly"]["state_closure"].update(radius=.5),
            lambda r: r["assembly"].update(lower_counts=[0] * 6),
            lambda r: r["assembly"].update(bracket=[1, 4]),
            lambda r: r["assembly"].update(failure_probability=2e-7))
        for mutate in mutations:
            value = copy.deepcopy(result)
            mutate(value)
            counts["semantic_refusals"] += refuses(lambda: plan(value=value))
        for i, change in enumerate((None, "fresh_result", "audit_digest", "policy_digest", "source", "witness", "future")):
            kw = publication_fixture(top / f"publication{i}")
            root = kw["reader"].root
            if change == "fresh_result": kw["result"]["assembly"]["bracket"] = [1, 4]
            elif change == "audit_digest": kw["audit_sha256"] = "0" * 64
            elif change == "policy_digest": kw["policy_sha256"] = "0" * 64
            elif change == "source": (root / "scripts/verifier.py").write_text("changed")
            elif change == "witness": (root / "witness.txt").write_text("changed")
            elif change == "future": (root / "future.json").write_text("{}")
            if change is not None:
                counts["record_and_publication_refusals"] += refuses(lambda: gate.publish_fresh(**kw))
                continue
            published = gate.publish_fresh(**kw)
            assert published["published"] and not published["outcome_join_authorized"]
            counts["synthetic_publications"] += 1
            auth = {k: v for k, v in kw.items() if k not in ("result", "audit_path", "audit_sha256")}
            auth["disposition_sha256"] = published["disposition_sha256"]
            assert gate.authenticate_record(**auth)["record_authenticated"]
            counts["record_and_publication_refusals"] += refuses(lambda: gate.publish_fresh(**kw))
            saved = json.loads((root / "disposition.json").read_text())
            saved["outcome_join_authorized"] = True
            (root / "disposition.json").write_text(json.dumps(saved))
            auth["reader"] = EvidenceReader(root)
            auth["disposition_sha256"] = digest(root / "disposition.json")
            counts["record_and_publication_refusals"] += refuses(lambda: gate.authenticate_record(**auth))
        with ExitStack() as stack:
            root = top / "driver"
            request, result, registry, sequences, _ = driver_fixture(root, stack)
            frozen = driver.run(SimpleNamespace(mode="freeze-policy"))
            args = SimpleNamespace(mode="commit", policy_sha256=frozen["policy_sha256"], disposition_sha256=None)
            response = stack.enter_context(patch.object(driver.assembly.response_audit, "audit", return_value={"fresh": True}))
            join = stack.enter_context(patch.object(driver.assembly, "assemble_runtime_anchor_evidence"))
            pending = driver.run(args)
            assert pending["status"] == "pending_markers" and not join.called and not response.called
            counts["driver_pending_checks"] += 1
            for path in driver.assembly.completion_markers(request, sequences): save_json(root / path, {"marker": True})
            args.mode = "check"
            assert driver.run(args)["status"] == "completion_markers_present" and not join.called
            counts["driver_pending_checks"] += 1
            stack.enter_context(patch.object(driver.assembly, "memory_available_mib", return_value=4096))
            def numerical(reader, req, **kwargs):
                assert kwargs["fresh_response_audit"]() == {"fresh": True}
                assert kwargs["executions"] == registry and kwargs["sequence_plan"] == sequences
                return copy.deepcopy(result)
            join.side_effect = numerical
            args.mode = "commit"
            with redirect_stdout(io.StringIO()): published = driver.run(args)
            assert published["published"] and not published["outcome_join_authorized"] and response.call_count == join.call_count == 1
            counts["driver_fresh_commits"] += 1
            counts["driver_refusals"] += refuses(lambda: driver.run(args))
            args.mode, args.disposition_sha256 = "audit-record", published["disposition_sha256"]
            assert driver.run(args)["record_authenticated"] and join.call_count == 1
            counts["driver_post_publication_audits"] += 1
        for i, change in enumerate(("target", "policy_digest", "source", "document", "future", "competing_terminal",
                                   "memory", "during_source", "during_marker", "during_future", "during_plan")):
            with ExitStack() as stack:
                root = top / f"driver_bad{i}"
                request, result, registry, sequences, context = driver_fixture(root, stack)
                frozen = driver.run(SimpleNamespace(mode="freeze-policy"))
                args = SimpleNamespace(mode="commit", policy_sha256=frozen["policy_sha256"], disposition_sha256=None)
                for path in driver.assembly.completion_markers(request, sequences): save_json(root / path, {"marker": True})
                stack.enter_context(patch.object(driver.assembly, "memory_available_mib", return_value=0 if change == "memory" else 4096))
                def corrupt():
                    if "source" in change: (root / "scripts/seal_candidate_runtime_anchor_disposition.py").write_text("changed")
                    elif change == "document": (root / driver.DOCUMENT).write_text("changed")
                    elif "future" in change:
                        (root / driver.REL).mkdir(exist_ok=True)
                        (root / driver.REL / "reveal.json").write_text("{}")
                    elif change == "competing_terminal": save_json(root / driver.CON / "known_anchor_window_disposition.json", {})
                    elif change == "during_marker": (root / driver.assembly.completion_markers(request, sequences)[0]).write_text('{"changed":true}')
                    elif change == "during_plan": registry["dgx"]["method_sha256"] = "e" * 64
                if change == "target": context.return_value = (replace(request, target=2), {}, registry, sequences, "c" * 64)
                elif change == "policy_digest": args.policy_sha256 = "0" * 64
                elif not change.startswith("during_"): corrupt()
                def numerical(reader, req, **kwargs):
                    if change.startswith("during_"): corrupt()
                    else: raise AssertionError("invalid gate reached numerical work")
                    return copy.deepcopy(result)
                stack.enter_context(patch.object(driver.assembly, "assemble_runtime_anchor_evidence", side_effect=numerical))
                counts["driver_refusals"] += refuses(lambda: driver.run(args))
                assert not (root / driver.DISPOSITION).exists()
    root = Path(__file__).resolve().parents[1]
    report = {"status": "PASS", **counts,
        "scope": "synthetic semantic/publication and injected driver tests; no real neural certificate",
        "sources": {"scripts/" + name: digest(root / "scripts" / name) for name in
            ("runtime_anchor_disposition.py", "seal_candidate_runtime_anchor_disposition.py", "test_runtime_anchor_disposition.py")}}
    output_sha = publish_json(root / driver.REGRESSION, report)
    print(json.dumps({**report, "report": str(driver.REGRESSION), "sha256": output_sha}, indent=2))


if __name__ == "__main__":
    main()
