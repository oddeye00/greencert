"""Interruption, provenance, indexing and numerical-equivalence regressions."""
import io
import json
import hashlib
from pathlib import Path
import tempfile

import numpy as np
import torch
from flint import arb,ctx
from checkpointed_green_products import store_rows,product,StoredRows,digest,save_json
from outward_green_products import forward,adjoint
from arb_enclosed_direction_hvp import chunked_enclosed_direction_hvp
from transformer_hvp_grokking import TransformerConfig,make_template,flat_spec,flatten_parameters


def main():
    torch.set_num_threads(1);rng=np.random.default_rng(5291)
    reports={"all_passed":True,"exact_product_cases":0,"resumed_products":0,
             "recovered_array_only_interruptions":0,"corruption_rejections":0,
             "changed_contract_rejections":0,"gaussian_stream_identity_checks":0,
             "neural_parameterizations":0,"manifest_substitution_rejections":0,
             "aggregate_understatement_rejections":0}
    def rejects(call,key):
        try:call()
        except (ValueError,FileNotFoundError):reports[key]+=1
        else:raise AssertionError("bad input accepted")
    with tempfile.TemporaryDirectory(prefix="greencert-stream-tests-") as temp:
        root=Path(temp)
        for case,(H,n) in enumerate(( (1,2),(2,3),(4,5),(7,4) )):
            folder=root/f"case{case}";u=rng.normal(size=(H,2*n));buf=io.BytesIO();np.save(buf,u.reshape(-1))
            src=store_rows(folder/"input",iter(u),shape=u.shape,contract={"case":case},
                           expected_flat_npy_sha256=hashlib.sha256(buf.getvalue()).hexdigest())
            matrix=rng.normal(size=(H,n,n));matrix=(matrix+matrix.transpose(0,2,1))/16
            calls=[]
            def kernel(j,direction):
                calls.append(j)
                return [sum((arb(float(a))*b for a,b in zip(row,direction)),arb(0)) for row in matrix[j]]
            for trans in (False,True):
                out=folder/("adjoint" if trans else "forward")
                expected=(adjoint if trans else forward)(u,kernel,learning_rate=.03,momentum=.9,precision_bits=128)
                calls.clear()
                partial=product(out,src,kernel,learning_rate=.03,momentum=.9,transpose=trans,
                                precision_bits=128,contract={"operator":case},max_new_steps=1)
                if H>1:
                    assert not partial["complete"] and not (out/"summary.json").exists()
                result=product(out,src,kernel,learning_rate=.03,momentum=.9,transpose=trans,
                               precision_bits=128,contract={"operator":case})
                assert result["complete"] and len(calls)==H-1 and 0 not in calls
                rows=StoredRows(out);actual=np.stack([rows.row(j) for j in range(H)])
                assert np.array_equal(actual,expected["states"])
                assert [r["local_residual_norm_upper"] for r in result["rows"]]==expected["local_residuals"]
                assert result["residual_sequence_upper"]==expected["residual_sequence_upper"]
                assert result["terminal_sequence_norm_upper"]>=expected["terminal_sequence_norm_upper"]
                before=list(calls)
                again=product(out,src,kernel,learning_rate=.03,momentum=.9,transpose=trans,
                              precision_bits=128,contract={"operator":case})
                assert calls==before and again==result
                reports["exact_product_cases"]+=1;reports["resumed_products"]+=1
                rejects(lambda:product(out,src,kernel,learning_rate=.03,momentum=.9,transpose=trans,
                            precision_bits=128,contract={"operator":"changed"}),"changed_contract_rejections")
                damaged=out/"row_000.npy";original=damaged.read_bytes()
                # Test-fixture corruption, confined to the temporary directory.
                damaged.write_bytes(original[:-1]+bytes([original[-1]^1]))
                rejects(lambda:StoredRows(out),"corruption_rejections")
                damaged.write_bytes(original)
                rejects(lambda:store_rows(folder/"bad-hash",iter(u),shape=u.shape,contract={},
                            expected_flat_npy_sha256="0"*64),"corruption_rejections")
            interrupted=folder/"interrupted"
            def fault(j):raise RuntimeError("simulated interrupt after array write")
            try:product(interrupted,src,kernel,learning_rate=.03,momentum=.9,contract={},storage_fault_hook=fault)
            except RuntimeError:pass
            else:raise AssertionError("interruption hook did not fire")
            assert (interrupted/"row_000.npy").exists() and not (interrupted/"row_000.json").exists()
            product(interrupted,src,kernel,learning_rate=.03,momentum=.9,contract={})
            reports["recovered_array_only_interruptions"]+=1
        # CPU torch Gaussian chunks must reproduce the originally sealed vector.
        for H,d in ((3,32),(64,96),(5,902016)):
            seed=3747644135468465499
            a=torch.randn(H*d,generator=torch.Generator().manual_seed(seed),dtype=torch.float64).numpy()
            generator=torch.Generator().manual_seed(seed)
            b=np.concatenate([torch.randn(d,generator=generator,dtype=torch.float64).numpy() for _ in range(H)])
            assert np.array_equal(a,b);reports["gaussian_stream_identity_checks"]+=1
            del a,b
        for depth,norm in ((1,"none"),(2,"layernorm"),(4,"layernorm")):
            cfg=TransformerConfig(modulus=3,model_dim=4,hidden_dim=8,heads=1,depth=depth,
                                  normalization=norm,seed=41,learning_rate=.003,momentum=.9,weight_decay=.01)
            model=make_template(cfg);spec=flat_spec(model);p=flatten_parameters(model).numpy()
            eps=[(b.norm1.eps,b.norm2.eps) for b in model.blocks] if norm=="layernorm" else []
            pairs=np.array([[0,0],[1,2],[2,0]]);labels=pairs.sum(1)%3
            u=rng.normal(size=(3,2*len(p)))
            folder=root/f"neural-{depth}-{norm}"
            src=store_rows(folder/"input",iter(u),shape=u.shape,contract={})
            def kernel(j,direction):
                return chunked_enclosed_direction_hvp(p,pairs,labels,spec,cfg,normalization_eps=eps,
                                                      direction=direction,chunk_size=2)
            f=product(folder/"f",src,kernel,learning_rate=.003,momentum=.9,contract={})
            fs=StoredRows(folder/"f")
            t=product(folder/"t",fs,kernel,learning_rate=.003,momentum=.9,transpose=True,contract={})
            expectedf=forward(u,kernel,learning_rate=.003,momentum=.9)
            expectedt=adjoint(expectedf["states"],kernel,learning_rate=.003,momentum=.9)
            for out,expected in ((folder/"f",expectedf),(folder/"t",expectedt)):
                data=StoredRows(out)
                assert np.array_equal(np.stack([data.row(j) for j in range(3)]),expected["states"])
                assert [r["local_residual_norm_upper"] for r in data.summary["rows"]]==expected["local_residuals"]
                manifest=out/"summary.json";original=manifest.read_bytes()
                modified=json.loads(original);modified["kind"]="input_rows"
                manifest.write_text(json.dumps(modified))
                rejects(lambda:StoredRows(out),"manifest_substitution_rejections")
                manifest.write_bytes(original)
                modified=json.loads(original);modified["residual_sequence_upper"]=0.
                manifest.write_text(json.dumps(modified))
                rejects(lambda:StoredRows(out),"aggregate_understatement_rejections")
                manifest.write_bytes(original)
            reports["neural_parameterizations"]+=1
    print(json.dumps(reports,indent=2));return reports


if __name__=="__main__":main()
