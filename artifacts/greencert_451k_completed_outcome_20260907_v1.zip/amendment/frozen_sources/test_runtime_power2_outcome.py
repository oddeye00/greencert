"""Run the existing independent observer-contract harness on the new wrapper.

The harness adapter is test-only; numerical modules and production globals
are not changed. Synthetic wrong/absent outcomes remain recorded failures.
"""
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

import continue_power2_sealed_outcome as driver
import test_runtime_anchor_outcome as harness


if __name__ == "__main__":
    with patch.object(harness,"driver",driver):
        pending = harness.pending_tests()
        integration = harness.integration()
    names = driver.OWN_SOURCES | {"registered_outcome_continuation.py","continue_candidate_sealed_outcome.py",
                                   "runtime_anchor_disposition.py","audit_candidate_power2_window.py"}
    report = {"status":"PASS","pending_refusals":pending,**integration,
              "current_candidate_future_access":False,"real_neural_observations":0,
              "sources":{name:hashlib.sha256((driver.ROOT/"scripts"/name).read_bytes()).hexdigest() for name in names}}
    path = driver.ROOT/driver.REGRESSION
    digest = driver.publish_json(path,report)
    print(json.dumps(report|{"sha256":digest},indent=2))
