"""Explicit, outcome-sealed homogeneous response construction for the candidate.

Default mode only checks inputs and proposes a content-addressed method. It
does not import Torch, allocate a full path, or query a neural derivative.
Construction requires that exact method digest and sufficient free memory.
No result from this producer can replace the original certificate by itself.
"""
import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
import argparse
from dataclasses import asdict
import gc
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import flint

from audit_candidate_anchor_first_step import ENCODING_SOURCES
from audit_candidate_window_assembly import ROOT, SOURCE, CON, load_request
from checkpointed_green_products import digest, json_bytes, save_json
from green_family_evidence import checked_array, require
from known_anchor_green_response import construct
from verified_artifact_io import EvidenceReader


NAMES = (
    "build_candidate_known_anchor_response.py", "known_anchor_green_response.py",
    "test_known_anchor_green_response.py", "known_anchor_propagation.py",
    "test_known_anchor_propagation.py", "known_anchor_response.py",
    "audit_candidate_anchor_first_step.py", "audit_candidate_window_assembly.py",
    "checkpointed_green_products.py", "outward_green_momentum.py",
    "outward_green_products.py", "arb_factored_regularizer_hvp.py",
    "arb_enclosed_direction_hvp.py", "arb_reverse.py", "arb_reverse_transformer.py",
    "arb_transformer_objective.py", "transformer_hvp_grokking.py",
    "green_family_evidence.py", "verified_artifact_io.py",
    "continue_candidate_sealed_outcome.py", "registered_outcome_continuation.py",
    "test_candidate_known_anchor_readiness.py",
)


def memory_available():
    # Reuse the native resource query; this does not execute an outcome join.
    from continue_candidate_sealed_outcome import memory_available_mib
    return memory_available_mib()*2**20


def prepare(encoding_record, encoding_sha256):
    reader = EvidenceReader(ROOT)
    forbidden = (SOURCE/"reveal.json", SOURCE/"registered_outcome_run")
    require(all(not reader.resolve(p).exists() for p in forbidden), "future outcome barrier open")
    request, provenance = load_request(reader, source=SOURCE, construction=CON, power=1)
    green_method, _ = reader.read_json(CON/"outward_green/method.json", request.green_method_sha256)
    candidate, _ = reader.read_json(SOURCE/"candidate.json", request.identity.candidate_sha256)
    context = {"green_method":green_method, "candidate":candidate, "provenance":provenance}
    record, sha = reader.read_json(encoding_record, encoding_sha256)
    reader.check_sources(record, required_names=ENCODING_SOURCES)
    require(record["identity"] == asdict(request.identity), "foreign encoding identity")
    require(record["offset_sign"] == "eta*original_unscaled_velocity - reference_scaled_velocity",
            "wrong anchor-offset sign")
    require(record["original_certificate_gamma_replaced"] is False and
            record["homogeneous_response_computed"] is False and
            record["future_outcome_access"] is False, "relabeled encoding record")
    for path, expected in record["observed_artifact_hashes"].items():
        reader.check_blob(path, expected)
    encoded = checked_array(reader, record["vector_path"], record["vector_sha256"],
                            request.identity.parameters)
    sources = {name:digest(ROOT/"scripts"/name) for name in NAMES}
    for name, expected in sources.items():
        reader.check_blob(Path("scripts")/name, expected)
    method = {
        "role": "outcome_sealed_known_anchor_response_development",
        "identity": asdict(request.identity), "encoding_record":str(encoding_record),
        "encoding_sha256":sha, "encoded_velocity_sha256":record["vector_sha256"],
        "initial_encoding_injection_tail_upper":record["unrepresented_first_injection_norm_upper"],
        "original_first_injection_bound_still_in_force":record["original_first_injection_bound_still_in_force"],
        "original_green_method_sha256":request.green_method_sha256,
        "sources":sources, "observed_artifact_hashes":dict(reader.observed),
        "learning_rate":request.learning_rate, "momentum":request.momentum,
        "precision_bits":128, "chunk_size":8, "threads":1,
        "training_examples":len(request.training_examples),
        "training_pairs":context["green_method"]["training_pairs"],
        "training_labels":context["green_method"]["training_labels"],
        "normalization_eps":context["green_method"]["normalization_eps"],
        "expected_hvp_indices":list(range(1, request.identity.horizon)),
        "python":sys.version, "numpy":np.__version__, "python_flint":flint.__version__,
        "torch_version":context["green_method"]["runtime_versions"]["torch"],
        "future_outcome_access":False, "event_certificate_issued":False,
        "scope":"full-window deterministic response only; no original-route policy amendment",
    }
    def guard():
        require(all(not reader.resolve(p).exists() for p in forbidden), "future outcome barrier opened")
        for path, expected in tuple(reader.observed.items()):
            reader.check_blob(path, expected)
    guard()
    return reader, request, context, encoded, method, guard


def main(args):
    if args.max_new_steps is not None:
        require(args.max_new_steps >= 0, "negative transition budget")
    reader, request, context, encoded, method, base_guard = prepare(
        args.encoding_record, args.encoding_sha256)
    mh = hashlib.sha256(json_bytes(method)).hexdigest()
    if args.mode == "check":
        print(json.dumps({"status":"ready_to_construct_when_resources_available",
            "proposed_method_sha256":mh, "horizon":request.identity.horizon,
            "parameters":request.identity.parameters,
            "remaining_hvp_calls":request.identity.horizon-1,
            "initial_encoding_injection_tail_upper":method["initial_encoding_injection_tail_upper"],
            "original_first_injection_bound_still_in_force":method["original_first_injection_bound_still_in_force"],
            "neural_queries":0, "worker_launched":False,
            "full_window_response_computed":False, "event_certificate_issued":False}, indent=2))
        return
    require(args.method_sha256 == mh, "explicit matching method digest required")
    require(memory_available() >= 1536*2**20, "construction requires at least 1536 MiB free memory")
    folder = reader.resolve(CON/"known_anchor_homogeneous")
    save_json(folder/"method.json", method)
    def guard():
        base_guard()
        require(digest(folder/"method.json") == mh, "homogeneous method changed")

    # No Torch import or model allocation precedes the explicit resource gate.
    import torch
    from arb_factored_regularizer_hvp import factored_chunked_hvp
    from transformer_hvp_grokking import TransformerConfig, make_template, flat_spec, make_disjoint_split
    require(torch.__version__ == method["torch_version"], "Torch runtime differs")
    torch.set_num_threads(1)
    torch.backends.mha.set_fastpath_enabled(False)
    torch.use_deterministic_algorithms(True)
    cfg = TransformerConfig(**context["candidate"]["config"])
    model = make_template(cfg)
    spec = flat_spec(model)
    data = make_disjoint_split(cfg)
    eps = [(block.norm1.eps, block.norm2.eps) for block in model.blocks]
    require(sum(spec.sizes) == request.identity.parameters, "parameter dimension differs")
    require(data[0].tolist() == method["training_pairs"] and
            data[1].tolist() == method["training_labels"], "training population differs")
    require([list(v) for v in eps] == method["normalization_eps"], "normalization constants differ")
    del model
    raw = np.load(reader.resolve(CON/"corrected_scaled.npy"), mmap_mode="r", allow_pickle=False)
    require(raw.shape == (request.identity.horizon+1, 2*request.identity.parameters)
            and raw.dtype == np.float64, "reference shape differs")
    def kernel(j, direction):
        require(1 <= j < request.identity.horizon, "homogeneous HVP index outside contract")
        return factored_chunked_hvp(raw[j,:request.identity.parameters], data[0], data[1],
            spec, cfg, normalization_eps=eps, direction=direction, chunk_size=8,
            progress=lambda a,b:print(json.dumps({"hvp_step":j,"example_start":a,
                                                 "example_end":b}), flush=True))
    def progress(row):
        print(json.dumps({"completed_step":row["index"]+1,
            "local_residual_norm_upper":row["local_residual_norm_upper"],
            "seconds":row["seconds"]}), flush=True)
        gc.collect()
    result = construct(folder/"product", encoded, kernel, horizon=request.identity.horizon,
        learning_rate=request.learning_rate, momentum=request.momentum,
        operator_sha256=mh, encoding_sha256=args.encoding_sha256,
        precision_bits=128, max_new_steps=args.max_new_steps, guard=guard, progress=progress)
    guard()
    if result["complete"]:
        save_json(folder/"construction_summary.json", {"method_sha256":mh, **result})
    print(json.dumps({"method_sha256":mh, **result}, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("check", "construct"), default="check")
    parser.add_argument("--encoding-record", required=True)
    parser.add_argument("--encoding-sha256", required=True)
    parser.add_argument("--method-sha256")
    parser.add_argument("--max-new-steps", type=int)
    main(parser.parse_args())
