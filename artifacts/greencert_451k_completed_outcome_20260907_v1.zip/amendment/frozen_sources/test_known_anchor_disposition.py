"""Count-level, physical-tail and immutable-publication contract fixtures.

Neural/Green adapters are injected. Synthetic terminal records in private
temporary directories are not certificates for the real Transformer.
"""
import copy
from dataclasses import asdict, replace
import itertools
import json
from pathlib import Path
import tempfile

import known_anchor_disposition as gate
from checkpointed_green_products import digest, save_json
from file_backed_window_assembly import fingerprint
from registered_outcome_continuation import publish_json, utc
from test_file_backed_window_assembly import setup
from test_known_anchor_window_assembly import record_fixture, invoke
from verified_artifact_io import EvidenceReader, IntegrityError
from window_disposition import family_fingerprint
from window_event_assembly import first_persistent


def complete(root,H=6):
    root.mkdir()
    request,args,evidence = setup(n=4,horizon=H)
    record = record_fixture(root,request,args["response"])
    result,_ = invoke(root,request,evidence,record)
    return request,result


def publication_fixture(root, *, abstain=False,power=1):
    request,result = complete(root)
    request = replace(request,power=power)
    result["request_sha256"] = fingerprint(request)
    if abstain:
        result.update(status="no_finite_green_bound_at_requested_power",assembly=None)
    verifier = root/"scripts/verifier.py"; verifier.write_text("# synthetic policy source\n")
    policy = {"schema":gate.POLICY_SCHEMA,"window_family_sha256":family_fingerprint(request),
        "scope":gate.SCOPE,"homogeneous_method_sha256":"a"*64,"assembly_policy_sha256":"f"*64,
        "allowed_powers":[1,2],"failure_probability":request.failure_probability,
        "terminal_disposition_authorized":True,"outcome_join_authorized":False,"future_outcome_access":False,
        "original_issuance_policy_changed":False,"sources":{"verifier.py":digest(verifier)}}
    save_json(root/"policy.json",policy); psha = digest(root/"policy.json")
    reader = EvidenceReader(root)
    def recheck():
        current,_ = reader.read_json("policy.json",psha)
        reader.check_sources(current,required_names=frozenset({"verifier.py"}))
        return current
    def barrier():
        gate.require(not (root/"future.json").exists() and not (root/"outcome_run").exists(),"future barrier open")
    plan = gate.plan_disposition(request,result,allowed_powers=(1,2),method_sha256="a"*64)
    audit = {"policy_sha256":psha,"request":asdict(request),"result":result,"plan":plan,
             "observed_artifact_hashes":{"witness.txt":digest(root/"witness.txt")}}
    save_json(root/"audit.json",audit)
    return dict(reader=reader,request=request,result=result,audit_path="audit.json",audit_sha256=digest(root/"audit.json"),
        policy_path="policy.json",policy_sha256=psha,disposition_path="disposition.json",recheck_policy=recheck,barrier=barrier)


def record_kwargs(kwargs,published):
    return {k:v for k,v in kwargs.items() if k not in ("result","audit_path","audit_sha256")} | {
        "disposition_sha256":published["disposition_sha256"]}


def refuses(fn):
    try:
        fn()
    except (IntegrityError,FileExistsError):
        return 1
    raise AssertionError("unsafe terminal behavior accepted")


def main():
    counts = {"nonterminal_plans":0,"semantic_refusals":0,"count_envelopes":0,
        "count_path_containment_checks":0,"synthetic_terminal_publications":0,
        "publication_or_record_refusals":0}
    with tempfile.TemporaryDirectory(prefix="greencert_anchor_disposition_") as temp:
        top = Path(temp)
        request,result = complete(top/"complete")
        def plan(req=request,value=result,powers=(1,2)):
            return gate.plan_disposition(req,value,allowed_powers=powers,method_sha256="a"*64)
        assert plan()["bracket"] == [2,2] and not plan()["event_certificate_issued"]
        pending = copy.deepcopy(result); pending.update(status="pending",missing=[{"component":"green"}],assembly=None)
        assert plan(value=pending)["reason"] == "evidence_pending"
        counts["nonterminal_plans"] += 1
        for why in ("green","closure","event"):
            value = copy.deepcopy(result)
            if why == "green": value.update(status="no_finite_green_bound_at_requested_power",assembly=None)
            elif why == "closure":
                value["status"] = "assembly_abstention"
                value["assembly"].update(bracket=None,reason="state_closure_failed")
                value["assembly"]["state_closure"].update(closure=False,radius=None)
            else:
                value["status"] = "assembly_abstention"
                value["assembly"].update(bracket=None,reason="persistent_event_not_enclosed",
                                          lower_counts=[0]*7,upper_counts=[0]*7)
            assert plan(value=value)["reason"] == "remaining_declared_powers"
            later = replace(request,power=2); value["request_sha256"] = fingerprint(later)
            final = plan(req=later,value=value)
            assert final["terminal"] and final["decision"] == "route_abstention"
            counts["nonterminal_plans"] += 1
        mutations = (
            lambda r:r.update(schema="outward_window_disposition_v1"),
            lambda r:r.update(scope="unconditional exact-real proof"),
            lambda r:r.update(method_sha256="e"*64),
            lambda r:r.update(request_sha256="e"*64),
            lambda r:r.update(event_definition={"target":2,"persistence":2}),
            lambda r:r.update(event_certificate_issued=True),
            lambda r:r.update(construction_disposition_sealed=True),
            lambda r:r.update(outcome_join_authorized=True),
            lambda r:r.update(original_issuance_policy_changed=True),
            lambda r:r.update(future_outcome_access=True),
            lambda r:r.update(neural_kernels_replayed=True),
            lambda r:r.update(conditional_on_validated_producers=False),
            lambda r:r.update(missing=[{"component":"green"}]),
            lambda r:r.update(authenticated_derivative_steps=[1,2]),
            lambda r:r["authenticated_components"].append("green"),
            lambda r:r["provenance"].pop("known_anchor_response"),
            lambda r:r["provenance"]["known_anchor_response"].update(physical_encoding_replayed=False),
            lambda r:r["provenance"]["known_anchor_response"].update(response_artifact_count=0),
            lambda r:r["provenance"]["known_anchor_response"]["profile"].update(parameter_norms=(0.,)*2),
            lambda r:r["provenance"]["known_anchor_response"]["profile"].update(residual_upper=None),
            lambda r:r["provenance"]["known_anchor_response"]["profile"].update(encoding_injection_tail_upper=0.),
            lambda r:r["assembly"].update(certificate_issued=True),
            lambda r:r["assembly"].update(probability_scope="deterministic"),
            lambda r:r["assembly"].update(failure_probability=2e-7),
            lambda r:r["assembly"]["state_closure"].update(first_injection_error=0.),
            lambda r:r["assembly"]["state_closure"].update(first_injection_error=None),
            lambda r:r["assembly"]["state_closure"].update(radius=float("inf")),
            lambda r:r["assembly"]["state_closure"].update(radius=.5),
            lambda r:r["assembly"]["state_closure"].update(horizon=2),
            lambda r:r["assembly"].update(lower_counts=[0]*6),
            lambda r:r["assembly"]["lower_counts"].__setitem__(0,True),
            lambda r:r["assembly"]["lower_counts"].__setitem__(0,99),
            lambda r:r["assembly"].update(bracket=[1,4]),
            lambda r:r["assembly"].update(bracket=[True,2]),
            lambda r:r.update(status="assembly_abstention"))
        for mutate in mutations:
            bad = copy.deepcopy(result); mutate(bad)
            counts["semantic_refusals"] += refuses(lambda:plan(value=bad))
        for powers in ((),(1,3),(True,2),(2,),[1,2]):
            counts["semantic_refusals"] += refuses(lambda:plan(powers=powers))
        # Exhaustive count-level containment under supplied envelopes. These
        # envelopes are controlled premises, not newly verified neural logits.
        short,record = complete(top/"count_paths",H=3)
        pairs = tuple((lo,hi) for lo in range(3) for hi in range(lo,3))
        for target,K in itertools.product((1,2),(1,2,3)):
            req = replace(short,target=target,persistence=K)
            value = copy.deepcopy(record)
            value["request_sha256"] = fingerprint(req)
            value["event_definition"] = {"target":target,"persistence":K}
            for intervals in itertools.product(pairs,repeat=4):
                low,high = (list(v) for v in zip(*intervals))
                left,right = first_persistent(high,target,K),first_persistent(low,target,K)
                bracket = [left,right] if left is not None and right is not None and 0 < left <= right else None
                value["status"] = "enclosure_available_for_separate_disposition" if bracket else "assembly_abstention"
                value["assembly"].update(lower_counts=low,upper_counts=high,bracket=bracket,
                    reason=None if bracket else "persistent_event_not_enclosed")
                proposed = plan(req=req,value=value)
                counts["count_envelopes"] += 1
                if proposed["decision"] == "certificate":
                    for path in itertools.product(*(range(lo,hi+1) for lo,hi in intervals)):
                        actual = first_persistent(path,target,K)
                        assert actual is not None and bracket[0] <= actual <= bracket[1]
                        counts["count_path_containment_checks"] += 1
        for i,(abstain,power) in enumerate(((False,1),(False,2),(True,2))):
            kwargs = publication_fixture(top/f"publication_{i}",abstain=abstain,power=power)
            published = gate.publish_fresh(**kwargs)
            assert published["published"] and not published["outcome_join_authorized"]
            checked = gate.authenticate_record(**record_kwargs(kwargs,published))
            assert checked["record_authenticated"] and not checked["outcome_join_authorized"]
            assert checked["event_certificate_issued"] is (not abstain)
            counts["synthetic_terminal_publications"] += 1
            counts["publication_or_record_refusals"] += refuses(lambda:gate.publish_fresh(**kwargs))
        early = publication_fixture(top/"early",abstain=True,power=1)
        assert not gate.publish_fresh(**early)["published"] and not (early["reader"].root/"disposition.json").exists()
        for i,change in enumerate(("fresh_result","audit_hash","policy_hash","audit_content","source","input",
                                   "future_file","future_directory")):
            kwargs = publication_fixture(top/f"bad_publish_{i}")
            root = kwargs["reader"].root
            if change == "fresh_result": kwargs["result"] = {**kwargs["result"],"scope":"changed"}
            elif change == "audit_hash": kwargs["audit_sha256"] = "0"*64
            elif change == "policy_hash": kwargs["policy_sha256"] = "0"*64
            elif change == "audit_content":
                audit = json.loads((root/"audit.json").read_text()); audit["plan"]["bracket"] = [1,3]
                (root/"audit.json").write_text(json.dumps(audit)); kwargs["audit_sha256"] = digest(root/"audit.json")
            elif change == "source": (root/"scripts/verifier.py").write_text("changed")
            elif change == "input": (root/"witness.txt").write_text("changed")
            elif change == "future_file": (root/"future.json").write_text("{}")
            elif change == "future_directory": (root/"outcome_run").mkdir()
            counts["publication_or_record_refusals"] += refuses(lambda:gate.publish_fresh(**kwargs))
            assert not (root/"disposition.json").exists()
        for i,change in enumerate(("scope","authority","bracket","false_issuance","identity","method","audit",
                                   "source","input","future_directory","untrusted_digest")):
            kwargs = publication_fixture(top/f"bad_record_{i}")
            published = gate.publish_fresh(**kwargs)
            root = kwargs["reader"].root
            if change in ("scope","authority","bracket","false_issuance","identity","method"):
                record = json.loads((root/"disposition.json").read_text())
                if change == "scope": record["numerical_scope"] = "unconditional"
                elif change == "authority": record["outcome_join_authorized"] = True
                elif change == "bracket": record["decision"]["bracket"] = [1,4]
                elif change == "false_issuance": record["event_certificate_issued"] = False
                elif change == "identity": record["identity"]["parameters"] += 1
                else: record["homogeneous_method_sha256"] = "e"*64
                (root/"disposition.json").write_text(json.dumps(record))
                published["disposition_sha256"] = digest(root/"disposition.json")
            elif change == "audit": (root/"audit.json").write_text("{}")
            elif change == "source": (root/"scripts/verifier.py").write_text("changed")
            elif change == "input": (root/"witness.txt").write_text("changed")
            elif change == "future_directory": (root/"outcome_run").mkdir()
            else: published["disposition_sha256"] = "0"*64
            args = record_kwargs(kwargs,published); args["reader"] = EvidenceReader(root)
            counts["publication_or_record_refusals"] += refuses(lambda:gate.authenticate_record(**args))
    project = Path(__file__).resolve().parents[1]
    report = {"utc":utc(),**counts,"neural_certificates_issued":0,
        "scope":"scalar count, tail-accounting and publication fixtures; no additional neural evidence",
        "sources":{name:digest(project/"scripts"/name) for name in
            ("known_anchor_disposition.py","test_known_anchor_disposition.py","known_anchor_window_assembly.py")}}
    path = Path("results")/("known_anchor_disposition_regression_"+report["utc"].replace(":","").replace("-","")+".json")
    sha = publish_json(project/path,report)
    print(json.dumps(report | {"output":str(path),"sha256":sha},indent=2))


if __name__ == "__main__":
    main()
