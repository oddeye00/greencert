"""Typed orchestration, real Green-family bridge, and rejection fixtures.

Large n values below test metadata contracts, not large neural computations.
The complete-family bridge uses actual file-backed quadratic Green evidence;
its neural derivative and margin premises are explicitly synthetic.
"""
from contextlib import ExitStack
import copy
from dataclasses import replace
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

import runtime_anchor_window_assembly as join
from dgx_green_transition_pilot import ROOT, sha, save
from green_family_evidence import canonical_sha
from reference_margin_evidence import ReferenceMarginRow, anchor_output
from test_file_backed_window_assembly import setup
from test_known_anchor_window_assembly import record_fixture
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError
from window_event_assembly import PointMargin, assemble


def invoke(root, request, evidence, record, *, missing=(), corrupt=(), progress=None,
           executions=None, plan=None, real_green=False):
    calls = []
    executions = {"fixture": {"identity": "test-only"}} if executions is None else executions
    plan = ({"synthetic": True},) if plan is None else plan
    def get(name):
        calls.append(name)
        if name in missing:
            raise EvidencePending("missing typed fixture: " + name)
        if name in corrupt:
            raise IntegrityError("corrupt typed fixture: " + name)
        return record if name == "known_anchor_response" else evidence[name]
    with ExitStack() as stack:
        stack.enter_context(patch.object(join, "authenticate_reference_window", side_effect=lambda *a, **k: get("reference_margins")))
        stack.enter_context(patch.object(join, "authenticate_bound_row", side_effect=lambda *a, **k: get(f"derivative_row_{k['step']:03d}")))
        if not real_green:
            stack.enter_context(patch.object(join, "authenticate_runtime_green_family", side_effect=lambda *a, **k: get("green")))
        result = join.assemble_runtime_anchor_evidence(EvidenceReader(root), request,
            executions=executions, sequence_plan=plan, fresh_response_audit=lambda: get("known_anchor_response"),
            method_sha256="a"*64, required_audit_sources=frozenset({"fixture_auditor.py"}),
            additional_forbidden_paths=("outcome_run",), progress=progress)
    return result, calls


def main():
    report = {"status": "PASS", "typed_complete_joins": 0, "pending_dependencies": 0,
              "integrity_refusals": 0, "real_file_backed_green_bridges": 0,
              "event_certificates_issued": 0, "trained_networks": 0}
    with tempfile.TemporaryDirectory(prefix="greencert-runtime-anchor-tests-") as temporary:
        top = Path(temporary)
        for n in (1, 7, 451008):
            for H in (1, 2, 6, 12):
                root = top / f"typed{n}_{H}"
                root.mkdir()
                request, args, evidence = setup(n, H)
                record = record_fixture(root, request, args["response"])
                result, calls = invoke(root, request, evidence, record)
                response = replace(args["response"], first_injection_error_upper=.001)
                assert result["assembly"] == assemble(**{**args, "response": response})
                assert len(calls) == H+3 and result["missing"] == []
                assert not result["event_certificate_issued"] and not result["outcome_join_authorized"]
                assert not result["original_records_relabelled"]
                report["typed_complete_joins"] += 1
        request, args, evidence = setup()
        names = ["known_anchor_response", "reference_margins", "green"] + [
            f"derivative_row_{j:03d}" for j in range(1, request.identity.horizon+1)]
        for i, name in enumerate(names):
            root = top / f"pending{i}"
            root.mkdir()
            record = record_fixture(root, request, args["response"])
            value, _ = invoke(root, request, evidence, record, missing=(name,))
            assert value["status"] == "pending" and value["assembly"] is None
            report["pending_dependencies"] += 1
            try:
                invoke(root, request, evidence, record, corrupt=(name,))
            except IntegrityError:
                report["integrity_refusals"] += 1
            else:
                raise AssertionError("integrity failure downgraded")
        changes = ("response_method", "response_identity", "partial_response", "cached_list_profile",
            "nonzero_anchor", "missing_tail", "negative_tail", "nan_tau", "fake_issued", "no_physical_replay",
            "changed_witness", "changed_source", "future", "future_directory", "future_during",
            "request_during", "registry_during", "plan_during", "artifact_during", "wrong_green",
            "wrong_probability", "partial_green", "missing_drift", "terminal_drift", "partial_row_plan", "point_only_output")
        for i, change in enumerate(changes):
            root = top / f"reject{i}"
            root.mkdir()
            req, ev = copy.deepcopy(request), copy.deepcopy(evidence)
            record = record_fixture(root, req, args["response"])
            registry, plan, progress = {"fixture": {"identity": "test-only"}}, ({"synthetic": True},), None
            if change == "response_method": record["method_sha256"] = "e"*64
            elif change == "response_identity": record["profile"]["identity"]["parameters"] += 1
            elif change == "partial_response": record["profile"]["parameter_norms"] = record["profile"]["parameter_norms"][:-1]
            elif change == "cached_list_profile": record["profile"]["parameter_norms"] = list(record["profile"]["parameter_norms"])
            elif change == "nonzero_anchor": record["profile"]["parameter_norms"] = (1.,) + record["profile"]["parameter_norms"][1:]
            elif change == "missing_tail": record["profile"]["encoding_injection_tail_upper"] = None
            elif change == "negative_tail": record["profile"]["encoding_injection_tail_upper"] = -1.
            elif change == "nan_tau": record["profile"]["residual_upper"] = float("nan")
            elif change == "fake_issued": record["event_certificate_issued"] = True
            elif change == "no_physical_replay": record["physical_encoding_replayed"] = False
            elif change == "changed_witness": (root / "witness.txt").write_text("changed fixture")
            elif change == "changed_source": (root / "scripts/fixture_auditor.py").write_text("changed fixture")
            elif change == "future": (root / "future.json").write_text("{}")
            elif change == "future_directory": (root / "outcome_run").mkdir()
            elif change.endswith("_during"):
                def progress(name, status, _change=change):
                    if name == "runtime_green" and status == "authenticated":
                        if _change == "future_during": (root / "outcome_run").mkdir()
                        elif _change == "request_during": req.normalization_eps.append([1e-5, 1e-5])
                        elif _change == "registry_during": registry["fixture"]["identity"] = "changed"
                        elif _change == "plan_during": plan[0]["synthetic"] = False
                        else: (root / "witness.txt").write_text("changed during fixture")
            elif change == "wrong_green": ev["green"]["bound"] = replace(args["green"], identity=replace(req.identity, parameters=2))
            elif change == "wrong_probability": ev["green"]["bound"] = replace(args["green"], failure_probability=2e-7)
            elif change == "partial_green": ev["green"]["bound"] = replace(args["green"], complete_probes=1)
            elif change == "missing_drift": ev["derivative_row_001"]["drift"] = None
            elif change == "terminal_drift": ev["derivative_row_006"]["drift"] = args["drift_rows"][0]
            elif change == "partial_row_plan": req = replace(req, row_plan=req.row_plan[:-1])
            elif change == "point_only_output": ev["derivative_row_001"]["output"] = ev["reference_margins"]["anchor"]
            try:
                invoke(root, req, ev, record, executions=registry, plan=plan, progress=progress)
            except IntegrityError:
                report["integrity_refusals"] += 1
            else:
                raise AssertionError("invalid runtime-anchor join accepted: " + change)
        # Exercise the actual complete-family verifier inside the new join,
        # rather than returning a supplied GreenBound at this bridge.
        from test_runtime_green_evidence import fixture as green_fixture
        for H in (1, 3):
            root = top / f"real_green{H}"
            ga, checked = green_fixture(root, H, 2, 2, 1)
            req, direct, _ = setup(2, H)
            train = [{"index": 0, "pair": [0, 1], "label": 1}]
            identity = replace(ga["identity"], evaluation_set_sha256=canonical_sha(req.evaluation_examples))
            req = replace(req, identity=identity, training_examples=train, green_method_sha256=ga["origin_method_sha256"],
                          original_probe_hashes=ga["original_probe_hashes"], failure_probability=.01)
            direct["identity"] = identity
            direct["training_count"] = 1
            direct["response"] = replace(direct["response"], identity=identity, first_injection_error_upper=.001)
            direct["green"] = replace(checked["bound"], identity=identity)
            direct["drift_rows"] = [replace(row, identity=identity, verified_training_count=1) for row in direct["drift_rows"]]
            direct["output_rows"] = [replace(row, identity=identity) for row in direct["output_rows"]]
            ref = tuple(ReferenceMarginRow(identity, row.step,
                tuple(PointMargin(m.example_id, m.lower, m.upper) for m in row.margins), "outward") for row in direct["output_rows"])
            ev = {"reference_margins": {"rows": ref, "anchor": anchor_output(ref[0]), "provenance": {}}}
            for j in range(1, H+1):
                ev[f"derivative_row_{j:03d}"] = {"output": direct["output_rows"][j],
                    "drift": direct["drift_rows"][j-1] if j < H else None, "provenance": {}}
            record = record_fixture(root, req, direct["response"])
            result, _ = invoke(root, req, ev, record, executions=ga["executions"], plan=ga["sequence_plan"], real_green=True)
            assert result["assembly"] == assemble(**direct)
            assert result["provenance"]["runtime_green"]["complete_probes"] == 2
            report["real_file_backed_green_bridges"] += 1
    report["sources"] = {"scripts/"+name: sha(ROOT/"scripts"/name) for name in
        ("runtime_anchor_window_assembly.py", "test_runtime_anchor_window_assembly.py", "runtime_green_evidence.py",
         "known_anchor_window_assembly.py", "window_event_assembly.py", "test_runtime_green_evidence.py")}
    if len(sys.argv) > 1:
        save(ROOT / Path(sys.argv[1]), report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
