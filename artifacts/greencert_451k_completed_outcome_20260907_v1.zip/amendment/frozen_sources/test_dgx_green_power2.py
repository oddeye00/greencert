"""Bounded second-power orchestration and no-retry regressions."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile

import numpy as np
from flint import arb
import dgx_green_power2 as worker
from checkpointed_green_products import StoredRows, store_rows
from outward_green_products import forward, adjoint


def regression():
    report = {"status": "PASS", "exact_phase_comparisons": 0, "scope_refusals": 0,
              "retry_refusals": 0, "retained_interruption": False, "candidate_queries": 0}
    def refuse(call, key):
        try:
            call()
        except (ValueError, KeyError, TypeError):
            report[key] += 1
        else:
            raise AssertionError("invalid q2 operation accepted")
    plan = {"origin_method_sha256": worker.old.METHOD_SHA, "power": 2, "probes": [0,1,2,3],
            "phases": ["forward", "adjoint"], "threads_per_process": 1, "maximum_parallel_probes": 4,
            "minimum_free_mib": 4096, "q1_audit_sha256": worker.AUDIT_SHA,
            "regenerate_probes": False, "automatic_retry": False, "automatic_import": False,
            "event_certificate": False, "future_outcome_access": False, "inputs": []}
    for probe in range(4):
        folder = (worker.GREEN if probe < 3 else worker.CON/"outward_green_dgx")/f"probe_{probe}/power_01/adjoint"
        plan["inputs"].append({"probe": probe, "folder": folder.as_posix(), "summary_sha256": "a"*64})
    worker.validate_plan(plan)
    for key, value in {"origin_method_sha256": "b"*64, "power": 1, "probes": [3],
                       "phases": ["adjoint", "forward"], "threads_per_process": 2, "maximum_parallel_probes": 5,
                       "minimum_free_mib": 1, "q1_audit_sha256": "c"*64, "regenerate_probes": True,
                       "automatic_retry": True, "automatic_import": True, "event_certificate": True,
                       "future_outcome_access": True}.items():
        bad = deepcopy(plan)
        bad[key] = value
        refuse(lambda: worker.validate_plan(bad), "scope_refusals")
    for key, value in (("folder", "new_gaussian"), ("summary_sha256", "bad"), ("probe", 2)):
        bad = deepcopy(plan)
        bad["inputs"][0][key] = value
        refuse(lambda: worker.validate_plan(bad), "scope_refusals")
    rng = np.random.default_rng(75211)
    with tempfile.TemporaryDirectory(prefix="greencert-q2-test-") as temporary:
        root = Path(temporary)
        for probe, (H,n) in enumerate(((1,2),(2,3),(4,2),(7,4))):
            matrices = rng.normal(size=(H,n,n))
            matrices = (matrices+matrices.transpose(0,2,1))/8
            def hvp(j, direction):
                return [sum((arb(float(a))*b for a,b in zip(row,direction)), arb(0)) for row in matrices[j]]
            initial = rng.normal(size=(H,2*n))
            kwargs = {"learning_rate": .003, "momentum": .9, "precision_bits": 128}
            # Produce an independent reference for q1, then store its dyadic
            # adjoint output as the injected data for q2.
            q1 = adjoint(forward(initial,hvp,**kwargs)["states"],hvp,**kwargs)["states"]
            source = store_rows(root/f"source{probe}", iter(q1), shape=q1.shape, contract={"synthetic_q1": probe})
            target = root/f"q2_{probe}"
            calls = []
            worker.run_pair(target,source,hvp,eta=.003,mu=.9,method_sha="d"*64,probe=probe,
                            progress=lambda phase,row: calls.append((phase,row["index"])))
            current = q1
            for phase, operation in (("forward",forward),("adjoint",adjoint)):
                expected = operation(current,hvp,**kwargs)
                actual = StoredRows(target/phase)
                rows = np.stack([actual.row(j) for j in range(H)])
                assert np.array_equal(rows,expected["states"])
                assert [v["local_residual_norm_upper"] for v in actual.summary["rows"]] == expected["local_residuals"]
                assert actual.method["contract"] == {"method_sha256": "d"*64, "probe": probe, "power": 2}
                assert actual.method["input_manifest_sha256"] == source.identity
                source, current = actual, rows
                report["exact_phase_comparisons"] += 1
            assert len(calls) == 2*H
            refuse(lambda: worker.run_pair(target,source,hvp,eta=.003,mu=.9,method_sha="d"*64,probe=probe),
                   "retry_refusals")
        interrupted = root/"interrupted"
        def stop():
            raise RuntimeError("synthetic interruption")
        try:
            worker.run_pair(interrupted,source,hvp,eta=.003,mu=.9,method_sha="d"*64,probe=0,guard=stop)
        except RuntimeError:
            assert interrupted.exists() and not (interrupted/"forward/summary.json").exists()
            report["retained_interruption"] = True
        else:
            raise AssertionError("interruption not retained")
        refuse(lambda: worker.run_pair(interrupted,source,hvp,eta=.003,mu=.9,method_sha="d"*64,probe=0),
               "retry_refusals")
    report["sources"] = {"scripts/"+name: worker.sha(worker.ROOT/"scripts"/name) for name in
                         (*worker.EXTRA, Path(__file__).name, "checkpointed_green_products.py", "outward_green_products.py")}
    return report


if __name__ == "__main__":
    result = regression()
    path = worker.ROOT/"results/dgx_green_power2_contract_20260907.json"
    worker.save(path,result)
    print(json.dumps(result | {"report_sha256": worker.sha(path)}, indent=2))
