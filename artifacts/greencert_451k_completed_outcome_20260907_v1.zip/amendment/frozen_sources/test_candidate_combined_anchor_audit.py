"""Complete audit orchestration tests with real anchor arithmetic fixtures.

The existing source/gradient records are synthetic evidence-adapter fixtures.
Only candidate preparation and the memory query are injected here; physical
anchor replay, original-response verification, homogeneous verification and
the file-backed combination run normally. This is not a neural experiment.
"""
import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
from contextlib import ExitStack, redirect_stdout
from dataclasses import asdict
import hashlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
from flint import arb, ctx

import audit_candidate_combined_anchor_response as audit
from anchor_response_evidence import authenticate_anchor
from checkpointed_green_products import digest, json_bytes, save_json
from known_anchor_green_response import construct
from known_anchor_response import encode_velocity_offset
from registered_outcome_continuation import publish_json, utc
from test_anchor_response_evidence import fixture
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError


def setup(root, *, n=4,H=3,eta=.1,mu=.9):
    args = fixture(root,H=H,n=n,eta=eta,mu=mu)
    anchor = authenticate_anchor(**args)
    with np.load(root/"anchor.npz",allow_pickle=False) as cp:
        velocity = cp["velocity"].copy()
    center = np.load(root/"corrected.npy",allow_pickle=False)[0]
    encoding = encode_velocity_offset(velocity,center[n:],learning_rate=eta,momentum=mu)
    encoded = encoding["encoded_velocity_offset"]
    method = {"encoding_record":"synthetic_encoding.json","encoding_sha256":"b"*64,
              "initial_encoding_injection_tail_upper":encoding["unrepresented_first_injection_norm_upper"],
              "original_first_injection_bound_still_in_force":anchor.first_injection_error_upper}
    mh = hashlib.sha256(json_bytes(method)).hexdigest()
    con = Path("construction")
    folder = root/con/"known_anchor_homogeneous"
    save_json(folder/"method.json",method)
    result = construct(folder/"product",encoded,lambda j,d:[arb(i+j+1)*v for i,v in enumerate(d)],
        horizon=H,learning_rate=eta,momentum=mu,operator_sha256=mh,encoding_sha256="b"*64)
    save_json(folder/"construction_summary.json",{"method_sha256":mh,**result})
    for name in audit.NAMES:
        p = root/"scripts"/name
        if not p.exists():
            p.write_text("# synthetic auditor-source identity fixture\n")
    request = SimpleNamespace(identity=args["identity"],learning_rate=eta,momentum=mu,
        anchor_paths={k:v for k,v in args.items() if k not in ("reader","identity")},
        response_folder="response",gradient_folder="gradient",training_examples=[0,1])
    candidate = json.loads((root/"candidate.json").read_text())
    guard_calls = []
    def prepare(record,sha):
        assert record == method["encoding_record"] and sha == method["encoding_sha256"]
        reader = EvidenceReader(root)
        def guard():
            guard_calls.append(1)
            for path, expected in tuple(reader.observed.items()):
                reader.check_blob(path,expected)
        return reader,request,{"candidate":candidate},encoded,method,guard
    return method,mh,encoded,prepare,con,guard_calls


def invoke(root, prepared, *, memory=4096):
    method,mh,encoded,prepare,con,guards = prepared
    with ExitStack() as stack:
        for name,value in (("ROOT",root),("SOURCE",Path("future_source")),("CON",con)):
            stack.enter_context(patch.object(audit,name,value))
        stack.enter_context(patch.object(audit,"prepare",side_effect=prepare))
        stack.enter_context(patch.object(audit,"memory_available_mib",return_value=memory))
        with redirect_stdout(io.StringIO()):
            return audit.audit(SimpleNamespace(method_sha256=mh))


def main():
    old = ctx.prec; ctx.prec = 256
    completed = rejected = missing = 0
    with tempfile.TemporaryDirectory(prefix="greencert_combined_driver_") as temp:
        top = Path(temp)
        try:
            cases = ((1,1,.1,.9),(4,3,.1,.9),(7,5,.125,.9),(4,3,.1,0.),
                     (2,3,float(np.nextafter(np.float64(0),np.float64(1))),.9))
            tail_cases = []
            for i,(n,H,eta,mu) in enumerate(cases):
                root = top/f"case_{i}"
                prepared = setup(root,n=n,H=H,eta=eta,mu=mu)
                result = invoke(root,prepared)
                assert result["status"] == "combined_response_audited_not_event_certified"
                assert result["physical_encoding_replayed"] and not result["neural_hvps_replayed"]
                assert not result["event_certificate_issued"] and not result["future_outcome_access"]
                assert len(result["profile"]["parameter_norms"]) == H+1
                assert result["profile"]["encoding_injection_tail_upper"] == prepared[0]["initial_encoding_injection_tail_upper"]
                assert prepared[-1]
                tail_cases.append(result["profile"]["encoding_injection_tail_upper"])
                completed += 1
            assert tail_cases[-1] > 0 and all(v == 0 for v in tail_cases[:-1])
            # Resource and future barriers remain active on a complete tree.
            for i,forbidden in enumerate((None,"reveal.json","registered_outcome_run")):
                root = top/f"barrier_{i}"
                prepared = setup(root)
                if forbidden is not None:
                    p = root/"future_source"/forbidden
                    p.parent.mkdir(exist_ok=True)
                    if forbidden.endswith(".json"):
                        p.write_text("{}")
                    else:
                        p.mkdir()
                try:
                    invoke(root,prepared,memory=0 if forbidden is None else 4096)
                except IntegrityError as error:
                    assert ("1536MiB" if forbidden is None else "barrier") in str(error)
                    rejected += 1
                else:
                    raise AssertionError("complete-tree resource/future barrier bypassed")
            # An absent full construction record is pending, even if row
            # files and the method remain. This is not an issuance abstention.
            root = top/"missing"
            prepared = setup(root)
            (root/prepared[4]/"known_anchor_homogeneous/construction_summary.json").unlink()
            try:
                invoke(root,prepared,memory=0)
            except EvidencePending:
                missing += 1
            else:
                raise AssertionError("partial product returned a complete profile")
            # Physical replay must reject a coherently relabeled zero tail.
            root = top/"understated_tail"
            prepared = setup(root,n=2,H=3,eta=float(np.nextafter(np.float64(0),np.float64(1))))
            method,mh,encoded,prepare,con,guards = prepared
            assert method["initial_encoding_injection_tail_upper"] > 0
            method["initial_encoding_injection_tail_upper"] = 0.
            new_mh = hashlib.sha256(json_bytes(method)).hexdigest()
            folder = root/con/"known_anchor_homogeneous"
            (folder/"method.json").write_bytes(json_bytes(method))
            construction = json.loads((folder/"construction_summary.json").read_text())
            construction["method_sha256"] = new_mh
            (folder/"construction_summary.json").write_bytes(json_bytes(construction))
            try:
                invoke(root,(method,new_mh,encoded,prepare,con,guards))
            except IntegrityError as error:
                assert "encoding tail" in str(error)
                rejected += 1
            else:
                raise AssertionError("unrepresented physical tail silently set to zero")
            # The original anchor forcing cannot be relabeled away, even if
            # all affected wrapper records are coherently rehashed.
            root = top/"understated_original_anchor"
            prepared = setup(root)
            method,mh,encoded,prepare,con,guards = prepared
            assert method["original_first_injection_bound_still_in_force"] > 0
            method["original_first_injection_bound_still_in_force"] = 0.
            new_mh = hashlib.sha256(json_bytes(method)).hexdigest()
            folder = root/con/"known_anchor_homogeneous"
            (folder/"method.json").write_bytes(json_bytes(method))
            construction = json.loads((folder/"construction_summary.json").read_text())
            construction["method_sha256"] = new_mh
            (folder/"construction_summary.json").write_bytes(json_bytes(construction))
            try:
                invoke(root,(method,new_mh,encoded,prepare,con,guards))
            except IntegrityError as error:
                assert "original anchor bound" in str(error)
                rejected += 1
            else:
                raise AssertionError("original anchor forcing relabeled to zero")
            root = top/"opposite_encoding"
            prepared = setup(root)
            assert np.any(prepared[2])
            prepared[2][...] *= -1
            try:
                invoke(root,prepared)
            except IntegrityError as error:
                assert "physical anchor encoding differs" in str(error)
                rejected += 1
            else:
                raise AssertionError("opposite physical encoding accepted")
        finally:
            ctx.prec = old
    project = Path(__file__).resolve().parents[1]
    names = ("test_candidate_combined_anchor_audit.py","audit_candidate_combined_anchor_response.py",
             "test_anchor_response_evidence.py","anchor_response_evidence.py",
             "combined_anchor_response.py","homogeneous_response_evidence.py")
    report = {"utc":utc(),"complete_driver_paths":completed,"resource_future_and_tail_refusals":rejected,
        "partial_product_pending":missing,"underflow_encoding_tail_preserved":True,
        "sources":{n:digest(project/"scripts"/n) for n in names},"event_certificates_issued":0,
        "scope":"audit orchestration and physical anchor arithmetic; synthetic derivative-source fixtures, no neural truth claim"}
    path = Path("results")/("candidate_combined_audit_regression_"+report["utc"].replace(":","").replace("-","")+".json")
    sha = publish_json(project/path,report)
    print(json.dumps(report | {"output":str(path),"sha256":sha},indent=2))


if __name__ == "__main__":
    main()
