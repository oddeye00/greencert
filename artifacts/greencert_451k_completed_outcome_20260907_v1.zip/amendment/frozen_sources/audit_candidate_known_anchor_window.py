"""Frozen, separate known-anchor assembly; no issuance or outcome permission.

Check mode inventories completion markers without doing numerical replay.
Audit mode invokes the full response audit in-process and the unchanged
Green, neural derivative and output adapters. A saved profile is not an input.
"""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
from types import SimpleNamespace

import audit_candidate_combined_anchor_response as response_audit
from audit_candidate_window_assembly import ROOT, SOURCE, CON, load_request
from build_candidate_known_anchor_response import NAMES as HOMOGENEOUS_SOURCES
from checkpointed_green_products import digest
from known_anchor_window_assembly import SCOPE, assemble_known_anchor_evidence
from registered_outcome_continuation import publish_json, utc
from seal_candidate_window_disposition import NAMES as ORIGINAL_SOURCES, check_markers
from verified_artifact_io import EvidenceReader, EvidencePending, require_sha256
from green_family_evidence import require
from window_disposition import check_policy as check_original_policy, family_fingerprint

NAMES = tuple(dict.fromkeys(ORIGINAL_SOURCES + response_audit.NAMES + HOMOGENEOUS_SOURCES + (
    "known_anchor_window_assembly.py", "test_known_anchor_window_assembly.py",
    "audit_candidate_known_anchor_window.py", "test_candidate_known_anchor_window_policy.py")))
POLICY = CON/"known_anchor_window_policy.json"
PROTOCOL = Path("KNOWN_ANCHOR_WINDOW_PROTOCOL.md")
ORIGINAL_POLICY = CON/"outward_window_disposition_policy.json"
ORIGINAL_POLICY_SHA = "e798b53fa26c4db0788aa580de7af6ea873fd4ed59da5ee884084c9cf807b96e"


def barrier(reader, request):
    require(all(not reader.resolve(path).exists() for path in (*request.forbidden_outcome_files,
        SOURCE/"reveal.json", SOURCE/"registered_outcome_run")), "future barrier open")


def check_policy(reader, request, *, policy_sha256, method_sha256):
    require_sha256(policy_sha256); require_sha256(method_sha256)
    barrier(reader, request)
    policy, sha = reader.read_json(POLICY,policy_sha256)
    require(policy["schema"] == "known_anchor_window_policy_v1" and
        policy["window_family_sha256"] == family_fingerprint(request) and
        policy["homogeneous_method_sha256"] == method_sha256 and
        policy["original_policy_sha256"] == ORIGINAL_POLICY_SHA and policy["scope"] == SCOPE and
        policy["original_issuance_policy_changed"] is False and policy["event_issuance_authorized"] is False and
        policy["outcome_join_authorized"] is False and policy["future_outcome_access"] is False,
        "known-anchor assembly policy scope or identity differs")
    reader.check_sources(policy,required_names=frozenset(NAMES))
    reader.check_blob(PROTOCOL,policy["protocol_sha256"])
    original,_ = check_original_policy(reader,request,policy_path=ORIGINAL_POLICY,
        policy_sha256=ORIGINAL_POLICY_SHA,required_source_names=frozenset(ORIGINAL_SOURCES))
    require(policy["allowed_powers"] == original["allowed_powers"] and type(request.power) is int and
        request.power in policy["allowed_powers"] and
        policy["failure_probability"] == request.failure_probability,
        "known-anchor assembly changes original probability or power budget")
    method,_ = reader.read_json(CON/"known_anchor_homogeneous/method.json",method_sha256)
    require(method["identity"] == asdict(request.identity) and
        method["original_green_method_sha256"] == request.green_method_sha256 and
        method["future_outcome_access"] is False and method["event_certificate_issued"] is False,
        "known-anchor construction belongs to another window/operator")
    reader.check_sources(method,required_names=frozenset(HOMOGENEOUS_SOURCES))
    return policy,sha


def freeze_policy(reader, request, *, method_sha256):
    require_sha256(method_sha256)
    barrier(reader,request)
    if reader.resolve(POLICY).exists():
        _,sha = reader.read_json(POLICY)
        check_policy(reader,request,policy_sha256=sha,method_sha256=method_sha256)
        return sha,False
    original,_ = check_original_policy(reader,request,policy_path=ORIGINAL_POLICY,
        policy_sha256=ORIGINAL_POLICY_SHA,required_source_names=frozenset(ORIGINAL_SOURCES))
    method,_ = reader.read_json(CON/"known_anchor_homogeneous/method.json",method_sha256)
    require(method["identity"] == asdict(request.identity) and
            method["original_green_method_sha256"] == request.green_method_sha256 and
            method["future_outcome_access"] is False and method["event_certificate_issued"] is False,
            "foreign homogeneous method at freeze")
    require(type(request.power) is int and request.power in original["allowed_powers"],
            "undeclared ordinary power at freeze")
    sources = {name:digest(ROOT/"scripts"/name) for name in NAMES}
    policy = {"schema":"known_anchor_window_policy_v1","created_utc":utc(),
        "window_family_sha256":family_fingerprint(request),"homogeneous_method_sha256":method_sha256,
        "original_policy_sha256":ORIGINAL_POLICY_SHA,"allowed_powers":original["allowed_powers"],
        "failure_probability":request.failure_probability,"scope":SCOPE,"sources":sources,
        "protocol_sha256":digest(ROOT/PROTOCOL),"original_issuance_policy_changed":False,
        "event_issuance_authorized":False,"outcome_join_authorized":False,"future_outcome_access":False,
        "development_scope":"outcome-sealed development after partial response/Green/derivative inspection; not fresh confirmation",
        "rule":"fresh physical-response audit plus original full-window bounds; audit only, separate disposition required"}
    reader.check_sources(policy,required_names=frozenset(NAMES))
    reader.check_sources(method,required_names=frozenset(HOMOGENEOUS_SOURCES))
    barrier(reader,request)
    sha = publish_json(reader.resolve(POLICY),policy)
    check_policy(reader,request,policy_sha256=sha,method_sha256=method_sha256)
    return sha,True


def run(args):
    reader = EvidenceReader(ROOT)
    request,context = load_request(reader,source=SOURCE,construction=CON,power=args.power)
    if args.mode == "freeze-policy":
        sha,created = freeze_policy(reader,request,method_sha256=args.method_sha256)
        return {"status":"assembly_policy_frozen","policy_sha256":sha,"created":created,
            "event_certificate_issued":False,"outcome_join_authorized":False,"future_outcome_access":False}
    policy,psha = check_policy(reader,request,policy_sha256=args.policy_sha256,method_sha256=args.method_sha256)
    missing = check_markers(reader,request)
    try:
        reader.read_json(CON/"known_anchor_homogeneous/construction_summary.json",allow_in_progress=True)
    except EvidencePending as error:
        missing.append({"path":str(CON/"known_anchor_homogeneous/construction_summary.json"),"reason":str(error)})
    barrier(reader,request)
    if missing or args.mode == "check":
        return {"status":"pending_markers" if missing else "completion_markers_present",
            "policy_sha256":psha,"missing":missing,"missing_count":len(missing),
            "numerical_verification_performed":False,"event_certificate_issued":False,
            "outcome_join_authorized":False,"future_outcome_access":False,
            "scope":"completion-marker inventory only; marker presence is not a bound or a certificate"}
    # The only production source for the combined profile is a fresh audit.
    result = assemble_known_anchor_evidence(reader,request,
        fresh_response_audit=lambda:response_audit.audit(SimpleNamespace(method_sha256=args.method_sha256)),
        method_sha256=args.method_sha256,required_audit_sources=frozenset(response_audit.NAMES),
        additional_forbidden_paths=(str(SOURCE/"registered_outcome_run"),),
        progress=lambda name,status:print(json.dumps({"component":name,"status":status}),flush=True))
    reader.check_sources(policy,required_names=frozenset(NAMES))
    barrier(reader,request)
    record = {"utc":utc(),"policy_sha256":psha,"request":asdict(request),"context":context,
        "result":result,"observed_artifact_hashes":dict(reader.observed)}
    path = CON/"known_anchor_window_audits"/(record["utc"].replace(":","").replace("-","")+".json")
    sha = publish_json(reader.resolve(path),record)
    return {"status":result["status"],"policy_sha256":psha,"output":str(path),"sha256":sha,
        "numerical_verification_performed":True,"event_certificate_issued":False,
        "outcome_join_authorized":False,"future_outcome_access":False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode",choices=("check","freeze-policy","audit"),default="check")
    parser.add_argument("--method-sha256",required=True)
    parser.add_argument("--policy-sha256")
    parser.add_argument("--power",type=int,default=1)
    print(json.dumps(run(parser.parse_args()),indent=2))
