"""Separate-route orchestration fixtures, not additional neural experiments."""
from contextlib import ExitStack
import copy
from dataclasses import asdict, replace
import json
from pathlib import Path
import tempfile
from unittest.mock import patch

import known_anchor_window_assembly as join
from checkpointed_green_products import digest
from registered_outcome_continuation import publish_json, utc
from test_file_backed_window_assembly import setup
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError
from window_event_assembly import ResponseBound, assemble


def record_fixture(root, request, response, *, tail=.001):
    (root/"scripts").mkdir(exist_ok=True)
    source = root/"scripts"/"fixture_auditor.py"
    source.write_text("# synthetic typed audit premise\n")
    witness = root/"witness.txt"
    witness.write_text("synthetic artifact binding\n")
    return {"status":"combined_response_audited_not_event_certified", "method_sha256":"a"*64,
        "construction_sha256":"b"*64,"physical_encoding_replayed":True,"neural_hvps_replayed":False,
        "original_issuance_policy_changed":False,"event_certificate_issued":False,"future_outcome_access":False,
        "sources":{"fixture_auditor.py":digest(source)}, "observed_artifact_hashes":{"witness.txt":digest(witness)},
        "profile":{"identity":asdict(request.identity),"parameter_norms":response.parameter_norms,
            "residual_upper":response.residual_upper,"encoding_injection_tail_upper":tail,
            "original_first_injection_upper":response.first_injection_error_upper,
            "original_summary_sha256":"c"*64,"homogeneous_summary_sha256":"d"*64}}


def invoke(root, request, evidence, record, *, missing=(), corrupt=(), progress=None):
    calls = []
    def get(name):
        calls.append(name)
        if name in missing:
            raise EvidencePending("missing fixture: "+name)
        if name in corrupt:
            raise IntegrityError("corrupt fixture: "+name)
        return record if name == "known_anchor_response" else evidence[name]
    with ExitStack() as stack:
        for function,name in (("authenticate_reference_window","reference_margins"),
                              ("authenticate_green_family","green")):
            stack.enter_context(patch.object(join,function,side_effect=lambda *a,_name=name,**kw:get(_name)))
        stack.enter_context(patch.object(join,"authenticate_bound_row",side_effect=lambda *a,**kw:
            get(f"derivative_row_{kw['step']:03d}")))
        result = join.assemble_known_anchor_evidence(EvidenceReader(root),request,
            fresh_response_audit=lambda:get("known_anchor_response"),method_sha256="a"*64,
            required_audit_sources=frozenset({"fixture_auditor.py"}),
            additional_forbidden_paths=("outcome_run",),progress=progress)
    return result,calls


def main():
    counts = {"complete_typed_joins":0,"pending_dependencies":0,"integrity_refusals":0,
              "real_physical_audit_bridges":0}
    with tempfile.TemporaryDirectory(prefix="greencert_anchor_window_") as temp:
        top = Path(temp)
        for n in (1,7,451008):
            for H in (1,2,6,12):
                root = top/f"case_{n}_{H}"; root.mkdir()
                request,args,evidence = setup(n,H)
                record = record_fixture(root,request,args["response"])
                result,calls = invoke(root,request,evidence,record)
                response = replace(args["response"],first_injection_error_upper=.001)
                assert result["assembly"] == assemble(**{**args,"response":response})
                assert len(calls) == H+3 and not result["missing"]
                assert result["assembly"]["failure_probability"] == request.failure_probability
                assert not result["event_certificate_issued"] and not result["outcome_join_authorized"]
                assert not result["original_issuance_policy_changed"]
                assert args["response"].first_injection_error_upper == .025
                counts["complete_typed_joins"] += 1
        request,args,evidence = setup()
        component_names = ["known_anchor_response","reference_margins","green"] + [
            f"derivative_row_{j:03d}" for j in range(1,request.identity.horizon+1)]
        for i,name in enumerate(component_names):
            root = top/f"pending_{i}"; root.mkdir()
            record = record_fixture(root,request,args["response"])
            result,_ = invoke(root,request,evidence,record,missing=(name,))
            assert result["status"] == "pending" and result["assembly"] is None
            counts["pending_dependencies"] += 1
            try:
                invoke(root,request,evidence,record,corrupt=(name,))
            except IntegrityError:
                counts["integrity_refusals"] += 1
            else:
                raise AssertionError("integrity failure downgraded to pending")
        changes = ("method","identity","partial","nonzero_anchor","tail_none","tail_negative","tau_nan",
                   "relabel_issued","unreplayed_encoding","changed_artifact","changed_source","future_file",
                   "future_directory","future_during","request_during","artifact_during","wrong_green",
                   "wrong_probability","missing_drift","terminal_drift","row_plan","point_only_output")
        for i,change in enumerate(changes):
            root = top/f"reject_{i}"; root.mkdir()
            record = record_fixture(root,request,args["response"])
            req, ev, progress = copy.deepcopy(request),copy.deepcopy(evidence),None
            if change == "method": record["method_sha256"] = "e"*64
            elif change == "identity": record["profile"]["identity"]["horizon"] += 1
            elif change == "partial": record["profile"]["parameter_norms"] = record["profile"]["parameter_norms"][:-1]
            elif change == "nonzero_anchor": record["profile"]["parameter_norms"] = (1.,)+(0.,)*req.identity.horizon
            elif change == "tail_none": record["profile"]["encoding_injection_tail_upper"] = None
            elif change == "tail_negative": record["profile"]["encoding_injection_tail_upper"] = -1.
            elif change == "tau_nan": record["profile"]["residual_upper"] = float("nan")
            elif change == "relabel_issued": record["event_certificate_issued"] = True
            elif change == "unreplayed_encoding": record["physical_encoding_replayed"] = False
            elif change == "changed_artifact": (root/"witness.txt").write_text("changed")
            elif change == "changed_source": (root/"scripts/fixture_auditor.py").write_text("changed")
            elif change == "future_file": (root/"future.json").write_text("{}")
            elif change == "future_directory": (root/"outcome_run").mkdir()
            elif change in ("future_during","request_during","artifact_during"):
                def progress(name,status,_change=change):
                    if name == "green" and status == "authenticated":
                        if _change == "future_during": (root/"outcome_run").mkdir()
                        elif _change == "request_during": req.normalization_eps.append([1e-5,1e-5])
                        else: (root/"witness.txt").write_text("changed during join")
            elif change == "wrong_green": ev["green"]["bound"] = replace(args["green"],identity=replace(req.identity,horizon=2))
            elif change == "wrong_probability": ev["green"]["bound"] = replace(args["green"],failure_probability=2e-7)
            elif change == "missing_drift": ev["derivative_row_001"]["drift"] = None
            elif change == "terminal_drift": ev["derivative_row_006"]["drift"] = args["drift_rows"][0]
            elif change == "row_plan": req = replace(req,row_plan=req.row_plan[:-1])
            elif change == "point_only_output": ev["derivative_row_001"]["output"] = ev["reference_margins"]["anchor"]
            try:
                invoke(root,req,ev,record,progress=progress)
            except IntegrityError:
                counts["integrity_refusals"] += 1
            else:
                raise AssertionError("accepted incompatible evidence: "+change)
        root = top/"no_gain"; root.mkdir()
        record = record_fixture(root,request,args["response"])
        ev = copy.deepcopy(evidence); ev["green"]["bound"] = None
        result,_ = invoke(root,request,ev,record)
        assert result["status"] == "no_finite_green_bound_at_requested_power" and result["assembly"] is None
        # Test the bridge with the real complete-response audit, including
        # physical replay and file-backed responses. Its derivative-source
        # records remain synthetic; no neural producer proof is inferred.
        import test_candidate_combined_anchor_audit as physical
        import audit_candidate_combined_anchor_response as response_audit
        for i,eta in enumerate((.1,float.fromhex("0x0.0000000000001p-1022"))):
            root = top/f"physical_{i}"
            from flint import ctx
            old = ctx.prec; ctx.prec = 256
            try:
                prepared = physical.setup(root,n=2,H=3,eta=eta)
                audited = physical.invoke(root,prepared)
            finally:
                ctx.prec = old
            req = prepared[3](prepared[0]["encoding_record"],prepared[0]["encoding_sha256"])[1]
            bound = join.response_from_fresh_audit(EvidenceReader(root),req,audited,
                method_sha256=prepared[1],required_audit_sources=frozenset(response_audit.NAMES))["bound"]
            assert isinstance(bound,ResponseBound) and bound.identity == req.identity
            assert bound.first_injection_error_upper == prepared[0]["initial_encoding_injection_tail_upper"]
            if i: assert bound.first_injection_error_upper > 0
            counts["real_physical_audit_bridges"] += 1
    project = Path(__file__).resolve().parents[1]
    report = {"utc":utc(),**counts,"event_certificates_issued":0,
        "scope":"join orchestration and physical-checkpoint fixtures; no additional neural experiment",
        "sources":{name:digest(project/"scripts"/name) for name in
            ("known_anchor_window_assembly.py","test_known_anchor_window_assembly.py",
             "audit_candidate_combined_anchor_response.py","window_event_assembly.py")}}
    path = Path("results")/("known_anchor_window_regression_"+report["utc"].replace(":","").replace("-","")+".json")
    sha = publish_json(project/path,report)
    print(json.dumps(report | {"output":str(path),"sha256":sha},indent=2))


if __name__ == "__main__":
    main()
