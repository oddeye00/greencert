"""Join the actual candidate's evidence; never seal or reveal a future.

Candidate-specific layout is isolated here. The join/theorem has no fixed
dimension, window, seed, gate, architecture depth, or predicted event offset.
"""
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

from candidate_evidence_context import load_context
from file_backed_window_assembly import BoundRowLocation, WindowEvidenceRequest, assemble_window_evidence
from green_family_evidence import require
from verified_artifact_io import EvidenceReader

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path("results/larger_transformer_third_pass")
CON = SOURCE / "construction_03925"
NAMES = ("audit_candidate_window_assembly.py", "file_backed_window_assembly.py",
    "test_file_backed_window_assembly.py", "candidate_evidence_context.py", "verified_artifact_io.py",
    "anchor_response_evidence.py", "bound_row_evidence.py", "green_family_evidence.py",
    "reference_margin_evidence.py", "window_event_assembly.py", "response_centered_scalar_closure.py",
    "outward_green_products.py", "green_local_residual_bounds.py",
    "outward_inexact_anytime_gram.py", "inexact_anytime_gram.py")


def load_request(reader, *, source, construction, power):
    context = load_context(reader, source=source, construction=construction)
    candidate, reference, gm = (context[name] for name in ("candidate", "reference", "green_method"))
    start, start_sha = reader.read_json(construction / "start.json", reference["start_sha256"])
    method, method_sha = reader.read_json(source / "method.json", start["method_sha256"])
    reader.check_sources(method, required_names=frozenset({"run_larger_transformer_third_pass.py",
        "select_larger_transformer_second_pass.py", "larger_transformer_development.py",
        "streaming_variational_centerline.py", "transformer_hvp_grokking.py", "transformer_modal_forecast.py"}))
    reader.check_blob("LARGER_TRANSFORMER_THIRD_PASS_PROTOCOL.md", method["protocol_sha256"])
    require(start["candidate_sha256"] == context["identity"].candidate_sha256 and
            method["config"] == candidate["config"] and method["parameter_count"] == gm["parameters"] and
            method["horizon"] == gm["horizon"] and candidate["threshold"] in method["gates"],
            "fixed event/candidate selection identity mismatch")
    prior, prior_sha = reader.read_json(construction / "green/method.json", gm["prior_probe_method_sha256"])
    reader.check_sources(prior, required_names=frozenset({"probe_larger_candidate_green.py",
        "build_larger_candidate_reference.py", "batched_green_operator.py", "probe_jacobian_bound.py",
        "shifted_gram_reuse.py", "transformer_hvp_grokking.py"}))
    reader.check_blob("LARGER_CANDIDATE_3925_BOUND_PROTOCOL.md", prior["protocol_sha256"])
    require(prior["reference_sha256"] == context["provenance"]["reference_record_sha256"] and
            prior["path_sha256"] == gm["path_sha256"] and prior["horizon"] == gm["horizon"] and
            prior["state_dimension"] == gm["state_dimension"] and prior["master_nonce"] == gm["master_nonce"] and
            prior["probe_seeds"] == gm["probe_seeds"], "original Gaussian family belongs to another operator")
    original = []
    for probe in range(prior["probes"]):
        row, _ = reader.read_json(construction / f"green/probe_{probe}/power_01.json")
        require(row["method_sha256"] == prior_sha and row["probe"] == probe and row["power"] == 1,
                "foreign original-probe record")
        original.append(row["previous_sha256"])
    evaluation = context["populations"]["certification"]
    # Reproduce the frozen selector's ceil(float threshold * population size).
    # No new target, persistence, or shorter event window is selected here.
    target = math.ceil(candidate["threshold"] * len(evaluation))
    locations = tuple(BoundRowLocation(j, str(construction / (
        f"outward_bound_rows/step_{j:03d}" if j == 1 else f"outward_moment_bound_rows/step_{j:03d}")),
        "original" if j == 1 else "moment_points_native_local") for j in range(1, gm["horizon"]+1))
    request = WindowEvidenceRequest(identity=context["identity"], anchor_paths=context["anchor_paths"],
        response_folder=str(construction / "verified_signed_response"),
        gradient_folder=str(construction / "reverse_arithmetic_000"),
        reference_margin_folder=str(construction / "outward_forward_window"),
        green_folder=str(construction / "outward_green"),
        green_method_sha256=context["provenance"]["green_method_sha256"],
        original_probe_hashes=tuple(original), power=power, failure_probability=prior["delta"],
        learning_rate=candidate["config"]["learning_rate"], momentum=candidate["config"]["momentum"],
        training_examples=context["populations"]["training"], evaluation_examples=evaluation,
        example_ids=tuple(f"certification_{j:03d}" for j in range(len(evaluation))),
        classes=candidate["config"]["modulus"], normalization_eps=gm["normalization_eps"],
        row_plan=locations, domain=context["baseline_method"]["radius"], target=target,
        persistence=method["persistence"], forbidden_outcome_files=(str(source / "reveal.json"),))
    return request, {**context["provenance"], "selection_method_sha256": method_sha,
                     "reference_start_sha256": start_sha, "original_probe_method_sha256": prior_sha}


def main(power):
    reader = EvidenceReader(ROOT)
    sources = {name: hashlib.sha256((ROOT / "scripts" / name).read_bytes()).hexdigest() for name in NAMES}
    for name, sha in sources.items():
        reader.check_blob(Path("scripts") / name, sha)
    request, context = load_request(reader, source=SOURCE, construction=CON, power=power)
    result = assemble_window_evidence(reader, request, progress=lambda name, status:
        print(json.dumps({"component": name, "status": status}), flush=True))
    for name, sha in sources.items():
        reader.check_blob(Path("scripts") / name, sha)
    require(not reader.resolve(SOURCE / "reveal.json").exists(), "future barrier changed before report")
    now = datetime.now(timezone.utc)
    record = {"utc": now.isoformat(), "request": asdict(request), "context_provenance": context,
              "result": result, "auditor_sources": sources, "observed_artifact_hashes": reader.observed}
    folder = ROOT / CON / "window_assembly_audits"
    folder.mkdir(exist_ok=True)
    output = folder / (now.strftime("%Y%m%dT%H%M%S%fZ") + ".json")
    with output.open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2, default=str); stream.write("\n")
    print(json.dumps({"status": result["status"], "parameters": request.identity.parameters,
        "horizon": request.identity.horizon, "target": request.target, "persistence": request.persistence,
        "authenticated_derivative_steps": result["authenticated_derivative_steps"],
        "pending_components": len(result["missing"]), "artifacts_checked": len(reader.observed),
        "event_certificate_issued": False, "construction_disposition_sealed": False,
        "output": str(output)}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--power", type=int, required=True)
    main(parser.parse_args().power)
