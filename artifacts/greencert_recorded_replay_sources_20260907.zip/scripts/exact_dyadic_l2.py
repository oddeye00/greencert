"""Exact squared L2 sums of finite native-binary64 arrays using integer limbs.

No floating-point product/reduction or BLAS is used. Each finite magnitude
is m*2**(E-1075), with E=1 for subnormals. Three base-2**18 limbs recover
m**2 exactly. At most 2**20 terms enter a uint64 reduction: every individual
limb product is <2**36 and its sum <2**56, so no modular wrap is possible.
Python integers perform the subsequent shifts, cross-term factors and sums.

This standalone candidate kernel does not replace any frozen verifier.
"""
import math

import numpy as np
from flint import arb, ctx

MAX_CHUNK = 1 << 20
MASK18 = np.uint64((1 << 18) - 1)


def squared_sum(values, *, chunk_size=MAX_CHUNK):
    """Return integers (S,e) satisfying sum(values**2) == S*2**e exactly."""
    if not isinstance(values, np.ndarray) or values.dtype != np.dtype(np.float64):
        raise ValueError("native binary64 ndarray required")
    if type(chunk_size) is not int or not 1 <= chunk_size <= MAX_CHUNK:
        raise ValueError("integer-reduction chunk outside its proved bound")
    bits = np.ascontiguousarray(values).reshape(-1).view(np.uint64)
    exponent = ((bits >> np.uint64(52)) & np.uint64(2047)).astype(np.uint16)
    if np.any(exponent == 2047):
        raise ValueError("finite binary64 inputs required")
    mantissa = bits & np.uint64((1 << 52) - 1)
    normal = exponent != 0
    mantissa = mantissa | (normal.astype(np.uint64) << np.uint64(52))
    exponent = np.maximum(exponent, np.uint16(1))
    nonzero = mantissa != 0
    if not np.any(nonzero):
        return 0, 0
    mantissa, exponent = mantissa[nonzero], exponent[nonzero]
    order = np.argsort(exponent, kind="stable")
    mantissa, exponent = mantissa[order], exponent[order]
    boundaries = np.flatnonzero(exponent[1:] != exponent[:-1]) + 1
    starts = np.concatenate((np.array([0]), boundaries))
    ends = np.concatenate((boundaries, np.array([len(exponent)])))
    minimum = int(exponent[0])
    total = 0
    for start, end in zip(starts, ends):
        group = 0
        for left in range(int(start), int(end), chunk_size):
            m = mantissa[left:min(left + chunk_size, int(end))]
            a, b, c = m >> np.uint64(36), (m >> np.uint64(18)) & MASK18, m & MASK18
            # Every multiply and reduction stays below 2**56. Convert each
            # reduction to a Python int before multiplying/shifting again.
            aa = int(np.sum(a * a, dtype=np.uint64))
            ab = int(np.sum(a * b, dtype=np.uint64))
            ac = int(np.sum(a * c, dtype=np.uint64))
            bb = int(np.sum(b * b, dtype=np.uint64))
            bc = int(np.sum(b * c, dtype=np.uint64))
            cc = int(np.sum(c * c, dtype=np.uint64))
            group += (aa << 72) + (ab << 55) + ((bb + 2 * ac) << 36) + (bc << 19) + cc
        total += group << (2 * (int(exponent[start]) - minimum))
    return total, 2 * (minimum - 1075)


def norm_upper(values, *, precision_bits=256, chunk_size=MAX_CHUNK):
    """Outward binary64 upper bound; infinity is returned on range overflow.

Arb encloses the one final integer conversion, scaling and square root.
The final nextafter covers conversion of its upper endpoint to binary64.
"""
    if type(precision_bits) is not int or precision_bits < 64:
        raise ValueError("at least 64-bit final enclosure precision required")
    integer, exponent = squared_sum(values, chunk_size=chunk_size)
    previous = ctx.prec
    ctx.prec = precision_bits
    try:
        value = arb(integer) * (arb(2) ** exponent)
        return math.nextafter(float(value.sqrt().upper()), math.inf)
    finally:
        ctx.prec = previous
