"""File-backed anchor and signed-response inputs for finite-window assembly.

Anchor conversion, dyadic vector norms, and scalar aggregates are replayed.
Neural gradient/HVP enclosures remain obligations of the authenticated
validated producer; this is not an independent replay of those neural kernels.
No numerical error is set to zero merely because it is small.
"""
from dataclasses import dataclass
import hashlib
import io
import math
from pathlib import Path
from zipfile import ZipFile, BadZipFile

import numpy as np
from flint import arb, ctx

from green_family_evidence import checked_array, number, require
from verified_artifact_io import EvidencePending, IntegrityError
from window_event_assembly import Identity, ResponseBound

RESPONSE_SOURCES = frozenset({"build_candidate_verified_response.py", "outward_variational_response.py",
    "test_outward_variational_response.py", "arb_reverse.py", "arb_reverse_transformer.py",
    "arb_deep_transformer_multijet.py", "arb_transformer_multijet.py", "transformer_hvp_grokking.py",
    "build_larger_candidate_reference.py", "audit_candidate_reverse_arithmetic.py", "audit_candidate_outward_forward.py"})


class HashingStream:
    def __init__(self, stream):
        self.stream = stream
        self.hasher = hashlib.sha256()
        self.count = 0

    def read(self, n=-1):
        value = self.stream.read(n)
        self.hasher.update(value)
        self.count += len(value)
        return value


def array_header(stream, shape):
    try:
        version = np.lib.format.read_magic(stream)
        require(version in ((1,0),(2,0)), "unsupported anchor NPY version")
        parser = np.lib.format.read_array_header_1_0 if version == (1,0) else np.lib.format.read_array_header_2_0
        actual, fortran, dtype = parser(stream, max_header_size=10000)
        require(actual == shape and dtype == np.float64 and fortran is False,
                "anchor array shape/type/order mismatch")
    except (ValueError, EOFError) as error:
        raise IntegrityError("invalid anchor array header") from error


def reference_prefix(reader, relative, expected_sha, *, shape, rows=1):
    """Read a small row prefix while hashing the complete same open stream."""
    require(len(shape) == 2 and type(rows) is int and 1 <= rows <= shape[0], "invalid reference prefix")
    path = reader.resolve(relative)
    try:
        with path.open("rb") as source:
            stream = HashingStream(source)
            array_header(stream, shape)
            header_size = stream.count
            payload = stream.read(rows*shape[1]*8)
            require(len(payload) == rows*shape[1]*8, "truncated reference prefix")
            expected_size = header_size + shape[0]*shape[1]*8
            while stream.read(1024*1024):
                require(stream.count <= expected_size, "excess reference array bytes")
            require(stream.count == expected_size, "truncated reference array")
            reader._remember(path, stream.hasher.hexdigest(), expected_sha)
    except FileNotFoundError:
        raise EvidencePending(f"missing reference artifact: {relative}") from None
    value = np.frombuffer(payload, dtype=np.float64).reshape(rows,shape[1])
    require(np.isfinite(value).all(), "nonfinite reference prefix")
    return value


def original_checkpoint(reader, relative, expected_sha, parameters):
    path = reader.resolve(relative)
    maximum = 16*parameters + 50000
    try:
        with path.open("rb") as stream:
            payload = stream.read(maximum+1)
    except FileNotFoundError:
        raise EvidencePending(f"missing checkpoint artifact: {relative}") from None
    require(len(payload) <= maximum, "oversized checkpoint archive")
    reader._remember(path, hashlib.sha256(payload).hexdigest(), expected_sha)
    try:
        with ZipFile(io.BytesIO(payload)) as archive:
            entries = archive.infolist()
            require(len(entries) == 2 and {v.filename for v in entries} == {"parameter.npy","velocity.npy"},
                    "checkpoint must contain exactly parameter and velocity")
            require(all(v.file_size <= parameters*8+10032 for v in entries), "oversized checkpoint member")
            result = {}
            for key in ("parameter","velocity"):
                data = archive.read(key+".npy")
                stream = io.BytesIO(data)
                array_header(stream,(parameters,))
                values = stream.read()
                require(len(values) == parameters*8, "checkpoint member length mismatch")
                result[key] = np.frombuffer(values,dtype=np.float64)
                require(np.isfinite(result[key]).all(), "nonfinite checkpoint member")
            return result
    except (BadZipFile, ValueError, EOFError) as error:
        raise IntegrityError("invalid checkpoint archive") from error


@dataclass(frozen=True)
class AnchorEvidence:
    identity: Identity
    first_injection_error_upper: float
    audit_sha256: str
    reference_record_sha256: str
    conversion_coordinates: int


def authenticate_anchor(reader, *, identity, candidate_path, reference_record_path,
                        checkpoint_path, corrected_path, original_path, audit_path):
    old = ctx.prec
    ctx.prec = 256
    try:
        require(identity.state_metric == "scaled_momentum_euclidean", "unsupported anchor geometry")
        candidate, candidate_sha = reader.read_json(candidate_path,identity.candidate_sha256)
        reference, reference_sha = reader.read_json(reference_record_path)
        audit, audit_sha = reader.read_json(audit_path)
        reader.check_blob("scripts/audit_candidate_anchor_scaling.py",audit["auditor_sha256"])
        require(reference["candidate_sha256"] == candidate_sha == audit["candidate_sha256"] and
                reference["corrected_scaled_sha256"] == audit["corrected_path_sha256"] == identity.reference_sha256 and
                candidate["anchor_sha256"] == audit["anchor_sha256"], "foreign anchor/reference identity")
        require(type(audit["parameters"]) is int and audit["parameters"] == identity.parameters and
                reference["parameters"] == identity.parameters and reference["horizon"] == identity.horizon,
                "anchor/reference dimensions differ")
        require(audit["precision_bits"] == 256 and audit["future_outcome_access"] is False and
                audit["full_event_certificate"] is False, "incompatible anchor audit scope")
        require(audit["parameter_anchor_exactly_matches"] is True and
                audit["reference_and_corrected_anchors_match"] is True and
                audit["stored_velocity_is_rounded_eta_times_v"] is True, "unsupported or false anchor condition")
        n = identity.parameters
        checkpoint = original_checkpoint(reader,checkpoint_path,candidate["anchor_sha256"],n)
        center = reference_prefix(reader,corrected_path,identity.reference_sha256,shape=(identity.horizon+1,2*n))[0]
        original = reference_prefix(reader,original_path,reference["reference_scaled_sha256"],shape=(identity.horizon+1,2*n))[0]
        require(np.array_equal(center,original) and np.array_equal(center[:n],checkpoint["parameter"]),
                "parameter anchor is not the original checkpoint")
        eta = number(candidate["config"]["learning_rate"],"learning rate",positive=True)
        mu = number(candidate["config"]["momentum"],"momentum")
        require(np.array_equal(center[n:],eta*checkpoint["velocity"]), "stored velocity conversion differs")
        square = arb(0)
        maximum = arb(0)
        nonzero = 0
        for w,v in zip(center[n:],checkpoint["velocity"]):
            delta = arb(eta)*arb(float(v))-arb(float(w))
            square += delta*delta
            maximum = max(maximum,abs(delta).upper())
            nonzero += int(not bool(delta == 0))
        offset = square.sqrt()
        forcing = arb(2).sqrt()*abs(arb(mu))*offset
        for key,value in (("velocity_anchor_offset_norm_upper",offset),
                          ("maximum_coordinate_offset_upper",maximum), ("first_injection_norm_upper",forcing)):
            require(bool(arb(number(audit[key],key)) >= value), "anchor conversion error understated")
        require(type(audit["nonzero_velocity_conversion_coordinates"]) is int and
                audit["nonzero_velocity_conversion_coordinates"] == nonzero and
                audit["exact_scaled_velocity_matches"] is (nonzero == 0), "anchor conversion count mismatch")
        return AnchorEvidence(identity,number(audit["first_injection_norm_upper"],"first anchor injection"),
                              audit_sha,reference_sha,nonzero)
    except (KeyError,TypeError,IndexError) as error:
        raise IntegrityError("malformed anchor evidence") from error
    finally:
        ctx.prec = old


def authenticate_response(reader, folder, *, identity, anchor, gradient_folder, training_count, progress=None):
    old = ctx.prec
    ctx.prec = 256
    try:
        require(isinstance(anchor,AnchorEvidence) and anchor.identity == identity, "response anchor binding mismatch")
        require(type(training_count) is int and training_count > 0, "invalid training population")
        folder = Path(folder)
        summary, summary_sha = reader.read_json(folder/"summary.json",allow_in_progress=True)
        method, mh = reader.read_json(folder/"method.json",summary["method_sha256"])
        reader.check_sources(method,required_names=RESPONSE_SOURCES)
        reader.check_blob("LARGER_CANDIDATE_VERIFIED_RESPONSE_PROTOCOL.md",method["protocol_sha256"])
        require(method["candidate_sha256"] == identity.candidate_sha256 and
                method["path_sha256"] == identity.reference_sha256 and
                method["reference_sha256"] == anchor.reference_record_sha256, "response reference substitution")
        for record in (method,summary):
            require(type(record["parameters"]) is int and record["parameters"] == identity.parameters and
                    type(record["horizon"]) is int and record["horizon"] == identity.horizon and
                    record["precision_bits"] == 192 and record["future_outcome_access"] is False,
                    "response dimension/precision/outcome scope mismatch")
        # The initial gradient was imported from this verified full-mean
        # vector enclosure. Authenticate its producer and exact blob identity.
        gradient_folder = Path(gradient_folder)
        grad, gs = reader.read_json(gradient_folder/"result.json")
        gm, gmh = reader.read_json(gradient_folder/"method.json",grad["method_sha256"])
        reader.check_sources(gm,required_names=RESPONSE_SOURCES - {
            "build_candidate_verified_response.py","outward_variational_response.py","test_outward_variational_response.py"})
        reader.check_blob("LARGER_CANDIDATE_REVERSE_ARITHMETIC_PROTOCOL.md",gm["protocol_sha256"])
        require(gm["candidate_sha256"] == identity.candidate_sha256 and gm["path_sha256"] == identity.reference_sha256 and
                grad["parameters"] == identity.parameters and grad["training_examples"] == training_count and
                grad["reference_step"] == 0 and grad["precision_bits"] == gm["precision_bits"] == 192 and
                gm["future_outcome_access"] is False, "initial gradient enclosure identity/scope mismatch")
        require(grad["enclosures_sha256"] == method["step0_gradient_sha256"], "initial response gradient substitution")
        reader.check_blob(gradient_folder/"derivative_enclosures.npz",method["step0_gradient_sha256"])
        independent, independent_sha = reader.read_json(folder/"independent_complete_audit.json")
        reader.check_blob("scripts/audit_verified_response_records.py",independent["auditor_sha256"])
        H,n = identity.horizon,identity.parameters
        require(independent["all_passed"] is True and independent["summary_sha256"] == summary_sha and
                independent["method_sha256"] == mh and independent["parameters"] == n and
                independent["steps"] == H and independent["coordinates_checked"] == H*2*n and
                independent["future_outcome_access"] is False and independent["full_event_certificate"] is False,
                "independent response audit is incomplete or foreign")
        require(isinstance(summary["rows"],list) and len(summary["rows"]) == H and
                isinstance(independent["rows"],list) and len(independent["rows"]) == H, "incomplete signed response window")
        tau2 = arb(0)
        norm2 = arb(0)
        upper_norms = []
        parameter_norms = [0.]
        for j in range(H):
            entry = summary["rows"][j]
            require(type(entry["step"]) is int and entry["step"] == j, "noncanonical signed response time index")
            row, row_sha = reader.read_json(folder/f"step_{j:03d}.json",entry["sha256"])
            require(type(row["step"]) is int and row["step"] == j and row["method_sha256"] == mh,
                    "response row identity/index mismatch")
            audit_row = independent["rows"][j]
            require(audit_row == {"step":j,"record_sha256":row_sha,"array_sha256":row["response_sha256"]},
                    "response vector differs from independent audit")
            value = checked_array(reader,folder/f"response_{j+1:03d}.npy",row["response_sha256"],2*n)
            a = sum((arb(float(x))**2 for x in value[:n]),arb(0))
            b = sum((arb(float(x))**2 for x in value[n:]),arb(0))
            norm = number(row["response_norm_upper"],"response norm")
            param = number(row["parameter_response_norm_upper"],"parameter response norm")
            residual = number(row["recurrence_error_upper"],"response recurrence residual")
            number(row["defect_norm_upper"],"reference defect norm")
            require(bool(arb(norm) >= (a+b).sqrt()) and bool(arb(param) >= a.sqrt()), "response norm understated")
            norm2 += a+b
            tau2 += arb(residual)**2
            upper_norms.append(norm)
            parameter_norms.append(param)
            if progress is not None:
                progress(j+1,H)
        tau = number(summary["recurrence_sequence_error_upper"],"sequence recurrence error")
        sequence = number(summary["response_sequence_norm_upper"],"response sequence norm")
        require(bool(arb(tau) >= tau2.sqrt()) and bool(arb(sequence) >= norm2.sqrt()), "response aggregate understated")
        require(number(summary["response_max_norm_upper"],"response maximum") == max(upper_norms), "response maximum mismatch")
        for key in ("recurrence_sequence_error_upper","response_sequence_norm_upper","response_max_norm_upper"):
            require(independent[key] == summary[key], "independent response aggregate mismatch")
        return {"bound":ResponseBound(identity,tuple(parameter_norms),tau,anchor.first_injection_error_upper,True,"outward"),
                "provenance":{"summary_sha256":summary_sha,"method_sha256":mh,"initial_gradient_result_sha256":gs,
                    "independent_audit_sha256":independent_sha,"anchor_audit_sha256":anchor.audit_sha256,
                    "coordinates_replayed":H*2*n,"anchor_conversion_replayed":True,
                    "neural_kernels_replayed":False,"event_certificate_issued":False,
                    "training_binding":"fixed candidate config and authenticated deterministic data-split producer"}}
    except (KeyError,TypeError,IndexError) as error:
        raise IntegrityError("malformed response evidence") from error
    finally:
        ctx.prec = old
