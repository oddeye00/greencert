"""Recorded homogeneous-response replay using exact norm verification.

The deterministic forcing and its nonzero initial residual are preserved.
No Gaussian event is assigned to this deterministic response, and no neural
HVP is rerun. The original homogeneous-source module remains unchanged.
"""
import hashlib
import io
from pathlib import Path
import numpy as np
from flint import ctx

from exact_sequence_evidence import authenticate_sequence
from green_family_evidence import SequenceEvidence, checked_array, number, require
from homogeneous_response_evidence import HomogeneousEvidence
from known_anchor_propagation import first_homogeneous_step
from outward_green_products import sequence_upper, streaming_norm_upper
from verified_artifact_io import IntegrityError, require_sha256
from window_event_assembly import Identity

def authenticate(reader, folder, *, identity, summary_sha256, operator_sha256,
                 encoding_sha256, encoded_velocity_offset, learning_rate,
                 momentum, precision_bits=128, progress=None):
    """Require the full deterministic forcing and H-1 verified HVP records.

    The externally bound encoding vector is not itself an encoding proof:
    the file-backed caller must verify its physical-anchor relation and tail.
    `operator_sha256` binds that caller's authenticated construction method.
    In particular this function never constructs a Gaussian calibration.
    """
    old = ctx.prec
    ctx.prec = 256
    try:
        require(isinstance(identity, Identity) and identity.state_metric == "scaled_momentum_euclidean",
                "unsupported homogeneous identity")
        H, n = identity.horizon, identity.parameters
        require(type(H) is int and H > 0 and type(n) is int and n > 0, "invalid full-window shape")
        require(type(precision_bits) is int and precision_bits >= 64, "invalid arithmetic precision")
        eta = number(learning_rate, "learning rate", positive=True)
        mu = number(momentum, "momentum")
        for sha in (summary_sha256, operator_sha256, encoding_sha256):
            require_sha256(sha)
        first = first_homogeneous_step(encoded_velocity_offset, momentum=mu)
        require(len(encoded_velocity_offset) == n, "encoding dimension differs")
        initial = first.pop("next_state")
        folder = Path(folder)
        result, result_sha = reader.read_json(folder/"summary.json", summary_sha256)
        expected = {
            "role":"deterministic_known_anchor_response_not_Gaussian_probe",
            "operator_sha256":operator_sha256, "encoding_sha256":encoding_sha256,
            "horizon":H, "parameters":n, "learning_rate":eta, "momentum":mu,
            "precision_bits":precision_bits,
            "first_step_residual_upper":first["local_residual_norm_upper"],
        }
        require(result["complete"] is True and result["contract"] == expected,
                "incomplete or foreign homogeneous construction")
        require(result["event_certificate_issued"] is False and result["original_anchor_bound_replaced"] is False,
                "homogeneous producer relabeled as event evidence")
        sf = folder/"forcing"
        summary, sha = reader.read_json(sf/"summary.json", result["forcing_manifest_sha256"])
        method, _ = reader.read_json(sf/"method.json", summary["method_sha256"])
        require(summary["complete"] is True and summary["kind"] == method["kind"] == "input_rows" and
                summary["shape"] == method["shape"] == [H,2*n] and method["contract"] == expected and
                method["expected_flat_npy_sha256"] is None, "foreign deterministic forcing")
        require(all(type(v) is int for v in summary["shape"]+method["shape"]),
                "noninteger deterministic forcing shape")
        require(isinstance(summary["rows"], list) and len(summary["rows"]) == H,
                "incomplete deterministic forcing population")
        header = io.BytesIO()
        np.lib.format.write_array_header_1_0(header, {
            "descr":np.dtype(np.float64).str,"fortran_order":False,"shape":(H*2*n,)})
        flat = hashlib.sha256(header.getvalue())
        norms = []
        for j, row in enumerate(summary["rows"]):
            require(type(row["index"]) is int and row["index"] == j and row["file"] == f"row_{j:03d}.npy",
                    "noncanonical deterministic forcing row")
            value = checked_array(reader, sf/row["file"], row["sha256"], 2*n)
            require(np.array_equal(value, initial) if j == 0 else not np.any(value),
                    "homogeneous forcing changed or contains a later injection")
            norm = number(row["norm_upper"], "forcing norm")
            if j == 0:
                require(norm == streaming_norm_upper(value), "initial forcing norm differs")
            # Later vectors were checked exactly zero. Any nonnegative bound
            # encloses their norm; no O(H*d) Arb summation of zeros is needed.
            norms.append(norm)
            flat.update(value.tobytes())
        require(summary["flat_npy_sha256"] == flat.hexdigest(), "deterministic forcing identity mismatch")
        require(number(summary["terminal_sequence_norm_upper"], "forcing sequence norm") == sequence_upper(norms),
                "deterministic forcing aggregate differs")
        forcing = SequenceEvidence(sf, sha, summary, method)
        response = authenticate_sequence(reader, folder/"response",
            expected_sha=result["response_manifest_sha256"], shape=(H,2*n), kind="forward",
            contract=expected, inputs=forcing, precision_bits=precision_bits,
            learning_rate=eta, momentum=mu)
        later = response.summary["residual_sequence_upper"]
        full = sequence_upper([first["local_residual_norm_upper"], later])
        require(result["first_step_residual_upper"] == first["local_residual_norm_upper"] and
                result["later_product_residual_upper"] == later and
                result["full_window_residual_upper"] == full, "initial or full residual omitted/altered")
        require(type(result["hvp_calls"]) is int and result["hvp_calls"] == H-1,
                "wrong homogeneous HVP count")
        if progress is not None:
            progress(H,H)
        return HomogeneousEvidence(identity, folder, result_sha, response, full,
                                   operator_sha256, encoding_sha256)
    except (KeyError, TypeError, IndexError) as error:
        raise IntegrityError("malformed homogeneous response evidence") from error
    finally:
        ctx.prec = old
