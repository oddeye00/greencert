"""Compare read-only replay components with their unchanged reference auditors.

All mutated records are synthetic and owned by a TemporaryDirectory. Their
digests are refreshed, so refusals test semantics rather than stale hashes.
These tests do not execute neural producers or issue event certificates.
"""
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
import argparse
import copy
from dataclasses import replace
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import tempfile

import numpy as np
from flint import arb, ctx

from anchor_response_evidence import authenticate_anchor
from exact_dyadic_l2 import squared_sum
from exact_dyadic_norm import squared_integer
from exact_homogeneous_replay import authenticate as replay_homogeneous
from exact_response_replay import authenticate_response as replay_response
from exact_runtime_green_replay import authenticate_runtime_green_family as replay_green
from known_anchor_green_response import construct
from recorded_evidence_replay import RecordedEvidenceReader
from runtime_green_evidence import authenticate_runtime_green_family as reference_green
from test_anchor_response_evidence import fixture as response_fixture, run as reference_response
from test_combined_anchor_evidence import auth as reference_homogeneous
from test_runtime_green_evidence import fixture as green_fixture
from verified_artifact_io import EvidenceReader, IntegrityError
from window_event_assembly import Identity


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(root):
    return RecordedEvidenceReader(root, {p.relative_to(root).as_posix(): digest(p)
                                        for p in root.rglob("*") if p.is_file()})


def rewrite(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+"\n", encoding="utf-8", newline="\n")
    return digest(path)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    counts = {name: 0 for name in ("norm_cross_implementation_checks", "green_equal_cases",
        "response_equal_cases", "homogeneous_equal_cases", "semantic_refusals", "read_barrier_refusals",
        "existing_future_not_read_cases")}

    def refuses(call, key="semantic_refusals"):
        try:
            call()
        except IntegrityError:
            counts[key] += 1
        else:
            raise AssertionError("incompatible evidence accepted")

    rng = np.random.default_rng(20260907)
    words = rng.integers(0, 2**64, 8192, dtype=np.uint64)
    words[((words >> np.uint64(52)) & np.uint64(2047)) == 2047] ^= np.uint64(1) << np.uint64(52)
    arrays = [np.array([], dtype=np.float64), np.array([0., -0.]),
        np.array([np.nextafter(0., 1.), np.finfo(np.float64).tiny, np.finfo(np.float64).max]),
        words.view(np.float64), rng.normal(size=8192)[::3]]
    for values in arrays:
        oracle = sum((Fraction(float(x))**2 for x in values), Fraction())
        for chunk in (7, 257, 65536):
            integer, exponent = squared_sum(values, chunk_size=chunk)
            actual = Fraction(squared_integer(values, chunk_size=chunk), 1 << 2148)
            assert actual == Fraction(integer)*Fraction(2)**exponent == oracle
            counts["norm_cross_implementation_checks"] += 1

    with tempfile.TemporaryDirectory(prefix="greencert_readonly_components_") as temporary:
        top = Path(temporary).resolve()
        assert top.name.startswith("greencert_readonly_components_")
        for i, case in enumerate(((1,1,1,1), (2,3,2,1), (3,2,4,1), (4,5,4,2))):
            root = top/f"green_{i}"
            args, _ = green_fixture(root, *case)
            expected = reference_green(EvidenceReader(root), **args)
            actual = replay_green(pin(root), **args)
            for key in ("bound", "scalar_inputs", "green_norm"):
                assert actual[key] == expected[key], key
            counts["green_equal_cases"] += 1
            for key, value in (("power", 0), ("failure_probability", .02), ("learning_rate", .004),
                ("momentum", .8), ("forbidden_paths", ()), ("sequence_plan", args["sequence_plan"][:-1]),
                ("original_probe_hashes", ("0"*64,)+args["original_probe_hashes"][1:]),
                ("identity", replace(args["identity"], parameters=case[1]+1))):
                changed = {**args, key: value}
                refuses(lambda: replay_green(pin(root), **changed))
            for role in ("forward", "adjoint"):
                changed = copy.deepcopy(args)
                changed["sequence_plan"][-1][-1][role]["method"] = "unregistered"
                refuses(lambda: replay_green(pin(root), **changed))
            method_path = root/"remote/method.json"
            saved_method = read(method_path)
            for key, value in (("learning_rate", .004), ("delta", .02), ("parameters", case[1]+1)):
                altered = {**saved_method, key: value}
                changed = copy.deepcopy(args)
                changed["executions"]["arm"]["method_sha256"] = rewrite(method_path, altered)
                refuses(lambda: replay_green(pin(root), **changed))
                assert rewrite(method_path, saved_method) == args["executions"]["arm"]["method_sha256"]
            last = root/args["sequence_plan"][-1][-1]["adjoint"]["folder"]
            saved = read(last/"summary.json")
            rewrite(last/"summary.json", {**saved, "terminal_sequence_norm_upper": 0.})
            refuses(lambda: replay_green(pin(root), **args))
            rewrite(last/"summary.json", saved)
            if case[0] > 1:
                row = read(last/"row_000.json")
                altered_row = {**row, "hvp_step": 999}
                rewrite(last/"row_000.json", altered_row)
                altered = copy.deepcopy(saved)
                altered["rows"][0] = altered_row
                rewrite(last/"summary.json", altered)
                refuses(lambda: replay_green(pin(root), **args))
                rewrite(last/"row_000.json", row)
                rewrite(last/"summary.json", saved)
            # Future existence is acceptable for a retrospective replay,
            # but future content is never a permitted premise.
            pinned = pin(root)
            rewrite(root/"reveal.json", {"synthetic_future": "must not be read"})
            actual = replay_green(pinned, **args)
            assert "reveal.json" not in pinned.observed and actual["bound"] == expected["bound"]
            counts["existing_future_not_read_cases"] += 1
            refuses(lambda: replay_green(pin(root), **args), "read_barrier_refusals")
            # Prefix exclusion also covers files beneath an observation run.
            (root/"registered_outcome_run").mkdir()
            rewrite(root/"registered_outcome_run/reservation.json", {"synthetic": True})
            changed = {**args, "forbidden_paths": ("REGISTERED_OUTCOME_RUN",)}
            refuses(lambda: replay_green(pin(root), **changed), "read_barrier_refusals")

        def check_response(args):
            changed = {**args, "reader": pin(args["reader"].root)}
            anchor = authenticate_anchor(**changed)
            return replay_response(changed["reader"], "response", identity=changed["identity"], anchor=anchor,
                                   gradient_folder="gradient", training_count=2)

        for i, (H,n,eta,mu) in enumerate(((1,1,.1,.9), (3,4,.125,.9), (5,7,.1,0.), (3,4,.1,.9))):
            args = response_fixture(top/f"response_{i}", H=H, n=n, eta=eta, mu=mu)
            expected = reference_response(args)[1]
            assert check_response(args) == expected
            counts["response_equal_cases"] += 1
        changes = (("anchor","first_injection_norm_upper",0.), ("anchor","future_outcome_access",True),
            ("method","sources",{}), ("method","candidate_sha256","0"*64),
            ("method","path_sha256","0"*64), ("method","reference_sha256","0"*64),
            ("method","step0_gradient_sha256","0"*64), ("method","precision_bits",64),
            ("gradient","training_examples",1), ("gradient","reference_step",1),
            ("gradient_method","path_sha256","0"*64), ("gradient_method","sources",{}),
            ("row","parameter_response_norm_upper",0.), ("row","response_norm_upper",0.),
            ("row","recurrence_error_upper",-1.), ("row","step",999),
            ("summary","recurrence_sequence_error_upper",0.), ("summary","response_sequence_norm_upper",0.),
            ("summary","response_max_norm_upper",0.), ("summary","rows",[]),
            ("independent","all_passed",False), ("independent","coordinates_checked",1),
            ("independent","rows",[]), ("independent","summary_sha256","0"*64))
        for i, (stage, key, value) in enumerate(changes):
            def mutate(actual, row, **where):
                if actual == stage and (stage != "row" or where["j"] == 1):
                    row[key] = value
            args = response_fixture(top/f"bad_response_{i}", mutation=mutate)
            refuses(lambda: check_response(args))

        for n in (1,3):
            for H in (1,4,8):
                root = top/f"homogeneous_{n}_{H}"
                root.mkdir()
                identity = Identity("d"*64,"e"*64,"f"*64,"0"*64,n,H,"scaled_momentum_euclidean")
                encoded = rng.normal(size=n)*1e-12
                def kernel(j, direction):
                    return [arb(j+i+1)*v for i,v in enumerate(direction)]
                construct(root/"homogeneous", encoded, kernel, horizon=H, learning_rate=.003, momentum=.9,
                          operator_sha256="a"*64, encoding_sha256="b"*64)
                def check_homogeneous():
                    return replay_homogeneous(pin(root), "homogeneous", identity=identity,
                        summary_sha256=digest(root/"homogeneous/summary.json"), operator_sha256="a"*64,
                        encoding_sha256="b"*64, encoded_velocity_offset=encoded, learning_rate=.003, momentum=.9)
                assert check_homogeneous() == reference_homogeneous(root, identity, encoded)
                counts["homogeneous_equal_cases"] += 1
                path = root/"homogeneous/summary.json"
                saved = read(path)
                for key, value in (("first_step_residual_upper",0.), ("full_window_residual_upper",0.),
                    ("hvp_calls",999), ("event_certificate_issued",True), ("complete",False)):
                    rewrite(path, {**saved, key:value})
                    refuses(check_homogeneous)
                    rewrite(path, saved)
    return {"status":"PASS", **counts, "neural_kernels_replayed":False, "event_certificates_issued":0,
            "future_outcome_access":False, "frozen_implementations_modified":False,
            "scope":"Synthetic exact-quadratic and provenance fixtures; not a neural event replay."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    previous = ctx.prec
    ctx.prec = 256
    try:
        result = main()
    finally:
        ctx.prec = previous
    if args.report:
        with args.report.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(result, stream, indent=2, allow_nan=False)
            stream.write("\n")
    print(json.dumps(result, indent=2))
