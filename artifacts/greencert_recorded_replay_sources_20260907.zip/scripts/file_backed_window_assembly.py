"""Join authenticated finite-window evidence before a separate disposition.

This is a two-phase verifier. Missing work is pending, not abstention. A
complete join evaluates the outward state/event inequalities but does not
seal a construction disposition or open a future outcome. Neural kernels
remain obligations of the registered validated producers.
"""
from dataclasses import asdict, dataclass
import hashlib
import json
import math
from pathlib import Path

from anchor_response_evidence import authenticate_anchor, authenticate_response
from bound_row_evidence import PRODUCERS, authenticate_bound_row
from green_family_evidence import authenticate_green_family, canonical_sha, require
from reference_margin_evidence import authenticate_reference_window, intersect_with_derivative_row
from verified_artifact_io import EvidencePending, IntegrityError, require_sha256
from window_event_assembly import Identity, assemble


@dataclass(frozen=True)
class BoundRowLocation:
    step: int
    folder: str
    producer: str


@dataclass(frozen=True)
class WindowEvidenceRequest:
    identity: Identity
    anchor_paths: dict
    response_folder: str
    gradient_folder: str
    reference_margin_folder: str
    green_folder: str
    green_method_sha256: str
    original_probe_hashes: tuple[str, ...]
    power: int
    failure_probability: float
    learning_rate: float
    momentum: float
    training_examples: list
    evaluation_examples: list
    example_ids: tuple[str, ...]
    classes: int
    normalization_eps: list
    row_plan: tuple[BoundRowLocation, ...]
    domain: float
    target: int
    persistence: int
    forbidden_outcome_files: tuple[str, ...]


def fingerprint(request):
    def convert(value):
        if isinstance(value, Path):
            return str(value)
        raise TypeError("non-serializable evidence request")
    payload = json.dumps(asdict(request), sort_keys=True, separators=(",", ":"),
                         allow_nan=False, default=convert).encode()
    return hashlib.sha256(payload).hexdigest()


def _validate(reader, request):
    require(isinstance(request, WindowEvidenceRequest), "invalid window evidence request")
    ident = request.identity
    require(isinstance(ident, Identity) and type(ident.parameters) is int and ident.parameters > 0 and
            type(ident.horizon) is int and ident.horizon > 0 and
            ident.state_metric == "scaled_momentum_euclidean", "unsupported window identity/geometry")
    for name in ("candidate_sha256", "reference_sha256", "training_set_sha256", "evaluation_set_sha256"):
        require_sha256(getattr(ident, name))
    require(canonical_sha(request.training_examples) == ident.training_set_sha256 and
            canonical_sha(request.evaluation_examples) == ident.evaluation_set_sha256,
            "window population identity mismatch")
    require(isinstance(request.training_examples, list) and len(request.training_examples) > 0 and
            isinstance(request.evaluation_examples, list) and len(request.evaluation_examples) > 0,
            "empty fixed population")
    require(isinstance(request.example_ids, tuple) and
            len(request.example_ids) == len(request.evaluation_examples) and
            all(isinstance(v, str) and v for v in request.example_ids) and
            len(set(request.example_ids)) == len(request.example_ids), "invalid fixed example identifiers")
    require(type(request.classes) is int and request.classes >= 2, "invalid class count")
    for population in (request.training_examples, request.evaluation_examples):
        require(all(type(v["index"]) is int and v["index"] == j and type(v["label"]) is int and
                    0 <= v["label"] < request.classes for j, v in enumerate(population)),
                "noncanonical fixed population")
    require(type(request.target) is int and 1 <= request.target <= len(request.example_ids) and
            type(request.persistence) is int and 1 <= request.persistence <= ident.horizon+1,
            "invalid fixed event definition")
    for value in (request.domain, request.learning_rate, request.momentum, request.failure_probability):
        require(type(value) in (int, float) and math.isfinite(value), "invalid window scalar")
    require(request.domain >= 0 and request.learning_rate > 0 and request.momentum >= 0 and
            0 < request.failure_probability < 1 and type(request.power) is int and request.power > 0,
            "invalid domain/optimizer/probability policy")
    require_sha256(request.green_method_sha256)
    require(isinstance(request.original_probe_hashes, tuple) and len(request.original_probe_hashes) > 0,
            "missing original probe family")
    for sha in request.original_probe_hashes:
        require_sha256(sha)
    require(isinstance(request.row_plan, tuple) and
            all(isinstance(row, BoundRowLocation) and type(row.step) is int for row in request.row_plan) and
            tuple(row.step for row in request.row_plan) == tuple(range(1, ident.horizon+1)),
            "row plan must contain every future output step exactly once in order")
    resolved = []
    for row in request.row_plan:
        require(row.producer in PRODUCERS, "unregistered row-plan producer")
        resolved.append(reader.resolve(row.folder))
    require(len(set(resolved)) == len(resolved), "one derivative folder cannot cover multiple centers")
    require(isinstance(request.anchor_paths, dict) and set(request.anchor_paths) == {
        "candidate_path", "reference_record_path", "checkpoint_path", "corrected_path", "original_path", "audit_path"},
        "incomplete anchor evidence specification")
    for path in (*request.anchor_paths.values(), request.response_folder, request.gradient_folder,
                 request.reference_margin_folder, request.green_folder):
        reader.resolve(path)
    require(isinstance(request.forbidden_outcome_files, tuple) and len(request.forbidden_outcome_files) > 0,
            "missing registered future-outcome barrier")
    for path in request.forbidden_outcome_files:
        reader.resolve(path)


def _barrier(reader, request):
    require(all(not reader.resolve(path).exists() for path in request.forbidden_outcome_files),
            "registered future outcome already exists")


def assemble_window_evidence(reader, request, *, progress=None):
    """Authenticate every component, then evaluate closure if all are ready.

No missing component is replaced by a float64 diagnostic, point-only output,
or smaller complete prefix. Integrity failures raise; only missing/in-progress
artifacts become pending. Returned records do not authorize an outcome join.
"""
    try:
        _validate(reader, request)
    except (KeyError, TypeError, OverflowError) as error:
        raise IntegrityError("malformed window evidence request") from error
    original_request = fingerprint(request)
    _barrier(reader, request)
    missing, provenance, rows = [], {}, {}

    def attempt(name, operation):
        _barrier(reader, request)
        if progress:
            progress(name, "started")
        try:
            value = operation()
        except EvidencePending as error:
            missing.append({"component": name, "reason": str(error)})
            if progress:
                progress(name, "pending")
            return None
        provenance[name] = value.get("provenance", {}) if isinstance(value, dict) else asdict(value)
        if progress:
            progress(name, "authenticated")
        return value

    anchor = attempt("anchor", lambda: authenticate_anchor(reader, identity=request.identity, **request.anchor_paths))
    response = None
    if anchor is None:
        missing.append({"component": "response", "reason": "requires authenticated exact parameter anchor"})
    else:
        response = attempt("response", lambda: authenticate_response(reader, request.response_folder,
            identity=request.identity, anchor=anchor, gradient_folder=request.gradient_folder,
            training_count=len(request.training_examples)))
    margins = attempt("reference_margins", lambda: authenticate_reference_window(reader,
        request.reference_margin_folder, identity=request.identity, evaluation=request.evaluation_examples,
        example_ids=request.example_ids, classes=request.classes, normalization_eps=request.normalization_eps))
    for location in request.row_plan:
        row = attempt(f"derivative_row_{location.step:03d}", lambda: authenticate_bound_row(reader, location.folder,
            identity=request.identity, step=location.step, domain=request.domain, producer=location.producer,
            training_examples=request.training_examples, evaluation_examples=request.evaluation_examples,
            example_ids=request.example_ids))
        if row is not None:
            rows[location.step] = row
    green = attempt("green", lambda: authenticate_green_family(reader, request.green_folder,
        identity=request.identity, power=request.power, method_sha256=request.green_method_sha256,
        original_probe_hashes=request.original_probe_hashes, failure_probability=request.failure_probability,
        learning_rate=request.learning_rate, momentum=request.momentum))
    _barrier(reader, request)
    require(fingerprint(request) == original_request, "evidence request changed during assembly")
    result = {"request_sha256": original_request, "identity": asdict(request.identity),
        "event_definition": {"target": request.target, "persistence": request.persistence},
        "status": "pending", "missing": missing, "authenticated_components": list(provenance),
        "authenticated_derivative_steps": sorted(rows), "provenance": provenance,
        "assembly": None, "event_certificate_issued": False, "construction_disposition_sealed": False,
        "future_outcome_access": False, "registered_outcome_files_absent": True,
        "conditional_on_validated_producers": True, "neural_kernels_replayed": False,
        "scope": "file-authenticated outward bounds; Green gain conditional on original ideal-Gaussian event"}
    if missing:
        return result
    if green["bound"] is None:
        return {**result, "status": "no_finite_green_bound_at_requested_power"}
    output = [margins["anchor"]]
    drift = []
    for step in range(1, request.identity.horizon+1):
        output.append(intersect_with_derivative_row(margins["rows"][step], rows[step]["output"]))
        if step < request.identity.horizon:
            require(rows[step]["drift"] is not None, "authenticated interior row has no drift")
            drift.append(rows[step]["drift"])
        else:
            require(rows[step]["drift"] is None, "terminal output row unexpectedly contains drift")
    assembled = assemble(identity=request.identity, training_count=len(request.training_examples),
        example_ids=request.example_ids, domain=request.domain, drift_rows=drift, output_rows=output,
        response=response["bound"], green=green["bound"], target=request.target,
        persistence=request.persistence, precision_bits=256)
    require(assembled["inputs_compatible"], "authenticated components violate scalar assembly contract: " +
            str(assembled.get("reason")))
    _barrier(reader, request)
    return {**result, "status": "enclosure_available_for_separate_disposition" if assembled["bracket"] is not None
            else "assembly_abstention", "assembly": assembled}
