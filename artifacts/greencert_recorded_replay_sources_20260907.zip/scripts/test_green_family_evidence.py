"""Small exact-quadratic fixtures exercise complete file-backed Green checks.

These are operator/integrity regressions, not trained-network confirmations.
Semantic corruptions are rehashed coherently to test more than byte identity.
"""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tempfile

import numpy as np
from flint import arb, ctx

from checkpointed_green_products import store_rows, product, StoredRows
from green_family_evidence import (PROTOCOLS, REQUIRED_SOURCES, SCOPE,
                                   authenticate_green_family, canonical_sha, checked_array)
from green_local_residual_bounds import gram_operator_upper
from outward_inexact_anytime_gram import folded_normal_calibration_lower
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError
from window_event_assembly import Identity

ROOT = Path(__file__).resolve().parents[1]


def write(path, value):
    data = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_fixture(root, *, H=3, n=2, probes=2, power=2, mutation=None):
    root.mkdir()
    sources = {}
    for name in REQUIRED_SOURCES:
        path = root / "scripts" / name
        path.parent.mkdir(exist_ok=True)
        path.write_text("# synthetic source-provenance fixture\n")
        sources[name] = digest(path)
    policies = {}
    for field, name in PROTOCOLS.items():
        path = root / name
        path.write_text("synthetic operator regression policy\n")
        policies[field] = digest(path)
    training = [{"index": 0, "pair": [0, 1], "label": 1}]
    identity = Identity(canonical_sha("candidate"), canonical_sha("path"), canonical_sha(training),
                        canonical_sha("evaluation"), n, H, "scaled_momentum_euclidean")
    rng = np.random.default_rng(53918)
    vectors = [rng.normal(size=(H, 2*n)) for _ in range(probes)]
    hashes = []
    for value in vectors:
        buffer = io.BytesIO()
        np.save(buffer, value.reshape(-1), allow_pickle=False)
        hashes.append(hashlib.sha256(buffer.getvalue()).hexdigest())
    method = {"sources": sources, **policies, "candidate_sha256": identity.candidate_sha256,
        "path_sha256": identity.reference_sha256, "parameters": n, "horizon": H, "state_dimension": 2*n,
        "probes": probes, "delta": .01, "initial_probe_flat_npy_sha256": hashes,
        "learning_rate": .003, "momentum": .9, "precision_bits": 128, "scalar_precision_bits": 256,
        "future_outcome_access": False, "powers": list(range(1, power+1)),
        "training_pairs": [[0, 1]], "training_labels": [1], "training_examples": 1,
        "hvp_backend": "full empirical data loss plus exact once-only quadratic-penalty HVP"}
    folder = root / "green"
    mh = write(folder / "method.json", method)
    pairs = []
    def kernel(j, direction):
        # A time-varying exact diagonal quadratic: no unverified HVP rounding.
        return [arb(j+k+1)/8 * x for k, x in enumerate(direction)]
    for probe, value in enumerate(vectors):
        base = folder / f"probe_{probe}"
        previous = store_rows(base / "initial", iter(value), shape=value.shape,
            contract={"method_sha256": mh, "probe": probe}, expected_flat_npy_sha256=hashes[probe])
        powers = []
        for q in range(1, power+1):
            pair = {}
            for kind in ("forward", "adjoint"):
                target = base / f"power_{q:02d}" / kind
                pair[kind] = product(target, previous, kernel, learning_rate=.003, momentum=.9,
                    transpose=kind == "adjoint", precision_bits=128,
                    contract={"method_sha256": mh, "probe": probe, "power": q})
                previous = StoredRows(target)
            powers.append(pair)
        pairs.append(powers)
    ds = [max(row[q]["forward"]["residual_sequence_upper"] for row in pairs) for q in range(power)]
    es = [max(row[q]["adjoint"]["residual_sequence_upper"] for row in pairs) for q in range(power)]
    terminal = max(row[-1]["adjoint"]["terminal_sequence_norm_upper"] for row in pairs)
    calibration = folded_normal_calibration_lower(delta=.01, probes=probes)
    norm = gram_operator_upper(shift=0, terminal_upper=terminal, calibration_lower=calibration,
                               forward_residuals=ds, adjoint_residuals=es)
    result = {"method_sha256": mh, "power": power, "complete_probe_count": probes,
              "calibration_lower": calibration, "terminal_upper": terminal,
              "forward_residuals": ds, "adjoint_residuals": es, "green_norm": norm,
              "future_outcome_access": False, "event_certificate": None, "scope": SCOPE}
    # Rewrite the artifact DAG bottom-up after each injected semantic change.
    # Consequently a rejected corruption cannot be dismissed as just a stale
    # checksum at the top of an otherwise unexamined chain.
    def change(stage, value, **where):
        if mutation is not None:
            mutation(stage, value, **where)
    change("method", method)
    mh = write(folder / "method.json", method)
    manifest = []
    for probe in range(probes):
        base = folder / f"probe_{probe}"
        target = base / "initial"
        sm = read(target / "method.json")
        ss = read(target / "summary.json")
        sm["contract"]["method_sha256"] = mh
        ss["method_sha256"] = write(target / "method.json", sm)
        previous_sha = write(target / "summary.json", ss)
        previous_rows = ss["rows"]
        family = []
        for q in range(1, power+1):
            pair = {}
            for kind in ("forward", "adjoint"):
                target = base / f"power_{q:02d}" / kind
                sm, ss = read(target / "method.json"), read(target / "summary.json")
                sm["contract"]["method_sha256"] = mh
                sm["input_manifest_sha256"] = previous_sha
                change("sequence_method", sm, probe=probe, q=q, kind=kind)
                smh = write(target / "method.json", sm)
                parent = None
                for j in (range(H-1, -1, -1) if kind == "adjoint" else range(H)):
                    row = read(target / f"row_{j:03d}.json")
                    row["method_sha256"] = smh
                    row["input_row_sha256"] = previous_rows[j]["sha256"]
                    row["parent_record_sha256"] = parent
                    change("row", row, probe=probe, q=q, kind=kind, j=j)
                    parent = write(target / f"row_{j:03d}.json", row)
                    ss["rows"][j] = row
                ss["method_sha256"] = smh
                ss["input_manifest_sha256"] = previous_sha
                change("sequence_summary", ss, probe=probe, q=q, kind=kind)
                previous_sha = write(target / "summary.json", ss)
                previous_rows = ss["rows"]
                pair[kind+"_manifest_sha256"] = previous_sha
            family.append(pair)
        manifest.append(family)
    result["method_sha256"] = mh
    result["product_manifest_sha256"] = manifest
    change("result", result)
    write(folder / f"power_{power:02d}.json", result)
    return dict(reader=EvidenceReader(root), folder="green", identity=identity, power=power,
        method_sha256=mh, original_probe_hashes=tuple(hashes), failure_probability=.01, learning_rate=.003, momentum=.9)


def main():
    parent = ROOT / "tmp"
    parent.mkdir(exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix="green_evidence_test_", dir=parent)).resolve()
    require_scope = temp.parent == parent.resolve() and temp.name.startswith("green_evidence_test_")
    assert require_scope
    report = {"all_passed": True, "complete_quadratic_families": 0, "coherently_rehashed_rejections": 0,
              "partial_family_pending": 0, "array_allocation_guard_rejections": 0,
              "trained_networks": 0, "event_certificates_issued": 0}
    old = ctx.prec
    ctx.prec = 256
    try:
        for i, (H, n, probes, power) in enumerate(((1,1,1,1), (2,4,2,1), (3,2,2,2), (5,8,4,2))):
            args = make_fixture(temp/f"valid_{i}", H=H, n=n, probes=probes, power=power)
            result = authenticate_green_family(**args)
            assert result["bound"] is not None and result["bound"].gain_upper >= 1
            assert result["bound"].expected_probes == result["bound"].complete_probes == probes
            assert result["bound"].probability_scope == "ideal_gaussian_probes"
            assert result["provenance"]["array_norms_replayed"] and not result["provenance"]["neural_hvps_replayed"]
            report["complete_quadratic_families"] += 1
        def field(stage, name, value, **criteria):
            def mutation(actual, row, **where):
                if actual == stage and all(where.get(k) == v for k,v in criteria.items()):
                    row[name] = value
            return mutation
        mutations = [
            field("method", "candidate_sha256", canonical_sha("other")),
            field("method", "path_sha256", canonical_sha("other")),
            field("method", "parameters", 3), field("method", "horizon", 4),
            field("method", "state_dimension", 8), field("method", "training_labels", [0]),
            field("method", "training_examples", 2), field("method", "delta", .1),
            field("method", "probes", 1), field("method", "precision_bits", 64),
            field("method", "hvp_backend", "float64"), field("method", "sources", {}),
            field("method", "powers", [2]), field("method", "future_outcome_access", True),
            field("sequence_method", "kind", "input_rows", probe=0,q=1,kind="forward"),
            field("sequence_method", "learning_rate", .004, probe=0,q=1,kind="forward"),
            field("sequence_method", "input_manifest_sha256", "0"*64, probe=0,q=2,kind="forward"),
            field("row", "hvp_step", 0, probe=0,q=1,kind="forward",j=1),
            field("row", "hvp_step", 0, probe=0,q=1,kind="adjoint",j=1),
            field("row", "parent_record_sha256", "0"*64, probe=0,q=1,kind="forward",j=1),
            field("row", "input_row_sha256", "0"*64, probe=0,q=1,kind="forward",j=1),
            field("row", "file", "../row_001.npy", probe=0,q=1,kind="forward",j=1),
            field("row", "norm_upper", 0., probe=0,q=1,kind="forward",j=1),
            field("row", "local_residual_norm_upper", -.1, probe=0,q=1,kind="forward",j=1),
            field("row", "local_residual_norm_upper", 1., probe=0,q=1,kind="forward",j=0),
            field("sequence_summary", "hvp_calls", 1, probe=0,q=1,kind="adjoint"),
            field("sequence_summary", "complete", False, probe=0,q=1,kind="adjoint"),
            field("sequence_summary", "terminal_sequence_norm_upper", 0., probe=0,q=1,kind="forward"),
            field("sequence_summary", "residual_sequence_upper", 0., probe=0,q=1,kind="adjoint"),
            field("result", "complete_probe_count", 1), field("result", "calibration_lower", 1.),
            field("result", "terminal_upper", 0.), field("result", "forward_residuals", [0.,0.]),
            field("result", "adjoint_residuals", [0.,0.]), field("result", "scope", "deterministic"),
            field("result", "product_manifest_sha256", []), field("result", "green_norm", {"enclosed": True, "operator_upper": 1.}),
        ]
        for i, mutate in enumerate(mutations):
            args = make_fixture(temp/f"invalid_{i}", mutation=mutate)
            try:
                authenticate_green_family(**args)
            except IntegrityError:
                report["coherently_rehashed_rejections"] += 1
            else:
                raise AssertionError(f"coherent semantic corruption {i} was accepted")
        for i, missing in enumerate(("green/power_02.json", "green/probe_1/power_02/adjoint/summary.json",
                                     "green/probe_0/initial/row_000.npy")):
            args = make_fixture(temp/f"pending_{i}")
            (args["reader"].root/missing).unlink()  # This test's freshly generated fixture only.
            try:
                authenticate_green_family(**args)
            except EvidencePending:
                report["partial_family_pending"] += 1
            else:
                raise AssertionError("incomplete probe family promoted")
        # Check untrusted headers before allocation, including a dimension
        # that would request terabytes if passed unchecked to np.load.
        fixture=temp/"array_guards"
        fixture.mkdir()
        huge=io.BytesIO()
        np.lib.format.write_array_header_1_0(huge,{"descr":"<f8","fortran_order":False,"shape":(2**38,)})
        wrong=io.BytesIO()
        np.save(wrong,np.ones(4,dtype=np.float32),allow_pickle=False)
        normal=io.BytesIO()
        np.save(normal,np.ones(4,dtype=np.float64),allow_pickle=False)
        for i, data in enumerate((huge.getvalue(),wrong.getvalue(),normal.getvalue()+b"extra",
                                 normal.getvalue()[:-3],b"X"*100100)):
            file=fixture/f"invalid_{i}.npy"
            file.write_bytes(data)
            try:
                checked_array(EvidenceReader(fixture),file.name,digest(file),4)
            except IntegrityError:
                report["array_allocation_guard_rejections"]+=1
            else:
                raise AssertionError("malformed array allocation accepted")
        print(json.dumps(report, indent=2))
        return report
    finally:
        ctx.prec = old
        assert temp.resolve().parent == parent.resolve() and temp.name.startswith("green_evidence_test_")
        shutil.rmtree(temp)


if __name__ == "__main__":
    main()
