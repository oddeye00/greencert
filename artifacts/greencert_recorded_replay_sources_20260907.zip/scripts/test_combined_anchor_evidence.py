"""File-backed response-join tests, with exact dyadic cancellation references.

Original ResponseBound fixtures model an already authenticated caller input;
they are not new neural/gradient evidence. No event certificate is created.
"""
import os
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
from dataclasses import replace
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import shutil
import tempfile

import numpy as np
from flint import arb, ctx

from checkpointed_green_products import digest, save_array, save_json, StoredRows
from combined_anchor_response import combine, CombinedResponseProfile
from homogeneous_response_evidence import authenticate
from known_anchor_green_response import construct
from outward_green_products import streaming_norm_upper
from registered_outcome_continuation import publish_json, utc
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError
from window_event_assembly import Identity, ResponseBound


def rewrite(path, record):
    # Test-only corruption in a TemporaryDirectory owned by this process.
    path.write_text(json.dumps(record, sort_keys=True, indent=2)+"\n")
    return digest(path)


def auth(root, identity, encoded, folder="homogeneous"):
    return authenticate(EvidenceReader(root), folder, identity=identity,
        summary_sha256=digest(root/folder/"summary.json"), operator_sha256="a"*64,
        encoding_sha256="b"*64, encoded_velocity_offset=encoded,
        learning_rate=.003, momentum=.9)


def original_fixture(root, identity, homogeneous, *, perturbation):
    folder = root/"original"
    source = StoredRows(root/homogeneous.response.folder)
    rows = []
    norms = [0.]
    values = []
    old = ctx.prec; ctx.prec = 256
    try:
        for j in range(identity.horizon):
            value = -source.row(j)
            value[0] += perturbation*(j+1)
            save_array(folder/f"response_{j+1:03d}.npy", value)
            norm = streaming_norm_upper(value[:identity.parameters])
            row = {"step":j,"method_sha256":"c"*64,
                   "parameter_response_norm_upper":norm,
                   "response_sha256":digest(folder/f"response_{j+1:03d}.npy")}
            save_json(folder/f"step_{j:03d}.json", row)
            rows.append({"step":j,"sha256":digest(folder/f"step_{j:03d}.json")})
            norms.append(norm); values.append(value)
    finally:
        ctx.prec = old
    save_json(folder/"summary.json", {"method_sha256":"c"*64,"rows":rows})
    original = {"bound":ResponseBound(identity,tuple(norms),.125,.25,True,"outward"),
                "provenance":{"summary_sha256":digest(folder/"summary.json"),"method_sha256":"c"*64}}
    return original, values


def main():
    rng = np.random.default_rng(26090611)
    audits = norm_checks = exact_zero_checks = refused = pending = 0
    with tempfile.TemporaryDirectory(prefix="greencert_combined_evidence_") as temp:
        top = Path(temp)
        for n in (1,3):
            for H in (1,4,8):
                for perturbation in (0.,1e-18):
                    root = top/str(audits); root.mkdir()
                    identity = Identity("d"*64,"e"*64,"f"*64,"0"*64,n,H,"scaled_momentum_euclidean")
                    encoded = rng.normal(size=n)*1e-12
                    def kernel(j,d):
                        return [arb(j+i+1)*v for i,v in enumerate(d)]
                    construct(root/"homogeneous", encoded, kernel, horizon=H,
                        learning_rate=.003, momentum=.9,operator_sha256="a"*64,encoding_sha256="b"*64)
                    homogeneous = auth(root,identity,encoded)
                    original, values = original_fixture(root,identity,homogeneous,perturbation=perturbation)
                    t = StoredRows(root/"homogeneous/response")
                    for block in (1,2,4096):
                        profile = combine(EvidenceReader(root), "original", original_evidence=original,
                            homogeneous=homogeneous,encoding_injection_tail_upper=.0625,block_size=block)
                        assert isinstance(profile,CombinedResponseProfile) and not isinstance(profile,ResponseBound)
                        assert profile.original_first_injection_upper == .25
                        assert profile.encoding_injection_tail_upper == .0625
                        assert Q(profile.residual_upper) >= Q(.125)+Q(homogeneous.residual_upper)
                        assert profile.parameter_norms[0] == 0.
                        for j in range(H):
                            squared = sum((Q(float(a))+Q(float(b)))**2
                                          for a,b in zip(values[j][:n],t.row(j)[:n]))
                            assert squared <= Q(profile.parameter_norms[j+1])**2
                            norm_checks += 1
                            if perturbation == 0:
                                assert profile.parameter_norms[j+1] == 0.
                                exact_zero_checks += 1
                    for wrong in (replace(homogeneous,identity=replace(identity,reference_sha256="1"*64)), None):
                        try:
                            combine(EvidenceReader(root),"original",original_evidence=original,
                                    homogeneous=wrong,encoding_injection_tail_upper=.0625)
                        except IntegrityError:
                            refused += 1
                        else:
                            raise AssertionError("missing/foreign homogeneous response accepted")
                    # Prefix/missing products are pending, never a zero bound.
                    try:
                        authenticate(EvidenceReader(root), "missing", identity=identity,
                            summary_sha256="a"*64, operator_sha256="a"*64, encoding_sha256="b"*64,
                            encoded_velocity_offset=encoded, learning_rate=.003, momentum=.9)
                    except EvidencePending:
                        pending += 1
                    else:
                        raise AssertionError("missing response accepted")
                    audits += 1
        # Coherently rehash altered summaries so checksum detection alone is
        # insufficient. The semantic checks must reject the changed claim.
        source = root/"homogeneous"
        corruptions = (
            ("drop_first_error", lambda r:r.update(first_step_residual_upper=0.), "residual"),
            ("drop_total_error", lambda r:r.update(full_window_residual_upper=0.), "residual"),
            ("truncate_hvp_count", lambda r:r.update(hvp_calls=0), "HVP count"),
            ("promote_to_event", lambda r:r.update(event_certificate_issued=True), "relabeled"),
            ("incomplete_flag", lambda r:r.update(complete=False), "incomplete"),
        )
        for name, mutate, message in corruptions:
            copy = root/name; shutil.copytree(source,copy)
            record = json.loads((copy/"summary.json").read_text())
            mutate(record); rewrite(copy/"summary.json",record)
            try:
                auth(root,identity,encoded,folder=name)
            except IntegrityError as error:
                assert message in str(error), str(error)
                refused += 1
            else:
                raise AssertionError("coherently relabeled response accepted")
        copy = root/"later_injection"; shutil.copytree(source,copy)
        summary = json.loads((copy/"forcing/summary.json").read_text())
        array_path = copy/"forcing/row_001.npy"
        value = np.load(array_path,allow_pickle=False); value[0] = 1.
        with array_path.open("wb") as stream:
            np.save(stream,value,allow_pickle=False)
        summary["rows"][1]["sha256"] = digest(array_path)
        summary_sha = rewrite(copy/"forcing/summary.json",summary)
        record = json.loads((copy/"summary.json").read_text())
        record["forcing_manifest_sha256"] = summary_sha
        rewrite(copy/"summary.json",record)
        try:
            auth(root,identity,encoded,folder="later_injection")
        except IntegrityError as error:
            assert "later injection" in str(error), str(error)
            refused += 1
        else:
            raise AssertionError("nonhomogeneous forcing accepted")
        # Changing the physical encoding's sign cannot retain the same product.
        try:
            auth(root,identity,-encoded)
        except IntegrityError as error:
            assert "forcing changed" in str(error)
            refused += 1
        else:
            raise AssertionError("opposite initial response accepted")
    project = Path(__file__).resolve().parents[1]
    names = ("homogeneous_response_evidence.py","combined_anchor_response.py",
             "test_combined_anchor_evidence.py","known_anchor_green_response.py",
             "known_anchor_propagation.py","green_family_evidence.py",
             "bulk_gram_evidence.py","outward_optimizer_bulk.py","verified_artifact_io.py")
    report = {"utc":utc(),"complete_homogeneous_audits":audits,
        "exact_rational_combined_norm_checks":norm_checks,"exact_cancellation_checks":exact_zero_checks,
        "integrity_refusals":refused,"missing_product_refusals":pending,
        "sources":{name:digest(project/"scripts"/name) for name in names},
        "event_certificates_issued":0,"neural_hvps_replayed":False,
        "scope":"file-backed synthetic response fixtures; not new neural evidence"}
    output = Path("results")/("combined_anchor_evidence_regression_"+
                             report["utc"].replace(":","").replace("-","")+".json")
    sha = publish_json(project/output,report)
    print(json.dumps(report | {"output":str(output),"sha256":sha}, indent=2))


if __name__ == "__main__":
    main()
