"""Exact quadratic mixed-lineage fixtures and semantic refusal tests."""
import copy
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import tempfile
import sys
import numpy as np
from flint import arb
from checkpointed_green_products import StoredRows, product
from dgx_green_transition_pilot import ROOT, sha, save
from green_family_evidence import authenticate_green_family
from runtime_green_contract import execution_method
from runtime_green_evidence import authenticate_runtime_green_family
from test_green_family_evidence import make_fixture, read, write
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError


def fixture(root, H, n, m, power):
    def mutation(stage, value, **unused):
        if stage == "method":
            value["runtime_versions"] = {"python": "original fixture host"}
    old = make_fixture(root, H=H, n=n, probes=m, power=power, mutation=mutation)
    reference = authenticate_green_family(**old)
    origin = read(root / "green/method.json")
    source = root / "scripts/synthetic_execution.py"
    source.write_text("# Test-only exact quadratic producer identity.\n", encoding="utf-8")
    protocol = root / "RUNTIME_PROTOCOL.md"
    protocol.write_text("Synthetic cross-runtime integrity regression.\n", encoding="utf-8")
    extra = {source.name: sha(source)}
    runtime = {"python": "another fixture host", "numpy": "fixture", "torch": "fixture",
               "python_flint": "fixture", "machine": "aarch64", "platform": "linux", "accelerator": "cpu"}
    method = execution_method(origin, origin_sha256=old["method_sha256"], protocol_sha256=sha(protocol),
                              execution_sources=extra, runtime=runtime)
    emh = write(root / "remote/method.json", method)
    def kernel(j, direction):
        return [arb(j+k+1)/8 * value for k, value in enumerate(direction)]
    plans = []
    for probe in range(m):
        previous = StoredRows(root / f"green/probe_{probe}/initial")
        powers = []
        for q in range(1, power+1):
            pair = {}
            for kind in ("forward", "adjoint"):
                remote = probe == m-1 or q > 1
                relative = f"{'remote' if remote else 'green'}/probe_{probe}/power_{q:02d}/{kind}"
                if remote:
                    product(root / relative, previous, kernel, learning_rate=.003, momentum=.9,
                            transpose=kind == "adjoint", precision_bits=128,
                            contract={"method_sha256": emh, "probe": probe, "power": q})
                previous = StoredRows(root / relative)
                pair[kind] = {"folder": relative, "method": "arm" if remote else "origin"}
            powers.append(pair)
        plans.append(tuple(powers))
    args = {"origin_folder": "green", "origin_method_sha256": old["method_sha256"],
        "executions": {"arm": {"method_path": "remote/method.json", "method_sha256": emh,
            "protocol_path": "RUNTIME_PROTOCOL.md", "protocol_sha256": sha(protocol), "execution_sources": extra}},
        "sequence_plan": tuple(plans), "identity": old["identity"], "power": power,
        "original_probe_hashes": old["original_probe_hashes"], "failure_probability": .01,
        "learning_rate": .003, "momentum": .9, "forbidden_paths": ("reveal.json",)}
    return args, reference


def main():
    report = {"status": "PASS", "complete_mixed_quadratic_families": 0, "same_gain_as_original": 0,
              "plan_or_identity_refusals": 0, "coherently_rehashed_semantic_refusals": 0,
              "missing_family_pending": 0, "trained_networks": 0, "event_certificates": 0}
    with tempfile.TemporaryDirectory(prefix="greencert-runtime-family-tests-") as temporary:
        temp = Path(temporary)
        for index, case in enumerate(((1, 1, 1, 1), (2, 3, 2, 1), (3, 2, 4, 1), (4, 5, 4, 2))):
            root = temp / f"case{index}"
            args, expected = fixture(root, *case)
            value = authenticate_runtime_green_family(EvidenceReader(root), **args)
            assert value["bound"] == expected["bound"]
            assert value["provenance"]["complete_probes"] == case[2]
            assert value["provenance"]["original_records_relabelled"] is False
            report["complete_mixed_quadratic_families"] += 1
            report["same_gain_as_original"] += 1
            def refuses(changed, key="plan_or_identity_refusals", exception=IntegrityError):
                try:
                    authenticate_runtime_green_family(EvidenceReader(root), **changed)
                except exception:
                    report[key] += 1
                else:
                    raise AssertionError("incompatible evidence accepted")
            changes = []
            for key, new in (("power", 0), ("failure_probability", .02), ("learning_rate", .004),
                             ("momentum", .8), ("forbidden_paths", ()),
                             ("sequence_plan", args["sequence_plan"][:-1]),
                             ("original_probe_hashes", ("0"*64,) + args["original_probe_hashes"][1:])):
                altered = copy.deepcopy(args)
                altered[key] = new
                changes.append(altered)
            altered = copy.deepcopy(args)
            altered["identity"] = replace(args["identity"], parameters=case[1]+1)
            changes.append(altered)
            altered = copy.deepcopy(args)
            altered["sequence_plan"][-1][-1]["forward"]["method"] = "origin"
            changes.append(altered)
            altered = copy.deepcopy(args)
            altered["sequence_plan"][-1][-1]["adjoint"] = altered["sequence_plan"][-1][-1]["forward"].copy()
            changes.append(altered)
            altered = copy.deepcopy(args)
            altered["sequence_plan"][-1][-1]["forward"]["method"] = "unregistered"
            changes.append(altered)
            for altered in changes:
                refuses(altered)
            pending = copy.deepcopy(args)
            pending["sequence_plan"][-1][-1]["adjoint"]["folder"] = "not-yet-computed"
            refuses(pending, "missing_family_pending", EvidencePending)
            # Method byte hashes are updated coherently. Rejection must come
            # from mathematical/runtime identity, not an old manifest hash.
            path = root / "remote/method.json"
            original_method = read(path)
            for key, new in (("learning_rate", .004), ("delta", .02), ("parameters", case[1]+1)):
                changed = copy.deepcopy(original_method)
                changed[key] = new
                altered = copy.deepcopy(args)
                altered["executions"]["arm"]["method_sha256"] = write(path, changed)
                refuses(altered, "coherently_rehashed_semantic_refusals")
                assert write(path, original_method) == args["executions"]["arm"]["method_sha256"]
            # The final summary is read by its actual hash, not a saved
            # top-level gain record. An understated aggregate must still fail.
            last = root / args["sequence_plan"][-1][-1]["adjoint"]["folder"]
            summary = read(last / "summary.json")
            changed = copy.deepcopy(summary)
            changed["terminal_sequence_norm_upper"] = 0.
            write(last / "summary.json", changed)
            refuses(args, "coherently_rehashed_semantic_refusals")
            write(last / "summary.json", summary)
            if case[0] > 1:
                record = read(last / "row_000.json")
                changed_record = copy.deepcopy(record)
                changed_record["hvp_step"] = 999
                write(last / "row_000.json", changed_record)
                changed = copy.deepcopy(summary)
                changed["rows"][0] = changed_record
                write(last / "summary.json", changed)
                refuses(args, "coherently_rehashed_semantic_refusals")
                write(last / "row_000.json", record)
                write(last / "summary.json", summary)
            assert authenticate_runtime_green_family(EvidenceReader(root), **args)["bound"] == expected["bound"]
    report["sources"] = {"scripts/"+name: sha(ROOT/"scripts"/name) for name in
        ("runtime_green_contract.py", "runtime_green_evidence.py", "test_runtime_green_evidence.py",
         "green_family_evidence.py", "test_green_family_evidence.py", "checkpointed_green_products.py")}
    if len(sys.argv) > 1:
        save(ROOT / Path(sys.argv[1]), report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
