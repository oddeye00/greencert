"""Complete-family optimizer-bulk Gram audit, with bounded-memory row streams.

This returns a distinct S=K* K-K0* K0 projection bound, not the original
GreenBound type. It never issues an event or opens a future trajectory.
"""
from contextlib import ExitStack
from dataclasses import asdict
from fractions import Fraction
import hashlib
import math
import os
from pathlib import Path

import numpy as np
from green_family_evidence import authenticate_green_family, require, number
from optimizer_bulk_green import bulk_gain_upper,bulk_gram_operator_upper
from outward_inexact_anytime_gram import folded_normal_calibration_lower
from outward_optimizer_bulk import (ieee_preflight,optimizer_matrix,gram_difference_bound,
                                    combine_squared_bounds,fraction_interval)
from verified_artifact_io import EvidencePending,IntegrityError,require_sha256

PROJECTION_SCOPE="ideal_gaussian_projection_for_fixed_gram_difference_S"


class DyadicRowStream:
    """Hold a hash-checked NPY row open; read only requested coordinate blocks.

    Both the same open stream and its pathname are rehashed on normal exit.
    Completed producer rows are assumed immutable during this audit. This is
    cooperative artifact verification, not a malicious-filesystem sandbox.
    """
    def __init__(self,reader,relative,sha,parameters):
        require(type(parameters) is int and parameters > 0,"invalid row parameter count")
        self.reader,self.relative,self.sha,self.n=reader,relative,require_sha256(sha),parameters
        self.path=reader.resolve(relative)
        self.stream=None

    def _hash(self):
        self.stream.seek(0)
        value=hashlib.file_digest(self.stream,"sha256").hexdigest()
        self.reader._remember(self.path,value,self.sha)

    def __enter__(self):
        try:
            self.stream=self.path.open("rb")
        except FileNotFoundError:
            raise EvidencePending(f"missing completed row: {self.relative}") from None
        try:
            size=os.fstat(self.stream.fileno()).st_size
            require(16*self.n <= size <= 16*self.n+10032,"invalid complete row size")
            self._hash()
            self.stream.seek(0)
            version=np.lib.format.read_magic(self.stream)
            require(version in ((1,0),(2,0)),"unsupported streamed NPY version")
            parser=np.lib.format.read_array_header_1_0 if version == (1,0) else np.lib.format.read_array_header_2_0
            shape,fortran,dtype=parser(self.stream,max_header_size=10000)
            require(shape == (2*self.n,) and fortran is False and dtype == np.float64,
                    "streamed row shape/dtype/order mismatch")
            self.offset=self.stream.tell()
            require(size == self.offset+16*self.n,"streamed row payload size mismatch")
            return self
        except BaseException:
            self.stream.close()
            raise

    def block(self,start,stop):
        require(type(start) is int and type(stop) is int and 0 <= start < stop <= self.n,
                "invalid parameter block")
        pieces=[]
        for offset in (start,self.n+start):
            self.stream.seek(self.offset+8*offset)
            payload=self.stream.read(8*(stop-start))
            require(len(payload) == 8*(stop-start),"truncated coordinate block")
            piece=np.frombuffer(payload,dtype=np.float64)
            require(np.isfinite(piece).all(),"nonfinite coordinate block")
            pieces.append(piece)
        return np.concatenate(pieces)

    def __exit__(self,kind,value,traceback):
        try:
            if kind is None:
                self._hash()
                self.reader.check_blob(self.relative,self.sha)
        finally:
            self.stream.close()


def union_budget(original_delta,bulk_delta):
    a=number(original_delta,"original failure probability",positive=True)
    b=number(bulk_delta,"bulk failure probability",positive=True)
    require(a < 1 and b < 1,"invalid projection probability")
    total=Fraction(a)+Fraction(b)
    require(total < 1,"noninformative simultaneous probability budget")
    return fraction_interval(total)[1]


def audit_bulk_gram_family(reader,folder,*,identity,method_sha256,original_probe_hashes,
                          failure_probability,bulk_failure_probability,learning_rate,momentum,
                          weight_decay,block_size=4096,forbidden_outcome_files,progress=None):
    """Authenticate q1 in full, then enclose V using all original images.

    `weight_decay` and the probability allocation must be caller-frozen before
    interpreting this audit. No per-probe comparator fit or probe selection is
    performed here. Missing family evidence raises EvidencePending, not a
    numerical abstention or a partial-family norm estimate.
    """
    require(type(block_size) is int and 1 <= block_size <= 16384,"invalid bounded coordinate block size")
    require(isinstance(forbidden_outcome_files,tuple) and forbidden_outcome_files,"outcome barrier required")
    def barrier():
        require(all(not reader.resolve(path).exists() for path in forbidden_outcome_files),"outcome barrier open")
    barrier()
    total_delta=union_budget(failure_probability,bulk_failure_probability)
    constants=dict(learning_rate=learning_rate,momentum=momentum,weight_decay=weight_decay)
    matrix=optimizer_matrix(**constants)
    preflight=ieee_preflight()
    authenticated=authenticate_green_family(reader,folder,identity=identity,power=1,
        method_sha256=method_sha256,original_probe_hashes=original_probe_hashes,
        failure_probability=failure_probability,learning_rate=learning_rate,momentum=momentum)
    family,fsha=reader.read_json(Path(folder)/"power_01.json",authenticated["provenance"]["result_sha256"])
    H,n,m=identity.horizon,identity.parameters,len(original_probe_hashes)
    require(authenticated["provenance"]["complete_probes"] == m and
            authenticated["provenance"]["array_norms_replayed"] is True,"family verification scope changed")
    D,E=family["forward_residuals"][0],family["adjoint_residuals"][0]
    require(number(D,"forward residual") == D and number(E,"adjoint residual") == E,"invalid full-family residuals")
    probe_rows=[]
    for probe in range(m):
        barrier()
        base=Path(folder)/f"probe_{probe}"
        initial,ish=reader.read_json(base/"initial/summary.json")
        adjoint,asha=reader.read_json(base/"power_01/adjoint/summary.json",
            family["product_manifest_sha256"][probe][0]["adjoint_manifest_sha256"])
        # The full verifier above establishes these manifests and all temporal
        # links. EvidenceReader also refuses a changed manifest in this run.
        require(initial["flat_npy_sha256"] == original_probe_hashes[probe] and
                len(initial["rows"]) == len(adjoint["rows"]) == H,"incomplete/substituted image population")
        block_rows=[]
        with ExitStack() as stack:
            originals=[stack.enter_context(DyadicRowStream(reader,base/"initial"/row["file"],row["sha256"],n))
                       for row in initial["rows"]]
            images=[stack.enter_context(DyadicRowStream(reader,base/"power_01/adjoint"/row["file"],row["sha256"],n))
                    for row in adjoint["rows"]]
            completed=0
            for start in range(0,n,block_size):
                stop=min(start+block_size,n)
                g=np.stack([row.block(start,stop) for row in originals])
                w=np.stack([row.block(start,stop) for row in images])
                square=gram_difference_bound(g,w,matrix=matrix)
                block_rows.append({"parameter_start":start,"parameter_stop":stop,"squared_norm_upper":square})
                completed+=stop-start
                if progress: progress({"probe":probe,"parameters_complete":completed,"parameters":n})
                barrier()
            require(completed == n,"coordinate population incomplete")
        V=combine_squared_bounds([v["squared_norm_upper"] for v in block_rows])
        probe_rows.append({"probe":probe,"original_probe_sha256":original_probe_hashes[probe],
            "initial_manifest_sha256":ish,"adjoint_manifest_sha256":asha,
            "parameters":n,"horizon":H,"V_upper":V,"blocks":block_rows})
    require(len(probe_rows) == m,"probe population incomplete")
    terminal=max(row["V_upper"] for row in probe_rows)
    b=bulk_gain_upper(H,**constants)["operator_upper"]
    c=folded_normal_calibration_lower(delta=bulk_failure_probability,probes=m)
    root=bulk_gram_operator_upper(bulk_gain_upper=b,terminal_upper=terminal,calibration_lower=c,
        forward_residual_upper=D,adjoint_residual_upper=E)
    if root["enclosed"]:
        require(root["operator_upper"] >= 1,"bulk root contradicts identity diagonal")
    # Do not publish from a source or data snapshot that changed mid-audit.
    for path,sha in tuple(reader.observed.items()): reader.check_blob(path,sha)
    barrier()
    return {"schema":"optimizer_bulk_gram_family_v1","identity":asdict(identity),
        "green_method_sha256":method_sha256,"complete_family_sha256":fsha,
        "arithmetic_preflight":preflight,"optimizer_constants":constants,
        "original_probe_hashes":list(original_probe_hashes),"complete_probes":m,
        "block_size":block_size,"probe_rows":probe_rows,"bulk_gain_upper":b,
        "V_upper":terminal,"forward_residual_upper":D,"adjoint_residual_upper":E,
        "calibration_lower":c,"bulk_green_norm":root,
        "ordinary_green_norm":None if authenticated["bound"] is None else authenticated["bound"].gain_upper,
        "bulk_projection_scope":PROJECTION_SCOPE,"bulk_failure_probability":bulk_failure_probability,
        "original_failure_probability":failure_probability,"simultaneous_failure_probability_upper":total_delta,
        "original_projection_event_reused_for_S":False,
        "accepted_by_frozen_original_event_gate":False,"event_certificate_issued":False,
        "future_outcome_access":False,"new_neural_products":0,"neural_hvps_replayed":False,
        "scope":"outward optimizer subtraction and scalar root; authenticated neural residuals remain validated-producer premises"}
