"""Read-only sequence replay with an exact-integer norm inequality.

Metadata/recurrence checks follow green_family_evidence.authenticate_sequence.
The numerical check proves the saved upper-bound inequality directly; it
does not require reproducing an Arb reduction's particular rounded output.
Frozen producer and reference-auditor source files are not modified.
"""
import hashlib
import io
from pathlib import Path

import numpy as np

from exact_dyadic_norm import squared_integer, encloses_norm
from green_family_evidence import SequenceEvidence, checked_array, number, require
from outward_green_products import sequence_upper

def authenticate_sequence(reader, folder, *, expected_sha, shape, kind, contract,
                          inputs=None, initial_hash=None, precision_bits=128,
                          learning_rate=.003, momentum=.9):
    folder = Path(folder)
    summary, summary_sha = reader.read_json(folder / "summary.json", expected_sha)
    method, method_sha = reader.read_json(folder / "method.json", summary["method_sha256"])
    H, d = shape
    require(type(H) is int and H > 0 and type(d) is int and d > 0 and d % 2 == 0, "invalid sequence shape")
    require(kind in ("input_rows", "forward", "adjoint"), "unknown sequence kind")
    require(summary["complete"] is True and summary["kind"] == method["kind"] == kind,
            "incomplete or substituted sequence")
    require(summary["shape"] == method["shape"] == [H, d], "sequence shape mismatch")
    require(all(type(x) is int for x in summary["shape"] + method["shape"]), "noninteger sequence shape")
    require(method["contract"] == contract, "sequence operator/probe/power contract mismatch")
    rows = summary["rows"]
    require(isinstance(rows, list) and len(rows) == H, "incomplete row population")
    if kind == "input_rows":
        require(inputs is None and initial_hash is not None, "missing original-probe policy")
        require(method["expected_flat_npy_sha256"] == summary["flat_npy_sha256"] == initial_hash,
                "substituted original probe")
        header = io.BytesIO()
        np.lib.format.write_array_header_1_0(header, {
            "descr": np.dtype(np.float64).str, "fortran_order": False, "shape": (H*d,)})
        flat_hash = hashlib.sha256(header.getvalue())
    else:
        require(isinstance(inputs, SequenceEvidence), "missing prior sequence evidence")
        require(method["input_manifest_sha256"] == summary["input_manifest_sha256"] == inputs.summary_sha256,
                "product not linked to its actual input manifest")
        require(type(method["precision_bits"]) is int and method["precision_bits"] == precision_bits,
                "product arithmetic differs from frozen method")
        require(number(method["learning_rate"], "learning rate", positive=True) == learning_rate and
                number(method["momentum"], "momentum") == momentum, "product optimizer mismatch")
        require(type(summary["hvp_calls"]) is int and summary["hvp_calls"] == H-1, "incomplete HVP population")
    order = range(H-1, -1, -1) if kind == "adjoint" else range(H)
    parent = None
    for j in order:
        row = rows[j]
        require(type(row["index"]) is int and row["index"] == j and row["file"] == f"row_{j:03d}.npy",
                "noncanonical or duplicate sequence row")
        if kind != "input_rows":
            record, record_sha = reader.read_json(folder / f"row_{j:03d}.json")
            require(record == row and record["method_sha256"] == method_sha and
                    record["parent_record_sha256"] == parent, "broken recurrence record chain")
            require(record["input_row_sha256"] == inputs.summary["rows"][j]["sha256"], "row input substitution")
            step = None if parent is None else j+1 if kind == "adjoint" else j
            correct_step = (record["hvp_step"] is None if step is None else
                            type(record["hvp_step"]) is int and record["hvp_step"] == step)
            require(correct_step, "incorrect causal HVP index")
            residual = number(record["local_residual_norm_upper"], "local residual")
            if parent is None:
                require(residual == 0 and record["sha256"] == inputs.summary["rows"][j]["sha256"],
                        "endpoint is not an exact input copy")
            parent = record_sha
        norm = number(row["norm_upper"], "row norm")
        value = checked_array(reader, folder / row["file"], row["sha256"], d)
        # The producer computes every row norm at max(256, product precision).
        require(encloses_norm(squared_integer(value), norm), "saved norm fails exact dyadic inequality")
        if kind == "input_rows":
            flat_hash.update(value.tobytes())
    norm = sequence_upper([number(row["norm_upper"], "row norm") for row in rows])
    require(number(summary["terminal_sequence_norm_upper"], "sequence norm") == norm,
            "sequence norm aggregate mismatch")
    if kind == "input_rows":
        require(flat_hash.hexdigest() == initial_hash, "original Gaussian vector identity mismatch")
    else:
        residual = sequence_upper([number(row["local_residual_norm_upper"], "local residual") for row in rows])
        require(number(summary["residual_sequence_upper"], "sequence residual") == residual,
                "sequence residual aggregate mismatch")
    return SequenceEvidence(folder, summary_sha, summary, method)
