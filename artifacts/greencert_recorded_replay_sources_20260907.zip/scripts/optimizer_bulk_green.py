"""Known optimizer bulk subtraction for a first-power Green audit.

The float64 products are DIAGNOSTICS, not enclosures. The scalar solver is
outward, conditional on a verified bulk gain, residual/image bounds, and the
Gaussian projection event for S=K.T K-B.T B. That is not the original event
for K.T K; using both requires explicit probability accounting.
"""
import math
import numpy as np
from flint import arb, ctx
from outward_inexact_anytime_gram import exact_arb


def bulk_product(injections, *, learning_rate, momentum, weight_decay, transpose=False):
    """Floating-point action of the parameter-isotropic momentum Green map.

    Inputs may contain a coordinate block, since the bulk does not mix
    parameter coordinates. Layout is (time, theta-block then scaled-velocity).
    No neural product is evaluated and no dense (H*d)-square map is formed.
    """
    values = np.asarray(injections)
    if values.dtype != np.float64 or values.ndim != 2 or min(values.shape) < 1 or values.shape[1] % 2:
        raise ValueError("finite H by even-dimension float64 input required")
    if not np.isfinite(values).all():
        raise ValueError("nonfinite bulk input")
    eta, mu, lam = map(float, (learning_rate, momentum, weight_decay))
    if not all(math.isfinite(v) for v in (eta, mu, lam)) or eta <= 0 or mu < 0 or lam < 0:
        raise ValueError("invalid optimizer constants")
    H, d = values.shape
    n = d//2
    answer = np.empty_like(values)
    state = np.zeros(d, dtype=np.float64)
    for j in (range(H-1, -1, -1) if transpose else range(H)):
        if transpose:
            difference = state[n:] - state[:n]
            top = state[:n] + eta*lam*difference
            bottom = mu*difference
        else:
            bottom = eta*lam*state[:n] + mu*state[n:]
            top = state[:n] - bottom
        state = np.concatenate((top, bottom)) + values[j]
        answer[j] = state
    if not np.isfinite(answer).all():
        raise OverflowError("bulk product overflow")
    return answer


def bulk_time_matrix(horizon, *, learning_rate, momentum, weight_decay):
    """Small float64 2H-square diagnostic; never a verified spectral bound."""
    if type(horizon) is not int or horizon < 1:
        raise ValueError("positive horizon required")
    basis = np.eye(2*horizon)
    return np.column_stack([bulk_product(basis[:, i].reshape(horizon, 2), learning_rate=learning_rate,
        momentum=momentum, weight_decay=weight_decay).reshape(-1) for i in range(2*horizon)])


def bulk_gain_upper(horizon, *, learning_rate, momentum, weight_decay, precision_bits=256):
    """Outward ||K0|| <= sqrt(||K0||_1 ||K0||_infinity), in O(H) scalars.

    Each block is J0**r tensor I_n, so the estimate covers every parameter
    coordinate without constructing a state- or time-dense matrix. Absolute
    row/column sums are maximal at the full temporal prefix.
    """
    if type(horizon) is not int or horizon < 1 or type(precision_bits) is not int or precision_bits < 64:
        raise ValueError("positive horizon and at least 64 bits required")
    for value in (learning_rate, momentum, weight_decay):
        if type(value) not in (int,float) or not math.isfinite(value) or value < 0:
            raise ValueError("invalid optimizer bulk constant")
    if learning_rate == 0:
        raise ValueError("positive learning rate required")
    old=ctx.prec
    ctx.prec=precision_bits
    try:
        a=exact_arb(learning_rate)*exact_arb(weight_decay)
        mu=exact_arb(momentum)
        J=((1-a,-mu),(a,mu))
        P=((arb(1),arb(0)),(arb(0),arb(1)))
        rows=[arb(0),arb(0)]
        columns=[arb(0),arb(0)]
        for r in range(horizon):
            for i in range(2):
                for j in range(2):
                    value=abs(P[i][j])
                    rows[i]+=value
                    columns[j]+=value
            if r+1<horizon:
                P=tuple(tuple(sum((J[i][k]*P[k][j] for k in range(2)),arb(0)) for j in range(2)) for i in range(2))
        upper=math.nextafter(max(float((row*col).sqrt().upper()) for row in rows for col in columns),math.inf)
        if not math.isfinite(upper):
            raise OverflowError("no finite optimizer-bulk norm enclosure")
        return {"operator_upper":upper,"horizon":horizon,"precision_bits":precision_bits,
                "arithmetic":"outward","parameter_dimension_independent":True}
    finally:
        ctx.prec=old


def bulk_gram_slack(kappa, *, bulk_gain_upper, terminal_upper, calibration_lower,
                     forward_residual_upper, adjoint_residual_upper):
    k, b, y, c, d, e = map(exact_arb, (kappa, bulk_gain_upper, terminal_upper,
        calibration_lower, forward_residual_upper, adjoint_residual_upper))
    return (c-d)*k*k - e*k - (y+c*b*b)


def bulk_gram_operator_upper(*, bulk_gain_upper, terminal_upper, calibration_lower,
                              forward_residual_upper, adjoint_residual_upper, precision_bits=256):
    """Outward root of (c-D) k^2-E k-(V+c b^2) >= 0.

    V must enclose max_i ||w_i-B.T B g_i||, including the arithmetic used
    for the bulk subtraction. D,E are full-family local recurrence bounds
    for the original forward/adjoint K products, not accumulated errors
    obtained by multiplying an unverified estimate of ||K||.
    """
    kwargs = dict(bulk_gain_upper=bulk_gain_upper, terminal_upper=terminal_upper,
        calibration_lower=calibration_lower, forward_residual_upper=forward_residual_upper,
        adjoint_residual_upper=adjoint_residual_upper)
    for key, value in kwargs.items():
        if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
            raise ValueError(f"invalid {key}")
    if calibration_lower <= 0 or type(precision_bits) is not int or precision_bits < 64:
        raise ValueError("positive calibration and at least 64 bits required")
    if forward_residual_upper >= calibration_lower:
        return {"enclosed": False, "reason": "forward_residual_exhausts_bulk_projection_calibration"}
    old = ctx.prec
    ctx.prec = precision_bits
    try:
        b, y, c, d, e = (exact_arb(kwargs[key]) for key in
            ("bulk_gain_upper", "terminal_upper", "calibration_lower", "forward_residual_upper", "adjoint_residual_upper"))
        gap = c-d
        root = (e+(e*e+4*gap*(y+c*b*b)).sqrt())/(2*gap)
        upper = math.nextafter(float(root.upper()), math.inf)
        if not math.isfinite(upper):
            raise OverflowError("no finite representable bulk supersolution")
        while not bool(bulk_gram_slack(upper, **kwargs) >= 0):
            upper = math.nextafter(upper, math.inf)
            if not math.isfinite(upper):
                raise OverflowError("bulk supersolution overflow")
        return {"enclosed": True, "operator_upper": upper,
                "supersolution_slack": str(bulk_gram_slack(upper, **kwargs)),
                "conditional_on_verified_inputs_and_bulk_projection_event": True}
    finally:
        ctx.prec = old
