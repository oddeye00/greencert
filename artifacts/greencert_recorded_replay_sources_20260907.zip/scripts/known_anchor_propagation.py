"""Verified initial and homogeneous steps for a known velocity-only offset."""
from fractions import Fraction
import math
import numpy as np

from known_anchor_response import rational_norm_upper,require
from outward_green_momentum import rounded_recurrence_step
from outward_optimizer_bulk import difference_interval,squared_norm_upper,combine_squared_bounds


def first_homogeneous_step(encoded_velocity_offset,*,momentum):
    """T1=(-mu*dbar,+mu*dbar), with exact-rational arithmetic residual.

    The parameter direction at T0=(0,dbar) is exactly zero, so no HVP is
    needed. This does not assert dbar equals the physical anchor offset;
    any initial encoding tail remains a separate obligation.
    """
    d=encoded_velocity_offset
    require(isinstance(d,np.ndarray) and d.dtype==np.float64 and d.ndim==1 and len(d)>0 and
            np.isfinite(d).all(),"finite binary64 encoded velocity offset required")
    require(type(momentum) in (int,float) and math.isfinite(momentum) and momentum>=0,"invalid momentum")
    with np.errstate(over="ignore",invalid="ignore",under="ignore"):
        rounded=momentum*d
    require(np.isfinite(rounded).all(),"first homogeneous state overflow")
    mu=Fraction(momentum)
    residual_square=point_square=Fraction(0)
    nonzero=0
    for initial,stored in zip(d,rounded):
        value=Fraction(float(stored))
        error=mu*Fraction(float(initial))-value
        residual_square+=error*error
        point_square+=value*value
        nonzero+=int(error!=0)
    return {"next_state":np.concatenate((-rounded,rounded)),
            "local_residual_norm_upper":rational_norm_upper(2*residual_square),
            "parameter_response_norm_upper":rational_norm_upper(point_square),
            "full_response_norm_upper":rational_norm_upper(2*point_square),
            "nonzero_multiplication_residual_coordinates":nonzero,"neural_hvp_calls":0}


def homogeneous_step(state,hvp,*,learning_rate,momentum):
    """Later J_j*T_j steps require a verified HVP at the original center."""
    return rounded_recurrence_step(state,np.zeros_like(state),hvp,
                                   learning_rate=learning_rate,momentum=momentum)


def combined_parameter_norm(original_parameter_response,anchor_parameter_response):
    """Enclose the exact dyadic sum, without rounding it to a new center."""
    a,b=original_parameter_response,anchor_parameter_response
    require(isinstance(a,np.ndarray) and isinstance(b,np.ndarray) and a.dtype==b.dtype==np.float64 and
            a.ndim==b.ndim==1 and a.shape==b.shape and len(a)>0 and np.isfinite(a).all() and np.isfinite(b).all(),
            "aligned finite parameter responses required")
    if np.array_equal(a,-b):
        return 0.0
    intervals=difference_interval(a,(-b,-b))
    return combine_squared_bounds([squared_norm_upper(intervals)])
