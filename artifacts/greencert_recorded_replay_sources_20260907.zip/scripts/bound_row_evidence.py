"""Authenticate complete generated derivative rows for window assembly.

This rechecks source/input linkage, populations, complete coverage and scalar
aggregates. The neural enclosures remain claims of the registered validated
producer; independent neural replay is a separate, explicitly stated task.
"""
from pathlib import Path
import math

from flint import arb, ctx
from verified_artifact_io import IntegrityError
from window_event_assembly import DriftRow, MarginBound, OutputRow

COMMON = frozenset({"arb_deep_point_gram.py", "arb_deep_point_gram_structured.py", "arb_deep_envelope.py",
                   "arb_matrix_bounds.py", "arb_transformer_objective.py", "transformer_hvp_grokking.py",
                   "build_larger_candidate_reference.py"})
PRODUCERS = {
    "original": (COMMON | {"audit_candidate_outward_bound_row.py"},
                 "LARGER_CANDIDATE_OUTWARD_BOUND_ROW_PROTOCOL.md"),
    "moment_points_native_local": (COMMON | {"audit_candidate_outward_moment_row.py",
        "arb_deep_point_gram_bound_strategy.py", "arb_native_row_bounds.py", "arb_psd_moment_bounds.py",
        "test_arb_gram_bound_strategy.py", "test_arb_native_row_bounds.py", "test_arb_psd_moment_bounds.py",
        "audit_psd_strategy_records.py"}, "LARGER_CANDIDATE_OUTWARD_MOMENT_ROW_PROTOCOL.md"),
}


def require(condition, message):
    if not condition:
        raise IntegrityError(message)


def number(value, name, nonnegative=True):
    require(type(value) in (float, int), f"invalid {name}")
    require(math.isfinite(value) and (not nonnegative or value >= 0), f"invalid {name}")
    return float(value)


def _authenticate_bound_row(reader, folder, *, identity, step, domain, producer,
                            training_examples, evaluation_examples, example_ids):
    """Examples are caller-bound dictionaries containing pair and label.

    Producer selection is a caller policy, never selected by an artifact.
    Returns typed scalar inputs plus provenance; no certificate is issued.
    """
    require(producer in PRODUCERS, "unregistered derivative producer")
    require(type(step) is int and 1 <= step <= identity.horizon, "invalid derivative/output step")
    require(len(evaluation_examples) == len(example_ids) > 0 and len(set(example_ids)) == len(example_ids),
            "invalid fixed evaluation population")
    folder = Path(folder)
    summary, summary_sha = reader.read_json(folder / "summary.json", allow_in_progress=True)
    method, method_sha = reader.read_json(folder / "method.json", summary["method_sha256"])
    required_sources, protocol = PRODUCERS[producer]
    reader.check_sources(method, required_names=required_sources)
    reader.check_blob(protocol, method["protocol_sha256"])
    require(method["candidate_sha256"] == identity.candidate_sha256 and method["path_sha256"] == identity.reference_sha256,
            "foreign candidate/reference derivative row")
    require(method["parameters"] == identity.parameters and method["step"] == step and summary["step"] == step,
            "wrong derivative-row dimension/index")
    require(method["future_outcome_access"] is False and summary["future_outcome_access"] is False,
            "outcome access incompatible with sealed construction")
    radius = number(method["radius"], "proof domain")
    require(radius >= domain and summary["radius"] == radius, "insufficient or inconsistent proof domain")
    require(method["transport_precision_bits"] == 192 and method["geometry_precision_ladder"] == [64, 96, 192],
            "unregistered derivative arithmetic policy")
    if producer == "moment_points_native_local":
        require(method["point_norm_rule"] == "outward trace/Frobenius/mean-variance minimum" and
                method["local_norm_rule"] == "outward native absolute-row reduction", "norm-policy mismatch")
    expected_training = len(training_examples) if step < identity.horizon else 0
    expected_cert = len(evaluation_examples)
    require(expected_training > 0 or step == identity.horizon, "empty training population")
    require(method["training_examples"] == summary["training_examples"] == expected_training and
            method["certification_examples"] == summary["certification_examples"] == expected_cert,
            "wrong training/evaluation denominator")
    require(summary["all_examples_verified"] is True and summary["unresolved_examples"] == [], "unresolved complete row")
    entries = summary["rows"]
    require(isinstance(entries, list) and len(entries) == expected_training + expected_cert, "incomplete row manifest")
    by_index = {}
    for entry in entries:
        require(entry["split"] in ("training", "certification") and type(entry["index"]) is int, "invalid row role/index")
        key = entry["split"], entry["index"]
        require(key not in by_index, "duplicate row role/index")
        by_index[key] = entry
    expected_keys = {("training", j) for j in range(expected_training)} | {("certification", j) for j in range(expected_cert)}
    require(set(by_index) == expected_keys, "missing/out-of-range row role/index")
    drift_values, outputs, authenticated_weights, record_hashes = [], [], {}, {}
    for split, population, count in (("training", training_examples, expected_training),
                                      ("certification", evaluation_examples, expected_cert)):
        for index in range(count):
            entry = by_index[split, index]
            path = folder / f"{split}_{index:03d}.json"
            require(reader.resolve(entry["record_path"]) == reader.resolve(path), "noncanonical example record link")
            row, row_sha = reader.read_json(path, entry["sha256"])
            record_hashes[str(path)] = row_sha
            require(entry["status"] == row["status"] == "verified", "unverified example")
            require(row["method_sha256"] == method_sha and row["step"] == step and
                    row["split"] == split and row["index"] == index, "example provenance mismatch")
            require(row["pair"] == population[index]["pair"] and row["label"] == population[index]["label"],
                    "changed example or label")
            bits = row["geometry_bits"]
            require(type(bits) is int and bits in method["geometry_precision_ladder"] and row["transport_bits"] == 192,
                    "example arithmetic policy mismatch")
            if bits not in authenticated_weights:
                weight_path = folder / f"weights_{bits}.json"
                weights, weights_sha = reader.read_json(weight_path)
                require(weights["method_sha256"] == method_sha and weights["geometry_bits"] == bits,
                        "foreign weight-bound cache")
                require(isinstance(weights["weights"], dict) and weights["weights"], "missing weight-bound cache")
                for value in weights["weights"].values():
                    require(value["uses_verified_reconstruction_residual"] is True, "unverified weight factorization")
                    for field in ("upper", "svd_residual_frobenius_upper", "left_factor_norm_upper", "right_factor_norm_upper"):
                        number(value[field], "weight " + field)
                authenticated_weights[bits] = {"path": str(weight_path), "sha256": weights_sha}
            jet = row["logit_jet"]
            for key in ("first", "second", "third", "distance", "value"):
                number(jet[key], "logit " + key)
            lower = number(row["center_margin_lower"], "margin lower", False)
            upper = number(row["center_margin_upper"], "margin upper", False)
            require(lower <= upper, "reversed output margin enclosure")
            if split == "training":
                drift_values.append(number(row["scaled_momentum_drift_upper"], "per-example drift"))
            else:
                require(row["scaled_momentum_drift_upper"] is None, "certification example included in training mean")
                point_gain = number(row["point_gains"]["logits"], "point logit Jacobian")
                outputs.append(MarginBound(example_ids[index], lower, upper, point_gain, number(jet["second"], "output Hessian")))
    require(len(summary["output_bounds"]) == expected_cert, "incomplete summary output rows")
    # The summary must reproduce its example rows, not introduce new outputs.
    for index, bound in enumerate(summary["output_bounds"]):
        example, _ = reader.read_json(folder / f"certification_{index:03d}.json", by_index["certification", index]["sha256"])
        require(bound == {key: example[key] for key in ("index", "label", "logit_jet", "center_margin_lower", "center_margin_upper")},
                "summary output differs from example record")
    drift = None
    if expected_training:
        mean = number(summary["mean_training_drift_upper"], "empirical mean bound")
        prior = ctx.prec
        ctx.prec = 256
        try:
            exact_sum = sum((arb(value) for value in drift_values), arb(0)) / expected_training
            require(bool(arb(mean) >= exact_sum), "understated empirical mean bound")
        finally:
            ctx.prec = prior
        drift = DriftRow(identity, step, radius, expected_training, mean, "outward")
    else:
        require(summary["mean_training_drift_upper"] is None, "unexpected endpoint training mean")
    return {"drift": drift, "output": OutputRow(identity, step, radius, tuple(outputs), "outward"),
            "provenance": {"summary_sha256": summary_sha, "method_sha256": method_sha, "producer": producer,
                "weight_records": authenticated_weights, "example_records": record_hashes,
                "neural_arithmetic_replayed": False, "empirical_mean_rechecked_outward": expected_training > 0}}


def authenticate_bound_row(reader, folder, *, identity, step, domain, producer,
                           training_examples, evaluation_examples, example_ids):
    """Reject malformed completed artifacts; preserve explicit pending state."""
    try:
        return _authenticate_bound_row(reader, folder, identity=identity, step=step, domain=domain,
            producer=producer, training_examples=training_examples, evaluation_examples=evaluation_examples,
            example_ids=example_ids)
    except (KeyError, TypeError, IndexError) as error:
        raise IntegrityError("malformed completed derivative evidence") from error
