"""Neural Green residual audit against separate high-precision HVP calls."""
import json
import time
import numpy as np
import torch
from flint import arb,ctx
from arb_enclosed_direction_hvp import chunked_enclosed_direction_hvp
from arb_reverse_transformer import arb_objective_gradient_hvp
from outward_green_products import forward,adjoint
from outward_green_momentum import momentum_image
from transformer_hvp_grokking import TransformerConfig,make_template,flat_spec,flatten_parameters


def squared_norm(values):
    return sum((abs(v).upper()**2 for v in values),arb(0))


def main():
    old=ctx.prec;torch.set_num_threads(1);started=time.perf_counter();rows=[];checks=0
    try:
        for depth in (1,2,4):
            for norm in ("none","layernorm"):
                cfg=TransformerConfig(modulus=3,model_dim=4,hidden_dim=8,heads=1,depth=depth,
                    normalization=norm,seed=440+depth,learning_rate=.003,momentum=.9,weight_decay=.01)
                model=make_template(cfg);spec=flat_spec(model);p=flatten_parameters(model).numpy();n=len(p)
                eps=[(b.norm1.eps,b.norm2.eps) for b in model.blocks] if norm=="layernorm" else []
                rng=np.random.default_rng(560+depth);path=np.stack([p+j*1e-4*rng.normal(size=n)/n**.5 for j in range(3)])
                pairs=np.array([[0,0],[1,2],[2,0]]);labels=pairs.sum(1)%cfg.modulus
                injection=rng.normal(size=(3,2*n))
                def kernel(j,direction):
                    return chunked_enclosed_direction_hvp(path[j],pairs,labels,spec,cfg,
                        normalization_eps=eps,direction=direction,chunk_size=2)
                f=forward(injection,kernel,learning_rate=.003,momentum=.9,precision_bits=128)
                t=adjoint(f["states"],kernel,learning_rate=.003,momentum=.9,precision_bits=128)
                ctx.prec=256;fsquare=arb(0);tsquare=arb(0)
                assert np.array_equal(f["states"][0],injection[0])
                assert np.array_equal(t["states"][-1],f["states"][-1])
                for j in (1,2):
                    state=f["states"][j-1]
                    h=arb_objective_gradient_hvp(path[j],pairs,labels,spec,cfg,normalization_eps=eps,direction=state[:n])["hvp"]
                    predicted=momentum_image(state,h,learning_rate=.003,momentum=.9)
                    residual=[arb(float(z))-v-arb(float(u)) for z,v,u in zip(f["states"][j],predicted,injection[j])]
                    radius=squared_norm(residual).sqrt()
                    assert bool(arb(f["local_residuals"][j])>=radius)
                    fsquare+=squared_norm(residual);checks+=len(residual)
                for j in (0,1):
                    state=t["states"][j+1]
                    # H(b-a) is independently formed as H b - H a, not by
                    # casting the exact difference to a float tangent.
                    ha=arb_objective_gradient_hvp(path[j+1],pairs,labels,spec,cfg,
                        normalization_eps=eps,direction=state[:n])["hvp"]
                    hb=arb_objective_gradient_hvp(path[j+1],pairs,labels,spec,cfg,
                        normalization_eps=eps,direction=state[n:])["hvp"]
                    h=[b-a for a,b in zip(ha,hb)]
                    predicted=momentum_image(state,h,learning_rate=.003,momentum=.9,transpose=True)
                    residual=[arb(float(z))-v-arb(float(u)) for z,v,u in zip(t["states"][j],predicted,f["states"][j])]
                    radius=squared_norm(residual).sqrt()
                    assert bool(arb(t["local_residuals"][j])>=radius)
                    tsquare+=squared_norm(residual);checks+=len(residual)
                assert bool(arb(f["residual_sequence_upper"])>=fsquare.sqrt())
                assert bool(arb(t["residual_sequence_upper"])>=tsquare.sqrt())
                rows.append({"depth":depth,"normalization":norm,"parameters":n,"horizon":3,
                    "forward_residual_upper":f["residual_sequence_upper"],
                    "adjoint_residual_upper":t["residual_sequence_upper"]})
        result={"all_passed":True,"neural_configurations":len(rows),
            "independently_audited_recurrence_coordinates":checks,"seconds":time.perf_counter()-started,"rows":rows}
        print(json.dumps(result,indent=2));return result
    finally:ctx.prec=old


if __name__=="__main__":main()
