"""Authenticate a complete ordinary-Gram family without loading a whole path.

This checks producer provenance, causal/adjoint indexing, original probe
identity, row norms and outward scalar inequalities. It does not replay the
neural HVPs. Their residual enclosures remain obligations of the authenticated
validated producer. No future outcome is read and no event is issued here.
"""
from dataclasses import dataclass
import hashlib
import io
import json
import math
from pathlib import Path

import numpy as np
from flint import ctx

from green_local_residual_bounds import gram_operator_upper, local_residual_slack
from outward_green_products import sequence_upper, streaming_norm_upper
from outward_inexact_anytime_gram import folded_normal_calibration_lower
from verified_artifact_io import EvidencePending, IntegrityError, require_sha256
from window_event_assembly import GreenBound


REQUIRED_SOURCES = frozenset({
    "build_candidate_outward_green.py", "checkpointed_green_products.py",
    "outward_green_products.py", "outward_green_momentum.py",
    "green_local_residual_bounds.py", "arb_enclosed_direction_hvp.py",
    "arb_factored_regularizer_hvp.py", "arb_reverse_transformer.py",
    "arb_reverse.py", "outward_inexact_anytime_gram.py", "inexact_anytime_gram.py",
    "transformer_hvp_grokking.py", "build_larger_candidate_reference.py",
})
PROTOCOLS = {
    "protocol_sha256": "LARGER_CANDIDATE_OUTWARD_GREEN_PROTOCOL.md",
    "local_residual_contract_sha256": "GREEN_LOCAL_RESIDUAL_INTERFACE.md",
}
SCOPE = "verified arithmetic conditional on the original ideal-PRNG projection event"


def require(condition, reason):
    if not condition:
        raise IntegrityError(reason)


def number(value, name, *, positive=False):
    require(type(value) in (float, int), f"invalid {name}")
    try:
        value = float(value)
    except OverflowError:
        raise IntegrityError(f"nonfinite {name}") from None
    require(math.isfinite(value) and value >= 0 and (not positive or value > 0), f"invalid {name}")
    return value


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class SequenceEvidence:
    folder: Path
    summary_sha256: str
    summary: dict
    method: dict


def checked_array(reader, relative, sha, dimension):
    # Hash the same open bytes that are parsed, rather than hashing and then
    # reopening a mutable pathname. Memory is bounded by one row, not H*d.
    path = reader.resolve(relative)
    try:
        with path.open("rb") as stream:
            # Refuse oversized files and malicious header dimensions before
            # np.load could allocate an array from a forged shape.
            maximum_bytes = 8*dimension + 10032
            payload = stream.read(maximum_bytes+1)
    except FileNotFoundError:
        raise EvidencePending(f"missing array artifact: {relative}") from None
    require(len(payload) <= maximum_bytes, "oversized NPY row")
    reader._remember(path, hashlib.sha256(payload).hexdigest(), sha)
    try:
        buffer = io.BytesIO(payload)
        version = np.lib.format.read_magic(buffer)
        require(version in ((1,0),(2,0)), "unsupported NPY row format")
        parse = np.lib.format.read_array_header_1_0 if version == (1,0) else np.lib.format.read_array_header_2_0
        shape, fortran, dtype = parse(buffer, max_header_size=10000)
        require(shape == (dimension,) and dtype == np.float64 and type(fortran) is bool,
                "NPY header does not describe the required row")
        buffer.seek(0)
        value = np.load(buffer, allow_pickle=False)
        require(buffer.tell() == len(payload), "extra bytes after NPY row")
        require(isinstance(value, np.ndarray) and value.dtype == np.float64 and
                value.shape == (dimension,) and np.isfinite(value).all(), "invalid complete array row")
    except (ValueError, EOFError) as error:
        raise IntegrityError("invalid complete array row") from error
    return value


def authenticate_sequence(reader, folder, *, expected_sha, shape, kind, contract,
                          inputs=None, initial_hash=None, precision_bits=128,
                          learning_rate=.003, momentum=.9):
    folder = Path(folder)
    summary, summary_sha = reader.read_json(folder / "summary.json", expected_sha)
    method, method_sha = reader.read_json(folder / "method.json", summary["method_sha256"])
    H, d = shape
    require(type(H) is int and H > 0 and type(d) is int and d > 0 and d % 2 == 0, "invalid sequence shape")
    require(kind in ("input_rows", "forward", "adjoint"), "unknown sequence kind")
    require(summary["complete"] is True and summary["kind"] == method["kind"] == kind,
            "incomplete or substituted sequence")
    require(summary["shape"] == method["shape"] == [H, d], "sequence shape mismatch")
    require(all(type(x) is int for x in summary["shape"] + method["shape"]), "noninteger sequence shape")
    require(method["contract"] == contract, "sequence operator/probe/power contract mismatch")
    rows = summary["rows"]
    require(isinstance(rows, list) and len(rows) == H, "incomplete row population")
    if kind == "input_rows":
        require(inputs is None and initial_hash is not None, "missing original-probe policy")
        require(method["expected_flat_npy_sha256"] == summary["flat_npy_sha256"] == initial_hash,
                "substituted original probe")
        header = io.BytesIO()
        np.lib.format.write_array_header_1_0(header, {
            "descr": np.dtype(np.float64).str, "fortran_order": False, "shape": (H*d,)})
        flat_hash = hashlib.sha256(header.getvalue())
    else:
        require(isinstance(inputs, SequenceEvidence), "missing prior sequence evidence")
        require(method["input_manifest_sha256"] == summary["input_manifest_sha256"] == inputs.summary_sha256,
                "product not linked to its actual input manifest")
        require(type(method["precision_bits"]) is int and method["precision_bits"] == precision_bits,
                "product arithmetic differs from frozen method")
        require(number(method["learning_rate"], "learning rate", positive=True) == learning_rate and
                number(method["momentum"], "momentum") == momentum, "product optimizer mismatch")
        require(type(summary["hvp_calls"]) is int and summary["hvp_calls"] == H-1, "incomplete HVP population")
    order = range(H-1, -1, -1) if kind == "adjoint" else range(H)
    parent = None
    for j in order:
        row = rows[j]
        require(type(row["index"]) is int and row["index"] == j and row["file"] == f"row_{j:03d}.npy",
                "noncanonical or duplicate sequence row")
        if kind != "input_rows":
            record, record_sha = reader.read_json(folder / f"row_{j:03d}.json")
            require(record == row and record["method_sha256"] == method_sha and
                    record["parent_record_sha256"] == parent, "broken recurrence record chain")
            require(record["input_row_sha256"] == inputs.summary["rows"][j]["sha256"], "row input substitution")
            step = None if parent is None else j+1 if kind == "adjoint" else j
            correct_step = (record["hvp_step"] is None if step is None else
                            type(record["hvp_step"]) is int and record["hvp_step"] == step)
            require(correct_step, "incorrect causal HVP index")
            residual = number(record["local_residual_norm_upper"], "local residual")
            if parent is None:
                require(residual == 0 and record["sha256"] == inputs.summary["rows"][j]["sha256"],
                        "endpoint is not an exact input copy")
            parent = record_sha
        norm = number(row["norm_upper"], "row norm")
        value = checked_array(reader, folder / row["file"], row["sha256"], d)
        # The producer computes every row norm at max(256, product precision).
        require(norm == streaming_norm_upper(value), "row norm does not enclose/reproduce its dyadic array")
        if kind == "input_rows":
            flat_hash.update(value.tobytes())
    norm = sequence_upper([number(row["norm_upper"], "row norm") for row in rows])
    require(number(summary["terminal_sequence_norm_upper"], "sequence norm") == norm,
            "sequence norm aggregate mismatch")
    if kind == "input_rows":
        require(flat_hash.hexdigest() == initial_hash, "original Gaussian vector identity mismatch")
    else:
        residual = sequence_upper([number(row["local_residual_norm_upper"], "local residual") for row in rows])
        require(number(summary["residual_sequence_upper"], "sequence residual") == residual,
                "sequence residual aggregate mismatch")
    return SequenceEvidence(folder, summary_sha, summary, method)


def _authenticate_green_family(reader, folder, *, identity, power, method_sha256,
                               original_probe_hashes, failure_probability, learning_rate, momentum):
    require(identity.state_metric == "scaled_momentum_euclidean", "unsupported Green state metric")
    require(type(power) is int and power >= 1, "invalid ordinary Gram power")
    require(isinstance(original_probe_hashes, tuple) and len(original_probe_hashes) > 0,
            "nonempty caller-bound original probe family required")
    require(len(set(original_probe_hashes)) == len(original_probe_hashes), "duplicate original probes")
    for value in original_probe_hashes:
        require_sha256(value)
    probes = len(original_probe_hashes)
    delta = number(failure_probability, "failure probability", positive=True)
    require(delta < 1, "invalid family probability budget")
    folder = Path(folder)
    method, mh = reader.read_json(folder / "method.json", method_sha256)
    reader.check_sources(method, required_names=REQUIRED_SOURCES)
    for key, relative in PROTOCOLS.items():
        reader.check_blob(relative, method[key])
    require(method["candidate_sha256"] == identity.candidate_sha256 and
            method["path_sha256"] == identity.reference_sha256, "foreign candidate/reference Green operator")
    require(type(method["parameters"]) is int and method["parameters"] == identity.parameters and
            type(method["horizon"]) is int and method["horizon"] == identity.horizon and
            type(method["state_dimension"]) is int and method["state_dimension"] == 2*identity.parameters,
            "Green dimension/window mismatch")
    require(type(method["probes"]) is int and method["probes"] == probes and
            tuple(method["initial_probe_flat_npy_sha256"]) == original_probe_hashes and method["delta"] == delta,
            "Green Gaussian calibration/probe policy mismatch")
    require(method["precision_bits"] == 128 and method["scalar_precision_bits"] == 256 and
            method["future_outcome_access"] is False, "unregistered Green arithmetic/outcome policy")
    require(number(method["learning_rate"], "learning rate", positive=True) == learning_rate and
            number(method["momentum"], "momentum") == momentum, "Green optimizer identity mismatch")
    require(method["hvp_backend"] == "full empirical data loss plus exact once-only quadratic-penalty HVP",
            "unregistered HVP backend")
    require(isinstance(method["powers"], list) and all(type(q) is int for q in method["powers"]) and
            set(range(1, power+1)).issubset(method["powers"]), "power outside frozen ordinary ladder")
    pairs, labels = method["training_pairs"], method["training_labels"]
    require(len(pairs) == len(labels) == method["training_examples"] > 0, "incomplete training population")
    population = [{"index": j, "pair": pair, "label": label} for j, (pair, label) in enumerate(zip(pairs, labels))]
    require(canonical_sha(population) == identity.training_set_sha256, "Green training population substitution")
    # No top-level result means this entire family is still pending. In
    # particular, a complete single-probe prefix cannot inherit m-probe c.
    result, result_sha = reader.read_json(folder / f"power_{power:02d}.json", allow_in_progress=True)
    require(result["method_sha256"] == mh and type(result["power"]) is int and result["power"] == power and
            type(result["complete_probe_count"]) is int and result["complete_probe_count"] == probes,
            "incomplete/substituted Gram family")
    require(result["scope"] == SCOPE and result["future_outcome_access"] is False and
            result["event_certificate"] is None, "incompatible Green evidence scope")
    manifest = result["product_manifest_sha256"]
    require(isinstance(manifest, list) and len(manifest) == probes and
            all(isinstance(row, list) and len(row) == power for row in manifest), "incomplete power/probe coverage")
    sequences = []
    for probe in range(probes):
        base = folder / f"probe_{probe}"
        previous = authenticate_sequence(reader, base / "initial", expected_sha=None,
            shape=(identity.horizon, 2*identity.parameters), kind="input_rows",
            contract={"method_sha256": mh, "probe": probe}, initial_hash=original_probe_hashes[probe])
        powers = []
        for q in range(1, power+1):
            pair = {}
            for kind in ("forward", "adjoint"):
                sequence = authenticate_sequence(reader, base / f"power_{q:02d}" / kind,
                    expected_sha=manifest[probe][q-1][kind+"_manifest_sha256"],
                    shape=(identity.horizon, 2*identity.parameters), kind=kind,
                    contract={"method_sha256": mh, "probe": probe, "power": q}, inputs=previous,
                    precision_bits=128, learning_rate=learning_rate, momentum=momentum)
                pair[kind] = sequence.summary
                previous = sequence
            powers.append(pair)
        sequences.append(powers)
    ds = [max(rows[q]["forward"]["residual_sequence_upper"] for rows in sequences) for q in range(power)]
    es = [max(rows[q]["adjoint"]["residual_sequence_upper"] for rows in sequences) for q in range(power)]
    terminal = max(rows[-1]["adjoint"]["terminal_sequence_norm_upper"] for rows in sequences)
    calibration = folded_normal_calibration_lower(delta=delta, probes=probes)
    require(result["forward_residuals"] == ds and result["adjoint_residuals"] == es and
            result["terminal_upper"] == terminal and result["calibration_lower"] == calibration,
            "family scalar inputs differ from all-probe aggregates/calibration")
    kwargs = dict(shift=0., terminal_upper=terminal, calibration_lower=calibration,
                  forward_residuals=ds, adjoint_residuals=es)
    computed = gram_operator_upper(**kwargs)
    require(result["green_norm"] == computed, "stored Green solve differs from outward independent recheck")
    bound = None
    if computed["enclosed"]:
        gain = number(computed["operator_upper"], "Green gain", positive=True)
        require(gain >= 1 and bool(local_residual_slack(gain, **kwargs) >= 0),
                "invalid Green supersolution/identity-diagonal floor")
        bound = GreenBound(identity, gain, "outward", "ideal_gaussian_probes", delta, probes, probes)
    return {"bound": bound, "provenance": {"method_sha256": mh, "result_sha256": result_sha,
            "power": power, "complete_probes": probes, "scope": SCOPE,
            "array_norms_replayed": True, "neural_hvps_replayed": False,
            "event_certificate_issued": False}}


def authenticate_green_family(reader, folder, **kwargs):
    old = ctx.prec
    ctx.prec = 256
    try:
        return _authenticate_green_family(reader, folder, **kwargs)
    except (KeyError, TypeError, IndexError) as error:
        raise IntegrityError("malformed completed Green evidence") from error
    finally:
        ctx.prec = old
