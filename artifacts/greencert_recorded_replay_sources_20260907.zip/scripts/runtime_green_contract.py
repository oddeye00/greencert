"""Strict common-operator identity for differently recorded execution hosts.

Runtime metadata may differ; numerical sources, every mathematical field,
and the complete original Gaussian family may not. This interface supplies
no HVP bound and does not convert one method's records into another's.
"""
import copy
import hashlib
import json
import re


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checked_sha(value):
    require(isinstance(value, str) and re.fullmatch("[0-9a-f]{64}", value) is not None, "canonical SHA256 required")
    return value


def compare_methods(origin, execution, *, origin_sha256, protocol_sha256, execution_sources):
    checked_sha(origin_sha256)
    checked_sha(protocol_sha256)
    require(isinstance(execution_sources, dict) and execution_sources, "caller-bound execution sources required")
    require(set(execution) == set(origin) | {"execution_lineage"}, "method fields added or omitted")
    require(execution["execution_lineage"] == {
        "origin_method_sha256": origin_sha256, "protocol_sha256": protocol_sha256,
        "same_operator_and_original_probes": True, "original_records_relabelled": False,
        "automatic_event_issuance": False, "future_outcome_access": False}, "lineage differs")
    require(all(isinstance(key, str) and key.endswith(".py") and "/" not in key and "\\" not in key
                for key in execution_sources), "invalid additional source name")
    for value in execution_sources.values():
        checked_sha(value)
    require(not (set(origin["sources"]) & set(execution_sources)), "origin source cannot be overridden")
    require(execution["sources"] == {**origin["sources"], **execution_sources}, "source identity changed")
    for key in origin:
        if key not in ("runtime_versions", "sources"):
            require(canonical(execution[key]) == canonical(origin[key]), "operator/probe field changed: " + key)
    runtime = execution["runtime_versions"]
    require(isinstance(runtime, dict) and set(runtime) == {"python", "numpy", "torch", "python_flint", "machine", "platform", "accelerator"}, "execution runtime not explicit")
    require(all(isinstance(v, str) and v for v in runtime.values()) and runtime["machine"] == "aarch64"
            and runtime["platform"] == "linux" and runtime["accelerator"] == "cpu", "unsupported execution host")
    # Runtime identity is recorded, not fabricated to equal the origin host.
    descriptor = {key: value for key, value in origin.items() if key != "runtime_versions"}
    return hashlib.sha256(canonical(descriptor).encode()).hexdigest()


def execution_method(origin, *, origin_sha256, protocol_sha256, execution_sources, runtime):
    result = copy.deepcopy(origin)
    result["runtime_versions"] = dict(runtime)
    result["sources"] = {**origin["sources"], **execution_sources}
    result["execution_lineage"] = {
        "origin_method_sha256": origin_sha256, "protocol_sha256": protocol_sha256,
        "same_operator_and_original_probes": True, "original_records_relabelled": False,
        "automatic_event_issuance": False, "future_outcome_access": False}
    compare_methods(origin, result, origin_sha256=origin_sha256, protocol_sha256=protocol_sha256,
                    execution_sources=execution_sources)
    return result
