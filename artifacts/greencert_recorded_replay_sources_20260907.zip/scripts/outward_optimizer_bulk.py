"""Outward binary64 interval arithmetic for the fixed optimizer Green map.

No BLAS, neural derivatives, or randomized queries are used. Every elementary
array operation is enclosed by its representable predecessor/successor.
Validity assumes correctly rounded IEEE binary64 operations with gradual
underflow. Runtime checks are diagnostics, not a proof of hardware behavior.
"""
from fractions import Fraction
import math

import numpy as np
from flint import arb, ctx
from outward_inexact_anytime_gram import exact_arb


class BulkArithmeticError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise BulkArithmeticError(message)


def ieee_preflight():
    info = np.finfo(np.float64)
    require(info.bits == 64 and info.nmant == 52 and info.eps == 2.0**-52,
            "IEEE binary64 required")
    with np.errstate(all="ignore"):
        tiny = float(np.nextafter(np.float64(0), np.float64(math.inf)))
        require(tiny == float.fromhex("0x0.0000000000001p-1022"), "subnormal successor unavailable")
        for size in (1,32,4097):
            unit = np.ones(size,dtype=np.float64)
            small = np.full(size,tiny,dtype=np.float64)
            require(np.all((unit+2.0**-53) == unit), "round-to-nearest-even check failed")
            require(np.all((small+small) == 2*tiny) and np.all((small*2) == 2*tiny),
                    "subnormal arithmetic/gradual underflow check failed")
            require(np.all((np.full(size,info.tiny)*0.5) == info.tiny/2), "flush-to-zero detected")
    return {"binary64_checks_passed":True, "numpy":np.__version__,
            "required_arithmetic":"correctly rounded IEEE binary64; gradual underflow",
            "hardware_correctness_formally_verified":False}


def fraction_interval(value):
    try:
        center = float(value)
    except OverflowError:
        raise BulkArithmeticError("coefficient overflow") from None
    require(math.isfinite(center), "nonfinite coefficient")
    exact = Fraction.from_float(center)
    lo = math.nextafter(center,-math.inf) if exact > value else center
    hi = math.nextafter(center, math.inf) if exact < value else center
    require(math.isfinite(lo) and math.isfinite(hi), "unrepresentable coefficient enclosure")
    return lo,hi


def optimizer_matrix(*, learning_rate, momentum, weight_decay):
    values = (learning_rate,momentum,weight_decay)
    require(all(type(v) in (int,float) and math.isfinite(v) and v >= 0 for v in values) and
            learning_rate > 0, "invalid optimizer constants")
    eta,mu,lam = map(Fraction,values)
    a = eta*lam
    return ((fraction_interval(1-a),fraction_interval(-mu)),
            (fraction_interval(a),fraction_interval(mu)))


def validate_interval(lo,hi):
    require(isinstance(lo,np.ndarray) and isinstance(hi,np.ndarray) and lo.shape == hi.shape and
            lo.dtype == hi.dtype == np.float64 and np.isfinite(lo).all() and np.isfinite(hi).all() and
            np.all(lo <= hi), "finite ordered binary64 interval arrays required")


def _outward(value, direction):
    rounded = np.nextafter(value,direction)
    require(np.isfinite(rounded).all(), "interval overflow; no finite enclosure")
    return rounded


def _add(left,right):
    return _outward(left[0]+right[0],-math.inf),_outward(left[1]+right[1],math.inf)


def _scale(interval, coefficient):
    a,b = coefficient
    if a == b == 0:
        zeros = np.zeros_like(interval[0])
        return zeros,zeros.copy()
    low = high = None
    for x in interval:
        for c in (a,b):
            product = x*c
            low = product if low is None else np.minimum(low,product)
            high = product if high is None else np.maximum(high,product)
    return _outward(low,-math.inf),_outward(high,math.inf)


def interval_step(state, injection, matrix, *, transpose=False):
    """One enclosed update; state and injection are (lower,upper) vectors."""
    require(type(transpose) is bool, "boolean transpose required")
    validate_interval(*state)
    validate_interval(*injection)
    require(state[0].ndim == 1 and state[0].size > 0 and state[0].size % 2 == 0 and
            state[0].shape == injection[0].shape, "invalid bulk state layout")
    require(isinstance(matrix,tuple) and len(matrix) == 2 and all(len(row) == 2 for row in matrix) and
            all(len(c) == 2 and math.isfinite(c[0]) and math.isfinite(c[1]) and c[0] <= c[1]
                for row in matrix for c in row), "invalid interval bulk matrix")
    n = state[0].size//2
    pieces = [(state[0][:n],state[1][:n]),(state[0][n:],state[1][n:])]
    result = []
    with np.errstate(over="raise",invalid="raise",divide="raise",under="ignore"):
        try:
            for i in range(2):
                coeff = [matrix[j][i] if transpose else matrix[i][j] for j in range(2)]
                value = _add(_scale(pieces[0],coeff[0]),_scale(pieces[1],coeff[1]))
                value = _add(value,(injection[0][i*n:(i+1)*n],injection[1][i*n:(i+1)*n]))
                result.append(value)
            return np.concatenate([v[0] for v in result]),np.concatenate([v[1] for v in result])
        except FloatingPointError as error:
            raise BulkArithmeticError("nonfinite bulk arithmetic") from error


def interval_product(lower, upper=None, *, matrix, transpose=False):
    """Coordinate-block finite-window K0 or K0* image enclosure, O(H*block)."""
    require(type(transpose) is bool, "boolean transpose required")
    upper = lower if upper is None else upper
    validate_interval(lower,upper)
    require(lower.ndim == 2 and min(lower.shape) > 0 and lower.shape[1] % 2 == 0,
            "H by even-dimension coordinate-block input required")
    H,d = lower.shape
    result_lo,result_hi = np.empty_like(lower),np.empty_like(lower)
    state = (np.zeros(d,dtype=np.float64),np.zeros(d,dtype=np.float64))
    for j in (range(H-1,-1,-1) if transpose else range(H)):
        if (transpose and j == H-1) or (not transpose and j == 0):
            # The causal/adjoint diagonal block is exactly the identity.
            state = lower[j].copy(),upper[j].copy()
        else:
            state = interval_step(state,(lower[j],upper[j]),matrix,transpose=transpose)
        result_lo[j],result_hi[j] = state
    return result_lo,result_hi


def difference_interval(point,interval):
    validate_interval(*interval)
    require(isinstance(point,np.ndarray) and point.dtype == np.float64 and
            point.shape == interval[0].shape and np.isfinite(point).all(), "invalid subtraction point")
    with np.errstate(over="raise",invalid="raise",under="ignore"):
        try:
            return _outward(point-interval[1],-math.inf),_outward(point-interval[0],math.inf)
        except FloatingPointError as error:
            raise BulkArithmeticError("nonfinite bulk subtraction") from error


def squared_norm_upper(interval):
    """Outward sum of endpoint squares; every tree addition rounds outward.

    No unverified BLAS/numpy.sum error term is silently set to zero.
    """
    validate_interval(*interval)
    magnitude = np.maximum(np.abs(interval[0]),np.abs(interval[1])).reshape(-1)
    require(magnitude.size > 0, "empty norm")
    with np.errstate(over="raise",invalid="raise",under="ignore"):
        try:
            level = _outward(magnitude*magnitude,math.inf)
            while len(level) > 1:
                pairs = len(level)//2
                following = _outward(level[:2*pairs:2]+level[1:2*pairs:2],math.inf)
                level = np.concatenate((following,level[-1:])) if len(level)%2 else following
            return float(level[0])
        except FloatingPointError as error:
            raise BulkArithmeticError("norm overflow") from error


def combine_squared_bounds(bounds, *, precision_bits=256):
    require(isinstance(bounds,(list,tuple)) and bounds and
            all(type(v) in (int,float) and math.isfinite(v) and v >= 0 for v in bounds),
            "finite nonnegative squared bounds required")
    require(type(precision_bits) is int and precision_bits >= 64, "at least64 bits required")
    previous=ctx.prec
    ctx.prec=precision_bits
    try:
        value=sum((exact_arb(v) for v in bounds),arb(0)).sqrt()
        upper=math.nextafter(float(value.upper()),math.inf)
        require(math.isfinite(upper),"norm combination overflow")
        return upper
    finally:
        ctx.prec=previous


def gram_difference_bound(injections, stored_image, *, matrix):
    """Enclose ||stored_w - K0* K0 g|| for a single coordinate block.

    The caller must authenticate original g and stored_w and combine all
    coordinate blocks/probes. This alone is not a bound for ||K||.
    """
    forward=interval_product(injections,matrix=matrix)
    gram=interval_product(*forward,matrix=matrix,transpose=True)
    return squared_norm_upper(difference_interval(stored_image,gram))
