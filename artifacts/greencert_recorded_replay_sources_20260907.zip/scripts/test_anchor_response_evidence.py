"""Coherently rehashed fixtures for anchor/response provenance and arithmetic.

These fixtures test the evidence adapter, not neural gradient/HVP truth.
"""
import hashlib
import io
import json
import math
from pathlib import Path
import shutil
import tempfile

import numpy as np
from flint import arb, ctx

from anchor_response_evidence import RESPONSE_SOURCES, authenticate_anchor, authenticate_response, original_checkpoint
from verified_artifact_io import EvidenceReader, EvidencePending, IntegrityError
from window_event_assembly import Identity

ROOT=Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    return digest(path)


def upper(value):
    return math.nextafter(float(value.upper()),math.inf) if not bool(value==0) else 0.


def fixture(root,*,H=3,n=4,eta=.1,mu=.9,mutation=None,parameter_mismatch=False):
    root.mkdir()
    def change(stage,value,**where):
        if mutation is not None:
            mutation(stage,value,**where)
    sources={}
    names=RESPONSE_SOURCES|{"audit_candidate_anchor_scaling.py","audit_verified_response_records.py"}
    for name in names:
        p=root/"scripts"/name
        p.parent.mkdir(exist_ok=True)
        p.write_text("# synthetic source identity fixture\n")
        sources[name]=digest(p)
    policies={}
    for name in ("LARGER_CANDIDATE_VERIFIED_RESPONSE_PROTOCOL.md","LARGER_CANDIDATE_REVERSE_ARITHMETIC_PROTOCOL.md"):
        p=root/name
        p.write_text("synthetic adapter test policy\n")
        policies[name]=digest(p)
    parameter=np.arange(n,dtype=np.float64)/8
    velocity=np.arange(1,n+1,dtype=np.float64)/3
    np.savez(root/"anchor.npz",parameter=parameter,velocity=velocity)
    candidate={"anchor_sha256":digest(root/"anchor.npz"),"config":{"learning_rate":eta,"momentum":mu}}
    csha=write(root/"candidate.json",candidate)
    points=np.tile(np.concatenate((parameter,eta*velocity)),(H+1,1))
    if parameter_mismatch:
        points[0,0]+=.125
    np.save(root/"corrected.npy",points,allow_pickle=False)
    np.save(root/"original.npy",points,allow_pickle=False)
    psha=digest(root/"corrected.npy")
    reference={"candidate_sha256":csha,"corrected_scaled_sha256":psha,"reference_scaled_sha256":digest(root/"original.npy"),
               "parameters":n,"horizon":H}
    change("reference",reference)
    rsha=write(root/"reference.json",reference)
    identity=Identity(csha,psha,"2"*64,"3"*64,n,H,"scaled_momentum_euclidean")
    delta=[arb(eta)*arb(float(v))-arb(float(w)) for v,w in zip(velocity,points[0,n:])]
    offset=sum((x*x for x in delta),arb(0)).sqrt()
    count=sum(not bool(x==0) for x in delta)
    anchor={"parameters":n,"precision_bits":256,"parameter_anchor_exactly_matches":True,
            "reference_and_corrected_anchors_match":True,"stored_velocity_is_rounded_eta_times_v":True,
            "exact_scaled_velocity_matches":count==0,"nonzero_velocity_conversion_coordinates":count,
            "velocity_anchor_offset_norm_upper":upper(offset),"maximum_coordinate_offset_upper":upper(max(abs(v).upper() for v in delta)),
            "first_injection_norm_upper":upper(arb(2).sqrt()*abs(arb(mu))*offset),
            "candidate_sha256":csha,"anchor_sha256":candidate["anchor_sha256"],"corrected_path_sha256":psha,
            "auditor_sha256":sources["audit_candidate_anchor_scaling.py"],"future_outcome_access":False,"full_event_certificate":False}
    change("anchor",anchor)
    write(root/"anchor_audit.json",anchor)
    grad_folder=root/"gradient"
    grad_folder.mkdir()
    (grad_folder/"derivative_enclosures.npz").write_bytes(b"synthetic validated-producer blob; no neural claim")
    grad_sha=digest(grad_folder/"derivative_enclosures.npz")
    grad_method={"sources":{k:v for k,v in sources.items() if k in RESPONSE_SOURCES},
        "protocol_sha256":policies["LARGER_CANDIDATE_REVERSE_ARITHMETIC_PROTOCOL.md"],
        "candidate_sha256":csha,"path_sha256":psha,"precision_bits":192,"future_outcome_access":False}
    change("gradient_method",grad_method)
    gmh=write(grad_folder/"method.json",grad_method)
    grad={"method_sha256":gmh,"enclosures_sha256":grad_sha,"parameters":n,"training_examples":2,
          "reference_step":0,"precision_bits":192}
    change("gradient",grad)
    write(grad_folder/"result.json",grad)
    folder=root/"response"
    method={"sources":{k:v for k,v in sources.items() if k in RESPONSE_SOURCES},
        "protocol_sha256":policies["LARGER_CANDIDATE_VERIFIED_RESPONSE_PROTOCOL.md"],
        "candidate_sha256":csha,"reference_sha256":rsha,"path_sha256":psha,"step0_gradient_sha256":grad_sha,
        "parameters":n,"horizon":H,"precision_bits":192,"future_outcome_access":False}
    change("method",method)
    mh=write(folder/"method.json",method)
    entries=[]
    independent_rows=[]
    norms=[]
    errors=[]
    for j in range(H):
        value=(np.arange(1,2*n+1,dtype=np.float64)*(j+1))/2**20
        path=folder/f"response_{j+1:03d}.npy"
        np.save(path,value,allow_pickle=False)
        row={"step":j,"method_sha256":mh,"response_sha256":digest(path),
             "response_norm_upper":upper(sum((arb(float(x))**2 for x in value),arb(0)).sqrt()),
             "parameter_response_norm_upper":upper(sum((arb(float(x))**2 for x in value[:n]),arb(0)).sqrt()),
             "recurrence_error_upper":2**-60,"defect_norm_upper":.1}
        norms.append(row["response_norm_upper"])
        errors.append(row["recurrence_error_upper"])
        change("row",row,j=j)
        rh=write(folder/f"step_{j:03d}.json",row)
        entries.append({"step":j,"sha256":rh})
        independent_rows.append({"step":j,"record_sha256":rh,"array_sha256":row["response_sha256"]})
    summary={"method_sha256":mh,"parameters":n,"horizon":H,"precision_bits":192,"future_outcome_access":False,
             "recurrence_sequence_error_upper":upper(sum((arb(v)**2 for v in errors),arb(0)).sqrt()),
             "response_sequence_norm_upper":upper(sum((arb(v)**2 for v in norms),arb(0)).sqrt()),
             "response_max_norm_upper":max(norms),"rows":entries}
    change("summary",summary)
    sh=write(folder/"summary.json",summary)
    independent={"all_passed":True,"summary_sha256":sh,"method_sha256":mh,"parameters":n,"steps":H,
                 "coordinates_checked":H*2*n,"future_outcome_access":False,"full_event_certificate":False,
                 "auditor_sha256":sources["audit_verified_response_records.py"],"rows":independent_rows,
                 **{k:summary[k] for k in ("recurrence_sequence_error_upper","response_sequence_norm_upper","response_max_norm_upper")}}
    change("independent",independent)
    write(folder/"independent_complete_audit.json",independent)
    return dict(reader=EvidenceReader(root),identity=identity,candidate_path="candidate.json",reference_record_path="reference.json",
                checkpoint_path="anchor.npz",corrected_path="corrected.npy",original_path="original.npy",audit_path="anchor_audit.json")


def run(args):
    anchor=authenticate_anchor(**args)
    checked=authenticate_response(args["reader"],"response",identity=args["identity"],anchor=anchor,
                                  gradient_folder="gradient",training_count=2)
    return anchor,checked


def main():
    old=ctx.prec
    ctx.prec=256
    parent=ROOT/"tmp"
    parent.mkdir(exist_ok=True)
    temp=Path(tempfile.mkdtemp(prefix="anchor_response_test_",dir=parent)).resolve()
    assert temp.parent==parent.resolve() and temp.name.startswith("anchor_response_test_")
    report={"all_passed":True,"valid_anchor_response_cases":0,"coherently_rehashed_rejections":0,
            "pending_checks":0,"neural_kernels_replayed":False,"event_certificates_issued":0}
    try:
        for i,(H,n,eta,mu) in enumerate(((1,1,.1,.9),(3,4,.125,.9),(5,7,.1,0.),(3,4,.1,.9))):
            args=fixture(temp/f"valid_{i}",H=H,n=n,eta=eta,mu=mu)
            anchor,checked=run(args)
            assert len(checked["bound"].parameter_norms)==H+1 and checked["bound"].parameter_norms[0]==0
            assert checked["bound"].first_injection_error_upper==anchor.first_injection_error_upper
            if eta==.125 or mu==0:
                assert anchor.first_injection_error_upper==0
            else:
                assert anchor.first_injection_error_upper>0
            assert checked["provenance"]["coordinates_replayed"]==H*2*n
            report["valid_anchor_response_cases"]+=1
        def field(stage,key,value,**criteria):
            def mutation(actual,row,**where):
                if actual==stage and all(where.get(k)==v for k,v in criteria.items()):
                    row[key]=value
            return mutation
        changes=[field("anchor","first_injection_norm_upper",0.),field("anchor","first_injection_norm_upper",None),
            field("anchor","velocity_anchor_offset_norm_upper",0.),field("anchor","maximum_coordinate_offset_upper",0.),
            field("anchor","nonzero_velocity_conversion_coordinates",0),field("anchor","parameter_anchor_exactly_matches",False),
            field("anchor","exact_scaled_velocity_matches",True),field("anchor","future_outcome_access",True),
            field("anchor","parameters",999),field("anchor","corrected_path_sha256","0"*64),
            field("reference","horizon",4),field("method","sources",{}),field("method","candidate_sha256","0"*64),
            field("method","path_sha256","0"*64),field("method","reference_sha256","0"*64),
            field("method","step0_gradient_sha256","0"*64),field("method","precision_bits",64),
            field("gradient","training_examples",1),field("gradient","reference_step",1),
            field("gradient_method","path_sha256","0"*64),field("gradient_method","sources",{}),
            field("row","parameter_response_norm_upper",0.,j=1),field("row","response_norm_upper",0.,j=1),
            field("row","recurrence_error_upper",-1.,j=1),field("row","step",2,j=1),
            field("summary","recurrence_sequence_error_upper",0.),field("summary","response_sequence_norm_upper",0.),
            field("summary","response_max_norm_upper",0.),field("summary","rows",[]),
            field("independent","all_passed",False),field("independent","coordinates_checked",1),
            field("independent","rows",[]),field("independent","summary_sha256","0"*64)]
        for i,mutation in enumerate(changes):
            args=fixture(temp/f"bad_{i}",mutation=mutation)
            try:
                run(args)
            except IntegrityError:
                report["coherently_rehashed_rejections"]+=1
            else:
                raise AssertionError(f"coherent corruption {i} accepted")
        args=fixture(temp/"parameter_mismatch",parameter_mismatch=True)
        try:
            run(args)
        except IntegrityError:
            report["coherently_rehashed_rejections"]+=1
        else:
            raise AssertionError("wrong parameter anchor accepted")
        for i,name in enumerate(("anchor.npz","response/summary.json","response/response_002.npy","response/independent_complete_audit.json")):
            args=fixture(temp/f"pending_{i}")
            (args["reader"].root/name).unlink()  # Newly generated fixture only.
            try:
                run(args)
            except EvidencePending:
                report["pending_checks"]+=1
            else:
                raise AssertionError("incomplete anchor/response evidence promoted")
        print(json.dumps(report,indent=2))
        return report
    finally:
        ctx.prec=old
        assert temp.resolve().parent==parent.resolve() and temp.name.startswith("anchor_response_test_")
        shutil.rmtree(temp)


if __name__=="__main__":
    main()
