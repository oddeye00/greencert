"""Read-only response replay with exact squared-norm inequalities.

The metadata/anchor/gradient bindings follow the frozen reference auditor.
Only vector norm reduction changes; all original scalar bounds are retained.
No neural gradient/HVP is recomputed or silently assigned zero error.
"""
from pathlib import Path
from flint import arb, ctx
from anchor_response_evidence import AnchorEvidence, RESPONSE_SOURCES
from exact_dyadic_norm import squared_integer, encloses_norm
from green_family_evidence import number, require, checked_array
from verified_artifact_io import IntegrityError
from window_event_assembly import ResponseBound

def authenticate_response(reader, folder, *, identity, anchor, gradient_folder, training_count, progress=None):
    old = ctx.prec
    ctx.prec = 256
    try:
        require(isinstance(anchor,AnchorEvidence) and anchor.identity == identity, "response anchor binding mismatch")
        require(type(training_count) is int and training_count > 0, "invalid training population")
        folder = Path(folder)
        summary, summary_sha = reader.read_json(folder/"summary.json",allow_in_progress=True)
        method, mh = reader.read_json(folder/"method.json",summary["method_sha256"])
        reader.check_sources(method,required_names=RESPONSE_SOURCES)
        reader.check_blob("LARGER_CANDIDATE_VERIFIED_RESPONSE_PROTOCOL.md",method["protocol_sha256"])
        require(method["candidate_sha256"] == identity.candidate_sha256 and
                method["path_sha256"] == identity.reference_sha256 and
                method["reference_sha256"] == anchor.reference_record_sha256, "response reference substitution")
        for record in (method,summary):
            require(type(record["parameters"]) is int and record["parameters"] == identity.parameters and
                    type(record["horizon"]) is int and record["horizon"] == identity.horizon and
                    record["precision_bits"] == 192 and record["future_outcome_access"] is False,
                    "response dimension/precision/outcome scope mismatch")
        # The initial gradient was imported from this verified full-mean
        # vector enclosure. Authenticate its producer and exact blob identity.
        gradient_folder = Path(gradient_folder)
        grad, gs = reader.read_json(gradient_folder/"result.json")
        gm, gmh = reader.read_json(gradient_folder/"method.json",grad["method_sha256"])
        reader.check_sources(gm,required_names=RESPONSE_SOURCES - {
            "build_candidate_verified_response.py","outward_variational_response.py","test_outward_variational_response.py"})
        reader.check_blob("LARGER_CANDIDATE_REVERSE_ARITHMETIC_PROTOCOL.md",gm["protocol_sha256"])
        require(gm["candidate_sha256"] == identity.candidate_sha256 and gm["path_sha256"] == identity.reference_sha256 and
                grad["parameters"] == identity.parameters and grad["training_examples"] == training_count and
                grad["reference_step"] == 0 and grad["precision_bits"] == gm["precision_bits"] == 192 and
                gm["future_outcome_access"] is False, "initial gradient enclosure identity/scope mismatch")
        require(grad["enclosures_sha256"] == method["step0_gradient_sha256"], "initial response gradient substitution")
        reader.check_blob(gradient_folder/"derivative_enclosures.npz",method["step0_gradient_sha256"])
        independent, independent_sha = reader.read_json(folder/"independent_complete_audit.json")
        reader.check_blob("scripts/audit_verified_response_records.py",independent["auditor_sha256"])
        H,n = identity.horizon,identity.parameters
        require(independent["all_passed"] is True and independent["summary_sha256"] == summary_sha and
                independent["method_sha256"] == mh and independent["parameters"] == n and
                independent["steps"] == H and independent["coordinates_checked"] == H*2*n and
                independent["future_outcome_access"] is False and independent["full_event_certificate"] is False,
                "independent response audit is incomplete or foreign")
        require(isinstance(summary["rows"],list) and len(summary["rows"]) == H and
                isinstance(independent["rows"],list) and len(independent["rows"]) == H, "incomplete signed response window")
        tau2 = arb(0)
        norm2 = 0
        upper_norms = []
        parameter_norms = [0.]
        for j in range(H):
            entry = summary["rows"][j]
            require(type(entry["step"]) is int and entry["step"] == j, "noncanonical signed response time index")
            row, row_sha = reader.read_json(folder/f"step_{j:03d}.json",entry["sha256"])
            require(type(row["step"]) is int and row["step"] == j and row["method_sha256"] == mh,
                    "response row identity/index mismatch")
            audit_row = independent["rows"][j]
            require(audit_row == {"step":j,"record_sha256":row_sha,"array_sha256":row["response_sha256"]},
                    "response vector differs from independent audit")
            value = checked_array(reader,folder/f"response_{j+1:03d}.npy",row["response_sha256"],2*n)
            a = squared_integer(value[:n])
            b = squared_integer(value[n:])
            norm = number(row["response_norm_upper"],"response norm")
            param = number(row["parameter_response_norm_upper"],"parameter response norm")
            residual = number(row["recurrence_error_upper"],"response recurrence residual")
            number(row["defect_norm_upper"],"reference defect norm")
            require(encloses_norm(a+b, norm) and encloses_norm(a, param), "response norm understated")
            norm2 += a+b
            tau2 += arb(residual)**2
            upper_norms.append(norm)
            parameter_norms.append(param)
            if progress is not None:
                progress(j+1,H)
        tau = number(summary["recurrence_sequence_error_upper"],"sequence recurrence error")
        sequence = number(summary["response_sequence_norm_upper"],"response sequence norm")
        require(bool(arb(tau) >= tau2.sqrt()) and encloses_norm(norm2, sequence), "response aggregate understated")
        require(number(summary["response_max_norm_upper"],"response maximum") == max(upper_norms), "response maximum mismatch")
        for key in ("recurrence_sequence_error_upper","response_sequence_norm_upper","response_max_norm_upper"):
            require(independent[key] == summary[key], "independent response aggregate mismatch")
        return {"bound":ResponseBound(identity,tuple(parameter_norms),tau,anchor.first_injection_error_upper,True,"outward"),
                "provenance":{"summary_sha256":summary_sha,"method_sha256":mh,"initial_gradient_result_sha256":gs,
                    "independent_audit_sha256":independent_sha,"anchor_audit_sha256":anchor.audit_sha256,
                    "coordinates_replayed":H*2*n,"anchor_conversion_replayed":True,
                    "neural_kernels_replayed":False,"event_certificate_issued":False,
                    "training_binding":"fixed candidate config and authenticated deterministic data-split producer"}}
    except (KeyError,TypeError,IndexError) as error:
        raise IntegrityError("malformed response evidence") from error
    finally:
        ctx.prec = old
