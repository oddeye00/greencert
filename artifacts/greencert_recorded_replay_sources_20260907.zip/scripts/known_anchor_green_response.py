"""Stream a known velocity offset through the unchanged causal Green map.

This is a numerical producer, not an evidence adapter or event gate. The
caller must authenticate the encoding and the HVP callback's operator. No
original anchor error is removed by this module.
"""
from pathlib import Path
import math

import numpy as np
from flint import ctx

from checkpointed_green_products import StoredRows, digest, product, save_json, store_rows
from known_anchor_propagation import first_homogeneous_step
from known_anchor_response import require
from outward_green_products import sequence_upper


def construct(folder, encoded_velocity_offset, hvp, *, horizon, learning_rate,
              momentum, operator_sha256, encoding_sha256, precision_bits=128,
              max_new_steps=None, guard=None, progress=None):
    """Construct T_1,...,T_H from T_0=(0,dbar), with full residual accounting.

    The Green forcing has the rounded T_1 in its first row and zeros later.
    The first-row rounding residual is accounted for *outside* product(),
    whose endpoint copy is exact only relative to that rounded forcing.
    HVP indices are 1,...,H-1, at the original reference centers. An unfinished
    prefix never returns a full-window residual bound. Resuming is safe only
    under the identical contract; product() authenticates existing rows.
    """
    require(type(horizon) is int and horizon >= 1, "positive integer horizon required")
    require(type(precision_bits) is int and precision_bits >= 64, "precision below contract")
    require(max_new_steps is None or (type(max_new_steps) is int and max_new_steps >= 0),
            "invalid transition budget")
    require(type(learning_rate) in (int, float) and math.isfinite(learning_rate)
            and learning_rate > 0, "positive finite learning rate required")
    for value in (operator_sha256, encoding_sha256):
        require(isinstance(value, str) and len(value) == 64 and
                all(c in "0123456789abcdef" for c in value), "canonical SHA256 required")
    if guard is not None:
        guard()
    first = first_homogeneous_step(encoded_velocity_offset, momentum=momentum)
    state = first.pop("next_state")
    folder = Path(folder)
    contract = {
        "role": "deterministic_known_anchor_response_not_Gaussian_probe",
        "operator_sha256": operator_sha256,
        "encoding_sha256": encoding_sha256,
        "horizon": horizon, "parameters": len(encoded_velocity_offset),
        "learning_rate": float(learning_rate), "momentum": float(momentum),
        "precision_bits": precision_bits,
        "first_step_residual_upper": first["local_residual_norm_upper"],
    }

    def forcing():
        yield state
        for _ in range(1, horizon):
            yield np.zeros_like(state)

    # Regeneration checks every input row, including the zero forcing rows.
    inputs = store_rows(folder / "forcing", forcing(),
                        shape=(horizon, len(state)), contract=contract)
    result = product(folder / "response", inputs, hvp,
                     learning_rate=learning_rate, momentum=momentum,
                     precision_bits=precision_bits, contract=contract,
                     max_new_steps=max_new_steps, guard=guard, progress=progress)
    if not result["complete"]:
        return {"complete": False, "completed_steps": result["completed_steps"],
                "horizon": horizon, "full_window_residual_upper": None,
                "event_certificate_issued": False, "original_anchor_bound_replaced": False}
    verified = StoredRows(folder / "response")
    require(verified.method["contract"] == contract, "response contract mismatch")
    require(np.array_equal(verified.row(0), state), "first response mismatch")
    old = ctx.prec
    ctx.prec = max(old, 256)
    try:
        # The first residual and later product residuals occupy disjoint rows.
        tau = sequence_upper([first["local_residual_norm_upper"],
                              verified.summary["residual_sequence_upper"]])
    finally:
        ctx.prec = old
    if guard is not None:
        guard()
    output = {
        "complete": True, "contract": contract,
        "forcing_manifest_sha256": inputs.identity,
        "response_manifest_sha256": verified.identity,
        "first_step_residual_upper": first["local_residual_norm_upper"],
        "later_product_residual_upper": verified.summary["residual_sequence_upper"],
        "full_window_residual_upper": tau,
        "hvp_calls": verified.summary["hvp_calls"],
        "event_certificate_issued": False, "original_anchor_bound_replaced": False,
        "scope": "computed deterministic response; caller must verify encoding tail, "
                 "same-operator HVPs, combined signed response, and nonlinear event closure",
    }
    save_json(folder / "summary.json", output)
    return output
