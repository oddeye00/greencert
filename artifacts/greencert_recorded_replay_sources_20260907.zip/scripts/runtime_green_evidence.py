"""Complete original-probe Green families with explicit execution lineages.

Every sequence keeps its own method hash and input chain. Only the execution
metadata and caller-bound orchestration sources may vary between methods.
This checks complete evidence and scalar bounds, not the neural HVPs anew.
"""
from pathlib import Path
from flint import ctx
from green_family_evidence import (REQUIRED_SOURCES, PROTOCOLS, authenticate_sequence,
    canonical_sha, number, require, SCOPE)
from green_local_residual_bounds import gram_operator_upper, local_residual_slack
from outward_inexact_anytime_gram import folded_normal_calibration_lower
from runtime_green_contract import compare_methods
from verified_artifact_io import IntegrityError, require_sha256
from window_event_assembly import GreenBound


def _authenticate(reader, *, origin_folder, origin_method_sha256, executions, sequence_plan,
                  identity, power, original_probe_hashes, failure_probability,
                  learning_rate, momentum, forbidden_paths):
    require(isinstance(forbidden_paths, tuple) and forbidden_paths, "outcome barrier required")
    def barrier():
        require(all(not reader.resolve(path).exists() for path in forbidden_paths), "future barrier open")
    barrier()
    require_sha256(origin_method_sha256)
    origin_folder = Path(origin_folder)
    origin, mh = reader.read_json(origin_folder / "method.json", origin_method_sha256)
    reader.check_sources(origin, required_names=REQUIRED_SOURCES)
    for key, path in PROTOCOLS.items():
        reader.check_blob(path, origin[key])
    require(identity.state_metric == "scaled_momentum_euclidean", "state geometry differs")
    require(origin["candidate_sha256"] == identity.candidate_sha256 and
            origin["path_sha256"] == identity.reference_sha256, "operator identity differs")
    H, n = identity.horizon, identity.parameters
    require(type(H) is int and H > 0 and type(n) is int and n > 0 and
            origin["horizon"] == H and origin["parameters"] == n and origin["state_dimension"] == 2*n,
            "operator dimensions differ")
    require(type(power) is int and power > 0 and set(range(1, power+1)).issubset(origin["powers"]), "power outside frozen ladder")
    require(isinstance(original_probe_hashes, tuple) and len(original_probe_hashes) > 0
            and len(set(original_probe_hashes)) == len(original_probe_hashes), "complete distinct original probe policy required")
    for value in original_probe_hashes:
        require_sha256(value)
    m = len(original_probe_hashes)
    delta = number(failure_probability, "failure probability", positive=True)
    require(delta < 1 and origin["delta"] == delta and origin["probes"] == m and
            tuple(origin["initial_probe_flat_npy_sha256"]) == original_probe_hashes, "Gaussian policy differs")
    eta = number(learning_rate, "learning rate", positive=True)
    mu = number(momentum, "momentum")
    require(origin["learning_rate"] == eta and origin["momentum"] == mu and
            origin["precision_bits"] == 128 and origin["scalar_precision_bits"] == 256
            and origin["future_outcome_access"] is False, "optimizer/arithmetic policy differs")
    require(origin["hvp_backend"] == "full empirical data loss plus exact once-only quadratic-penalty HVP", "unregistered HVP backend")
    population = [{"index": j, "pair": pair, "label": label} for j, (pair, label) in
                  enumerate(zip(origin["training_pairs"], origin["training_labels"]))]
    require(len(population) == len(origin["training_pairs"]) == len(origin["training_labels"]) == origin["training_examples"] > 0
            and canonical_sha(population) == identity.training_set_sha256, "training population differs")
    require(isinstance(executions, dict) and "origin" not in executions, "invalid execution registry")
    methods = {"origin": mh}
    lineage = {}
    for name, location in executions.items():
        require(isinstance(name, str) and name and isinstance(location, dict)
                and set(location) == {"method_path", "method_sha256", "protocol_path", "protocol_sha256", "execution_sources"},
                "invalid caller-bound execution policy")
        method, method_sha = reader.read_json(location["method_path"], location["method_sha256"])
        reader.check_blob(location["protocol_path"], location["protocol_sha256"])
        reader.check_sources(method, required_names=REQUIRED_SOURCES | frozenset(location["execution_sources"]))
        descriptor = compare_methods(origin, method, origin_sha256=mh, protocol_sha256=location["protocol_sha256"],
                                     execution_sources=location["execution_sources"])
        methods[name] = method_sha
        lineage[name] = {"method_sha256": method_sha, "runtime_versions": method["runtime_versions"],
                         "common_operator_sha256": descriptor, "execution_lineage": method["execution_lineage"]}
    require(isinstance(sequence_plan, tuple) and len(sequence_plan) == m and all(
            isinstance(row, tuple) and len(row) == power for row in sequence_plan), "all probes and requested powers required")
    locations = []
    used = set()
    for row in sequence_plan:
        for pair in row:
            require(isinstance(pair, dict) and set(pair) == {"forward", "adjoint"}, "complete forward/adjoint pair required")
            for value in pair.values():
                require(isinstance(value, dict) and set(value) == {"folder", "method"}
                        and value["method"] in methods, "unregistered sequence execution")
                locations.append(reader.resolve(value["folder"]))
                used.add(value["method"])
    require(len(set(locations)) == 2*m*power, "sequence folder reused across roles")
    require(set(executions).issubset(used), "unused execution registry entries")
    ds = [0.] * power
    es = [0.] * power
    terminals = []
    manifests = []
    for probe in range(m):
        barrier()
        previous = authenticate_sequence(reader, origin_folder / f"probe_{probe}/initial", expected_sha=None,
            shape=(H, 2*n), kind="input_rows", contract={"method_sha256": mh, "probe": probe},
            initial_hash=original_probe_hashes[probe])
        powers = []
        for q in range(1, power+1):
            pair = {}
            for kind in ("forward", "adjoint"):
                where = sequence_plan[probe][q-1][kind]
                previous = authenticate_sequence(reader, where["folder"], expected_sha=None,
                    shape=(H, 2*n), kind=kind, contract={"method_sha256": methods[where["method"]], "probe": probe, "power": q},
                    inputs=previous, precision_bits=128, learning_rate=eta, momentum=mu)
                pair[kind] = {"folder": str(where["folder"]), "method": where["method"],
                              "method_sha256": methods[where["method"]], "summary_sha256": previous.summary_sha256}
                maxima = ds if kind == "forward" else es
                maxima[q-1] = max(maxima[q-1], previous.summary["residual_sequence_upper"])
            powers.append(pair)
        terminals.append(previous.summary["terminal_sequence_norm_upper"])
        manifests.append(powers)
    calibration = folded_normal_calibration_lower(delta=delta, probes=m)
    kwargs = {"shift": 0., "terminal_upper": max(terminals), "calibration_lower": calibration,
              "forward_residuals": ds, "adjoint_residuals": es}
    computed = gram_operator_upper(**kwargs)
    bound = None
    if computed["enclosed"]:
        gain = number(computed["operator_upper"], "Green gain", positive=True)
        require(gain >= 1 and bool(local_residual_slack(gain, **kwargs) >= 0), "invalid Green supersolution")
        bound = GreenBound(identity, gain, "outward", "ideal_gaussian_probes", delta, m, m)
    barrier()
    for path, value in tuple(reader.observed.items()):
        reader.check_blob(path, value)
    return {"bound": bound, "scalar_inputs": kwargs, "green_norm": computed, "provenance": {
        "scope": SCOPE, "origin_method_sha256": mh, "executions": lineage,
        "sequence_manifests": manifests, "complete_probes": m, "power": power,
        "array_norms_replayed": True, "neural_hvps_replayed": False,
        "original_records_relabelled": False, "event_certificate_issued": False, "future_outcome_access": False}}


def authenticate_runtime_green_family(reader, **kwargs):
    prior = ctx.prec
    ctx.prec = 256
    try:
        return _authenticate(reader, **kwargs)
    except (KeyError, TypeError, IndexError, ValueError) as error:
        if isinstance(error, IntegrityError):
            raise
        raise IntegrityError("invalid mixed-runtime Green evidence: " + str(error)) from error
    finally:
        ctx.prec = prior
