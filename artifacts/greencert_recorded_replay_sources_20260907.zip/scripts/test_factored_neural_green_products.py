"""Run the independent256-bit Green audit with the factored HVP callback.

Dependency injection is confined to this test harness. The production AD
modules and their existing immutable audit records are not modified.
"""
import contextlib
import io
import json
from arb_factored_regularizer_hvp import factored_chunked_hvp
import test_outward_neural_green_products as harness


def main():
    original=harness.chunked_enclosed_direction_hvp
    try:
        harness.chunked_enclosed_direction_hvp=factored_chunked_hvp
        with contextlib.redirect_stdout(io.StringIO()):result=harness.main()
    finally:harness.chunked_enclosed_direction_hvp=original
    result["tested_hvp_backend"]="factored_chunked_hvp"
    result["independent_reference_backend"]="original256-bit full-objective HVP"
    print(json.dumps(result,indent=2));return result


if __name__=="__main__":main()
