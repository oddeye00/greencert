"""Combine two authenticated responses without rounding away cancellation.

The returned profile is deliberately not the original gate's ResponseBound.
Its use requires an explicit new event-assembly policy, verified physical
encoding tail, and the unchanged full-window derivative/output evidence.
"""
from dataclasses import dataclass
import math
from pathlib import Path

import numpy as np
from flint import arb, ctx

from bulk_gram_evidence import DyadicRowStream
from green_family_evidence import number, require
from homogeneous_response_evidence import HomogeneousEvidence
from outward_optimizer_bulk import difference_interval, squared_norm_upper, combine_squared_bounds
from window_event_assembly import Identity, ResponseBound


@dataclass(frozen=True)
class CombinedResponseProfile:
    identity: Identity
    parameter_norms: tuple
    residual_upper: float
    encoding_injection_tail_upper: float
    original_first_injection_upper: float
    original_summary_sha256: str
    homogeneous_summary_sha256: str


def combine(reader, original_folder, *, original_evidence, homogeneous,
            encoding_injection_tail_upper, block_size=4096, progress=None):
    """Join validated original-response evidence to a homogeneous product.

    original_evidence must be the result of authenticate_response(). The
    encoding tail must come from physical-checkpoint authentication, not a
    guessed zero. These are explicit caller obligations, not re-proved here.
    File reads bind each vector to the already authenticated row at its exact
    time index. Vector work uses coordinate blocks, with O(H+n/block_size)
    scalar metadata, rather than an H-by-n state array.
    """
    require(isinstance(homogeneous, HomogeneousEvidence), "verified homogeneous response required")
    require(isinstance(original_evidence, dict) and isinstance(original_evidence.get("bound"), ResponseBound),
            "verified original response required")
    original = original_evidence["bound"]
    provenance = original_evidence["provenance"]
    require(original.identity == homogeneous.identity and original.parameter_anchor_matches is True and
            original.arithmetic == "outward", "incompatible original response")
    require(type(block_size) is int and 1 <= block_size <= 16384, "invalid coordinate block size")
    tail = number(encoding_injection_tail_upper, "physical encoding injection tail")
    H, n = original.identity.horizon, original.identity.parameters
    require(len(original.parameter_norms) == H+1 and original.parameter_norms[0] == 0.,
            "incomplete original response geometry")
    folder = Path(original_folder)
    summary, sha = reader.read_json(folder/"summary.json", provenance["summary_sha256"])
    require(summary["method_sha256"] == provenance["method_sha256"] and len(summary["rows"]) == H,
            "original response summary changed")
    reader.check_blob(homogeneous.folder/"summary.json", homogeneous.summary_sha256)
    hs = homogeneous.response
    reader.check_blob(hs.folder/"summary.json", hs.summary_sha256)
    norms = [0.]
    for j in range(H):
        entry = summary["rows"][j]
        require(type(entry["step"]) is int and entry["step"] == j, "original response time index differs")
        row, _ = reader.read_json(folder/f"step_{j:03d}.json", entry["sha256"])
        require(row["step"] == j and row["method_sha256"] == provenance["method_sha256"] and
                row["parameter_response_norm_upper"] == original.parameter_norms[j+1],
                "original response row binding differs")
        tr = hs.summary["rows"][j]
        require(tr["index"] == j, "homogeneous response time index differs")
        squares = []
        with DyadicRowStream(reader, folder/f"response_{j+1:03d}.npy", row["response_sha256"], n) as z, \
             DyadicRowStream(reader, hs.folder/tr["file"], tr["sha256"], n) as t:
            for start in range(0, n, block_size):
                stop = min(n, start+block_size)
                width = stop-start
                a, b = z.block(start,stop)[:width], t.block(start,stop)[:width]
                if np.array_equal(a, -b):
                    squares.append(0.)
                else:
                    # Enclose the exact sum of the two saved dyadic vectors.
                    squares.append(squared_norm_upper(difference_interval(a, (-b,-b))))
        norms.append(0. if all(v == 0. for v in squares) else combine_squared_bounds(squares))
        if progress is not None:
            progress(j+1,H)
    old = ctx.prec
    ctx.prec = 256
    try:
        value = arb(number(original.residual_upper, "original recurrence residual")) + arb(homogeneous.residual_upper)
        tau = 0. if bool(value == 0) else math.nextafter(float(value.upper()), math.inf)
        require(math.isfinite(tau), "combined residual overflow")
    finally:
        ctx.prec = old
    reader.check_blob(folder/"summary.json", sha)
    reader.check_blob(homogeneous.folder/"summary.json", homogeneous.summary_sha256)
    reader.check_blob(hs.folder/"summary.json", hs.summary_sha256)
    return CombinedResponseProfile(original.identity, tuple(norms), tau, tail,
        original.first_injection_error_upper, sha, homogeneous.summary_sha256)
