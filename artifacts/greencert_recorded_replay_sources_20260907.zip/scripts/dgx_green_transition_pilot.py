"""One fixed, original-probe full-size Green transition on an isolated host.

This is an execution-portability test, not an additional Gaussian query, a
Green-norm bound, an event certificate, or authority to merge runtime families.
The numerical sources remain byte-identical to the original Windows method.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
REL = Path("results/larger_transformer_third_pass")
CON = REL / "construction_03925"
GREEN = CON / "outward_green"
INITIAL = GREEN / "probe_0/initial"
FORWARD = GREEN / "probe_0/power_01/forward"
METHOD_SHA = "b1d417cbc8b487522f4dccc9a29d5ffa4ee4aa8990c03967b86e9df257461388"
CANDIDATE_SHA = "ffc56c312c343418d3624e8f3344e7a059781c384c13b8d9789b7ba710c69273"
PATH_SHA = "eb23da91377bbb75ebaeea28c22ae3fb0ab220c667c7e8fa2b2fc3fbd1862409"
ROW_SHA = "ebaf672e039389aac060b2284021a5ecb4f7c5cbf3f9679d74125973440886c0"


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def barriers(root):
    for rel in (REL / "reveal.json", REL / "registered_outcome_run",
                CON / "outward_window_disposition.json", CON / "known_anchor_window_disposition.json"):
        check(not (root / rel).exists(), "future/disposition barrier opened")


def control_record(root):
    """Authenticate the two required injections and the first transition chain."""
    gm = read(root / GREEN / "method.json")
    im = read(root / INITIAL / "method.json")
    ins = read(root / INITIAL / "summary.json")
    fm = read(root / FORWARD / "method.json")
    r0 = read(root / FORWARD / "row_000.json")
    r1 = read(root / FORWARD / "row_001.json")
    check(sha(root / GREEN / "method.json") == METHOD_SHA, "original Green method differs")
    check(sha(root / REL / "candidate.json") == CANDIDATE_SHA == gm["candidate_sha256"], "candidate differs")
    check(sha(root / CON / "corrected_scaled.npy") == PATH_SHA == gm["path_sha256"], "reference differs")
    check((gm["horizon"], gm["parameters"], gm["state_dimension"], gm["training_examples"],
           gm["precision_bits"], gm["chunk_size"], gm["learning_rate"], gm["momentum"]) ==
          (64, 451008, 902016, 173, 128, 8, .003, .9), "original operator contract differs")
    check(im["contract"] == {"method_sha256": METHOD_SHA, "probe": 0}, "probe contract differs")
    check(im["kind"] == ins["kind"] == "input_rows" and im["shape"] == [64, 902016], "probe layout differs")
    check(ins["complete"] is True and len(ins["rows"]) == 64 and ins["method_sha256"] == sha(root / INITIAL / "method.json"), "probe manifest differs")
    check(ins["flat_npy_sha256"] == im["expected_flat_npy_sha256"] == gm["initial_probe_flat_npy_sha256"][0], "original Gaussian identity differs")
    check(fm["contract"] == {"method_sha256": METHOD_SHA, "power": 1, "probe": 0}, "product contract differs")
    check(fm["input_manifest_sha256"] == sha(root / INITIAL / "summary.json"), "input manifest join differs")
    check((fm["kind"], fm["shape"], fm["precision_bits"], fm["learning_rate"], fm["momentum"]) ==
          ("forward", [64, 902016], 128, .003, .9), "product operator differs")
    fsha = sha(root / FORWARD / "method.json")
    for j, record in enumerate((r0, r1)):
        source = ins["rows"][j]
        check(source["index"] == record["index"] == j and source["file"] == record["file"] == f"row_{j:03d}.npy", "row indexing differs")
        check(sha(root / INITIAL / source["file"]) == source["sha256"] == record["input_row_sha256"], "injection changed")
        check(record["method_sha256"] == fsha, "row method differs")
    check(r0["hvp_step"] is None and r0["parent_record_sha256"] is None and
          r0["local_residual_norm_upper"] == 0 and r0["sha256"] == ins["rows"][0]["sha256"], "endpoint is not exact injection")
    check(r1["hvp_step"] == 1 and r1["parent_record_sha256"] == sha(root / FORWARD / "row_000.json"), "transition chain differs")
    check(sha(root / FORWARD / "row_001.npy") == ROW_SHA == r1["sha256"], "control state differs")
    check(math.isfinite(r1["local_residual_norm_upper"]) and r1["local_residual_norm_upper"] > 0, "invalid control residual")
    return gm, r1


def validate_plan(plan):
    expected = {"probe": 0, "power": 1, "phase": "forward", "hvp_step": 1,
                "parameters": 451008, "state_dimension": 902016, "training_examples": 173,
                "precision_bits": 128, "chunk_size": 8, "threads": 1, "minimum_free_mib": 4096,
                "source_Green_method_sha256": METHOD_SHA, "candidate_sha256": CANDIDATE_SHA,
                "reference_sha256": PATH_SHA, "control_state_sha256": ROW_SHA,
                "regenerate_probes": False, "automatic_retry": False, "automatic_import": False,
                "future_outcome_access": False, "event_certificate": False}
    for key, value in expected.items():
        check(type(plan.get(key)) is type(value) and plan[key] == value, "fixed pilot field differs: " + key)
    return True


def frozen_fields():
    return {"probe": 0, "power": 1, "phase": "forward", "hvp_step": 1,
            "parameters": 451008, "state_dimension": 902016, "training_examples": 173,
            "precision_bits": 128, "chunk_size": 8, "threads": 1, "minimum_free_mib": 4096,
            "source_Green_method_sha256": METHOD_SHA, "candidate_sha256": CANDIDATE_SHA,
            "reference_sha256": PATH_SHA, "control_state_sha256": ROW_SHA,
            "regenerate_probes": False, "automatic_retry": False, "automatic_import": False,
            "future_outcome_access": False, "event_certificate": False}


def prepare():
    barriers(ROOT)
    gm, _ = control_record(ROOT)
    folder = ROOT / "results/dgx_green_transition_pilot_20260907"
    check(not folder.exists(), "pilot bundle already reserved")
    report = ROOT / "results/dgx_green_transition_contract_20260907.json"
    test = read(report)
    check(test["status"] == "PASS", "contract tests missing")
    for rel, digest in test["sources"].items():
        check(sha(ROOT / rel) == digest, "untested pilot source")
    sources = {Path("scripts") / name for name in gm["sources"]}
    for name, digest in gm["sources"].items():
        check(sha(ROOT / "scripts" / name) == digest, "frozen numerical source changed")
    sources |= {Path("scripts/dgx_green_transition_pilot.py"), Path("scripts/test_dgx_green_transition_pilot.py")}
    pending, done = list(sources), set()
    while pending:
        rel = pending.pop()
        if rel in done:
            continue
        done.add(rel)
        for node in ast.walk(ast.parse((ROOT / rel).read_text(encoding="utf-8"))):
            names = [v.name for v in node.names] if isinstance(node, ast.Import) else (
                [node.module] if isinstance(node, ast.ImportFrom) and node.module else [])
            for name in names:
                path = Path("scripts") / (name.replace(".", "/") + ".py")
                if (ROOT / path).is_file() and path not in done:
                    pending.append(path)
    rels = {REL / "candidate.json", CON / "corrected_scaled.npy", GREEN / "method.json",
            INITIAL / "method.json", INITIAL / "summary.json", INITIAL / "row_000.npy", INITIAL / "row_001.npy",
            FORWARD / "method.json", FORWARD / "row_000.json", FORWARD / "row_001.json", FORWARD / "row_001.npy",
            Path("DGX_GREEN_TRANSITION_PILOT_PROTOCOL.md"), report.relative_to(ROOT)} | done
    folder.mkdir(exist_ok=False)
    manifest = {}
    for rel in sorted(rels):
        target = folder / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / rel, target)
        check(sha(target) == sha(ROOT / rel), "pilot copy changed")
        manifest[rel.as_posix()] = sha(target)
    # Only immutable architecture metadata; parameters are supplied by the
    # reference file, never by make_template's random initialization.
    runtime = read(ROOT / "results/dgx_native_row_pilot_20260907/expected_runtime.json")
    save(folder / "expected_runtime.json", runtime["runtime_metadata"])
    manifest["expected_runtime.json"] = sha(folder / "expected_runtime.json")
    method = {**frozen_fields(), "utc": datetime.now(timezone.utc).isoformat(), "files": manifest,
              "original_numerical_sources": gm["sources"], "runtime_scope": "CPU-only ARM64 execution portability",
              "comparison": "all state bits, original residual, and direct supplied-state Arb residual",
              "scope": "One fixed full empirical HVP transition. No complete Green product or event."}
    validate_plan(method)
    control_record(folder)
    barriers(ROOT)
    save(folder / "pilot_method.json", method)
    archive = folder.with_suffix(".tar")
    with tarfile.open(archive, "x") as handle:
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                handle.add(path, arcname=path.relative_to(folder).as_posix(), recursive=False)
    receipt = {"method_sha256": sha(folder / "pilot_method.json"), "archive_sha256": sha(archive),
               "archive_bytes": archive.stat().st_size, "files": len(manifest), "python_sources": len(done),
               "future_outcome_access": False}
    save(folder / "export_receipt.json", receipt)
    print(json.dumps(receipt, indent=2), flush=True)


def authenticate(expected):
    check(sha(ROOT / "pilot_method.json") == expected, "pilot method differs")
    method = read(ROOT / "pilot_method.json")
    validate_plan(method)
    for rel, digest in method["files"].items():
        path = (ROOT / rel).resolve()
        check(path.is_relative_to(ROOT) and path.is_file() and sha(path) == digest, "pilot input changed: " + rel)
    for name, digest in method["original_numerical_sources"].items():
        check(sha(ROOT / "scripts" / name) == digest, "original source differs")
    barriers(ROOT)
    return method


def run(expected):
    check(sys.platform == "linux" and __debug__, "Linux without -O required")
    method = authenticate(expected)
    out = ROOT / "arm64_execution"
    check(not out.exists(), "pilot execution already reserved")
    memory = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
    check(int(memory["MemAvailable"].split()[0]) / 1024 >= method["minimum_free_mib"], "pilot memory guard")
    for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[key] = "1"
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    os.environ["MPLBACKEND"] = "Agg"
    import numpy as np
    import torch
    import flint
    from flint import arb, ctx
    from transformer_hvp_grokking import TransformerConfig, make_template, flat_spec, make_disjoint_split
    from arb_factored_regularizer_hvp import factored_chunked_hvp
    from outward_green_momentum import rounded_recurrence_step, supplied_recurrence_residual
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.backends.mha.set_fastpath_enabled(False)
    torch.use_deterministic_algorithms(True)
    gm, r1 = control_record(ROOT)
    config = TransformerConfig(**read(ROOT / REL / "candidate.json")["config"])
    model = make_template(config)
    spec = flat_spec(model)
    data = make_disjoint_split(config)
    eps = [[block.norm1.eps, block.norm2.eps] for block in model.blocks]
    metadata = read(ROOT / "expected_runtime.json")
    actual = {"names": list(spec.names), "shapes": [list(s) for s in spec.shapes], "sizes": list(spec.sizes)}
    check(actual == metadata["spec"] and eps == metadata["normalization_eps"] == gm["normalization_eps"], "operator layout/eps differs")
    check(sum(spec.sizes) == 451008 and data[0].tolist() == gm["training_pairs"] and data[1].tolist() == gm["training_labels"], "full training population differs")
    check(all(p.device.type == "cpu" and p.dtype == torch.float64 for p in model.parameters()), "CPU float64 required")
    out.mkdir(exist_ok=False)
    save(out / "start.json", {"utc": datetime.now(timezone.utc).isoformat(), "pid": os.getpid(),
         "proc_stat": Path("/proc/self/stat").read_text(), "method_sha256": expected,
         "python": sys.version, "numpy": np.__version__, "torch": torch.__version__, "python_flint": flint.__version__,
         "all173_pairs_labels_match": True, "runtime_spec_eps_match": True, "cuda_initialized": torch.cuda.is_initialized(),
         "future_outcome_access": False})
    try:
        from test_factored_neural_green_products import main as regressions
        result = regressions()
        check(result["all_passed"], "original neural Green regressions failed")
        save(out / "neural_regressions.json", result)
        authenticate(expected)
        ctx.prec = 128
        raw = np.load(ROOT / CON / "corrected_scaled.npy", mmap_mode="r", allow_pickle=False)
        check(raw.dtype == np.float64 and raw.shape == (65, 902016), "reference dimensions differ")
        state, injection = [np.load(ROOT / INITIAL / f"row_{j:03d}.npy", allow_pickle=False) for j in (0, 1)]
        control = np.load(ROOT / FORWARD / "row_001.npy", allow_pickle=False)
        check(all(v.dtype == np.float64 and v.shape == (902016,) and np.isfinite(v).all() for v in (state, injection, control)), "state shape/dtype differs")
        began, cpu = time.perf_counter(), time.process_time()
        hvp = factored_chunked_hvp(raw[1, :451008], data[0], data[1], spec, config,
            normalization_eps=eps, direction=[arb(float(v)) for v in state[:451008]], chunk_size=8,
            progress=lambda a, b: print(json.dumps({"stage": "fixed_original_probe_hvp", "example_start": a, "example_end": b}), flush=True))
        hvp_seconds, hvp_cpu = time.perf_counter() - began, time.process_time() - cpu
        transition = rounded_recurrence_step(state, injection, hvp, learning_rate=.003, momentum=.9)
        supplied = supplied_recurrence_residual(state, injection, control, hvp, learning_rate=.003, momentum=.9)
        all_bits = bool(np.array_equal(transition["next_state"].view(np.uint64), control.view(np.uint64)))
        residual_equal = transition["local_residual_norm_upper"] == r1["local_residual_norm_upper"]
        contained = supplied <= r1["local_residual_norm_upper"]
        with (out / "next_state.npy").open("xb") as stream:
            np.save(stream, transition["next_state"], allow_pickle=False)
        authenticate(expected)
        summary = {"status": "PASS" if all_bits and residual_equal and contained else "MISMATCH",
            "method_sha256": expected, "all902016_state_bits_equal": all_bits,
            "changed_state_coordinates": int(np.count_nonzero(transition["next_state"].view(np.uint64) != control.view(np.uint64))),
            "original_local_residual_upper": r1["local_residual_norm_upper"],
            "ARM_local_residual_upper": transition["local_residual_norm_upper"], "local_residual_bit_equal": residual_equal,
            "direct_supplied_state_residual_upper": supplied, "original_residual_encloses_direct_ARM_check": contained,
            "next_state_sha256": sha(out / "next_state.npy"), "hvp_seconds": hvp_seconds, "hvp_CPU_seconds": hvp_cpu,
            "whole_transition_with_second_residual_check_seconds": time.perf_counter() - began,
            "neural_regressions_sha256": sha(out / "neural_regressions.json"), "future_outcome_access": False,
            "event_certificate": False, "full_Green_bound": None,
            "scope": "One original fixed probe transition only; not a cross-runtime proof for uncomputed transitions."}
        save(out / "summary.json", summary)
        print(json.dumps(summary, indent=2), flush=True)
        check(summary["status"] == "PASS", "portability control mismatch; inspect without automatic retry")
    except Exception as error:
        save(out / "failure.json", {"type": type(error).__name__, "error": str(error)})
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "run"))
    parser.add_argument("--method-sha256")
    args = parser.parse_args()
    prepare() if args.mode == "prepare" else run(args.method_sha256)
