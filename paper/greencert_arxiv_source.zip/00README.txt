GREENCERT arXiv source release
================================

Compile with: pdflatex certified_local_training_events_arxiv.tex; bibtex certified_local_training_events_arxiv; pdflatex certified_local_training_events_arxiv.tex; pdflatex certified_local_training_events_arxiv.tex

The included .bbl permits direct LaTeX compilation as well. All figures are vector PDFs.
